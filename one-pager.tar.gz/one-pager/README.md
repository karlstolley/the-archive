Some notes from my sketchbook:

* Lighter feel than my previous designs, which have tended dark and heavy

* All in on rich web typography -- but again looking for lighter faces (not, for example, like the heavier slab-serifs on my current site). Some possibilities:
  * [Yalta Sans](http://www.fonts.com/font/linotype/yalta-sans)
  * [Sinova](http://www.fonts.com/font/linotype/sinova)
  * [Linotype Textra](http://www.fonts.com/font/linotype/linotype-textra)
  * [Vialog](http://www.fonts.com/font/linotype/vialog), which has a techie feel

* I want to experiment with the CSS `@supports` API and see how well it holds up in detecting OpenType feature-settings; see [Can I Use...](http://caniuse.com/#feat=css-supports-api), also this old (?), undated (grrrr...) [article on @support](http://www.marioaraque.com/support-css3-detection).

* Better adherence to modular scales, including aspect-ratios on images. Using the `<picture>` element to do more than resize images.

* Copy that better tells who I am & what I do, and why

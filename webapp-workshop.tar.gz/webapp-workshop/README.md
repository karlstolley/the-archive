## Developing Web Apps
*A workshop presented at STC 2014 in Phoenix, AZ by [Karl Stolley](http://karlstolley.com/).*

### Part I: Foundations in HTML5

This part of the workshop introduces HTML5 and its foundations for building web applications. The workshop emphasizes a mobile-first approach, covering some basics of CSS and responsive web design, as well as the new semantics in HTML5 used for structuring information and accepting user input.
Participants will learn to assemble the basic HTML5 and CSS components for their own application that retrieves and displays some form of open data, such as current weather, movie times, or government information. The workshop will also provide hands-on experience with agile development methods and version control.

### Part II: Front-end Interaction
This part of the workshop builds on the structural foundations of HTML5 covered in Part I and examines manipulating the Document Object Model (DOM) using the jQuery JavaScript framework. Participants will learn to process user input and request data on the user’s behalf from a third-party private or government source via the source’s open application programming interface (API). The workshop covers both the nuts-and-bolts of manipulating the DOM to insert and remove data, as well as the design challenges of building a pleasing, animated user interface.

At the conclusion of the workshop, participants will have created their own small Web application that runs entirely in the browser and pulls data from an open API.

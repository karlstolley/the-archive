Move or copy the menu files in this move-to-config/ directory to the config/
directory off of the root of your WikkaWiki installation. Be sure to move only
the individual menu files, not the move-to-config/ directory itself.

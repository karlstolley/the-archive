	<!--
		The owner menu is dynamically generated. To change it,
		edit the owner_menu files in the /config directory.
	-->
<?php
	echo $this->MakeMenu('cw_owner_menu');
?>
	<!--
		The page menu is dynamically generated. To change it,
		edit the page_menu files in the /config directory.
	-->
<?php
	echo $this->MakeMenu('cw_page_menu');
?>
</div>
<!-- END CONTENT WRAPPER-->
<!-- BEGIN PAGE FOOTER -->
<div id="footer">
<?php
	//page generation start
	global $tstart;
?>
	<p class="colophon">
		<a href="http://github.com/karlstolley/course-wiki">Design</a> by 
		<a href="http://karlstolley.com/">K. Stolley</a>. 
		Powered by <a href="http://wikkawiki.org/">WikkaWiki</a> and
		<a href="http://jquery.com/">jQuery</a>. 
		Valid <a href="http://validator.w3.org/check/referer">XHTML</a> &amp; 
		<a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a>. 
	</p>
<?php
echo '<!--'.sprintf(PAGE_GENERATION_TIME, $this->microTimeDiff($tstart)).'-->'."\n";
?>
</div>
<!-- END PAGE FOOTER -->
</div>
<!-- END PAGE WRAPPER -->
</body>
</html>

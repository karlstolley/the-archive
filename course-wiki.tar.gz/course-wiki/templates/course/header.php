<?php
//initialize WikkaWiki

/*Custom variables. Edit these two lines to match the name and
brief description of your course. Leave the quotation marks.*/
$cw_name = "Course Name Here"; /*Course Name*/
$cw_tagline = "A one-sentence description of the course."; /*Brief description*/

/*Custom variables that rely on the WikkaWiki API:*/
$cw_tag = $this->GetPageTag();
$cw_title = $this->PageTitle();

/*Set a few pieces of information for page construction:*/
$message = $this->GetRedirectMessage();
$user = $this->GetUser();
$site_base = $this->GetConfigValue("base_url");

/*
Define a bunch of constants for the wiki menus;
the defaults use a lot of square brackets and things,
which can be a usability stumbling block (not to mention
something tough to design around):
*/
define('EDITLINK_TEXT', 'Edit');
define('SHOWLINK_TEXT', 'Show');
define('SHOWCODELINK_TEXT', 'Source');
define('REVERTLINK_TEXT', 'Revert');
define('CLONELINK_TEXT', 'Clone');
define('DELETELINK_TEXT', 'Delete');
define('HISTORYLINK_TEXT', 'History');

/*This line can be removed on sites that use "pretty" URLs (mod_rewrite):*/
if ( substr_count($site_base, 'wikka.php?wakka=') > 0 ) $site_base = substr($site_base,0,-16);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title><?php echo $cw_name.": ".$cw_title; ?></title>
	<base href="<?php echo $site_base ?>" />
<?php if ($this->GetMethod() != 'show' || $this->page["latest"] == 'N' || $this->page["tag"] == 'SandBox') echo "<meta name=\"robots\" content=\"noindex, nofollow, noarchive\" />\n"; ?>
	<meta name="generator" content="WikkaWiki" />
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="description" content="<?php echo $this->htmlspecialchars_ent($this->GetConfigValue("meta_description")) ?>" />

<!--
	After initial setup, copy the following lines from source view into header.php,
	overwriting lines 51 thru 65. That will reduce unnecessary server load to find these
	paths, which are the same across the entire wiki:
-->

<!--=====Begin copying=====-->
	<!-- The main stylesheet -->
	<link rel="stylesheet" type="text/css" href="<?php echo $this->GetThemePath('/') ?>/css/styles.css" media="all" />
	<!--Conditional comment to hide the iPhone CSS from IE; see http://www.boutell.com/newfaq/creating/iphone.html -->
	<!--[if !IE]>-->
	<link rel="stylesheet" type="text/css" href="<?php echo $this->GetThemePath('/') ?>/css/iphone.css" media="only screen and (max-device-width: 480px)"/>
	<!--<![endif]--> 
	<!--[if IE]>
	<link rel="stylesheet" type="text/css" href="<?php echo $this->GetThemePath('/') ?>/css/ie-styles.css" media="all" />
	<![endif]-->
	<!-- The print stylesheet -->
	<link rel="stylesheet" type="text/css" href="<?php echo $this->GetThemePath('/') ?>/css/print.css" media="print" /> 
	<!-- Favicon links -->
	<link rel="icon" href="<?php echo $this->GetThemePath('/') ?>/images/favicon.ico" type="image/x-icon" />
	<link rel="shortcut icon" href="<?php echo $this->GetThemePath('/') ?>/images/favicon.ico" type="image/x-icon" />
	<!--jQuery and site JavaScript links-->
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
	<script type="text/javascript" src="<?php echo $this->GetThemePath('/') ?>/js/site.js"></script>
<!--=====End copying=====-->

<?php
/*Set up RSS links*/

if ($this->GetMethod() != 'edit')
{
	$rsslink  = '	<link rel="alternate" type="application/rss+xml" title="'.$cw_name.': revisions for '.$cw_tag.' (RSS)" href="'.$this->Href('revisions.xml', $cw_tag).'" />'."\n";
	$rsslink .= '	<link rel="alternate" type="application/rss+xml" title="'.$cw_name.': recently edited pages (RSS)" href="'.$this->Href('recentchanges.xml', $cw_tag).'" />'."\n";
	echo $rsslink;	
}

/*
  To use WikkaWiki plugins that include additional headers, remove the PHP comment markers
  from lines 67 and 75.
*/

/*
if (isset($this->additional_headers) && is_array($this->additional_headers) && count($this->additional_headers)) 
{ 
		foreach ($this->additional_headers as $additional_headers) 
		{ 
				echo $additional_headers; 
		} 
}
*/

?>
</head>
<!--
	Create a unique class for each page; e.g., CourseHome becomes page-coursehome;
	also add a being-edited class added for styling the edit page.
-->
<body class="<?php print 'page-'.strtolower($cw_tag); ?><?php if ($this->GetMethod() == 'edit') { echo ' being-edited'; } ?>">
<!-- BEGIN PAGE WRAPPER -->
<div id="page">
<?php
//display system messages
if (isset($message) && strlen($message)>0)
{
	echo '<div class="success">'.$message.'</div>';
}
?>
<!-- BEGIN PAGE HEADER -->
<div id="header">
	<h1><a rel="home" href="<?php echo $site_base . "CourseHome"; ?>"><?php echo $cw_name;?></a></h1>
	<p class="tagline"><?php echo $cw_tagline; ?></p>
	<ul class="accessibility">
		<li><a href="#content">Skip to page content.</a></li>
		<li><a href="#course_menu">Skip to course site navigation.</a></li>
	</ul>
	<!--
		The course menu is not dynamically generated. To change it,
		edit it in header.php
	-->
	<ul id="course_menu">
		<li id="cm_home"><a href="CourseHome">Home</a></li>
		<li id="cm_calendar"><a href="CourseCalendar">Calendar</a></li>
		<li id="cm_projects"><a href="CourseProjects">Projects</a></li>
		<li id="cm_policies"><a href="CoursePolicies">Policies</a></li>
		<li id="cm_people"><a href="CourseMembers">People</a></li>
		<li id="cm_pages"><a href="PageIndex">All Pages</a></li>
	</ul>
	<!--
		The user menu is dynamically generated. To change it,
		edit the user_menu files in the /config directory.
	-->
	<?php echo $this->MakeMenu('cw_user_menu'); ?>
</div>
<!-- END PAGE HEADER -->
<!-- BEGIN CONTENT WRAPPER -->
<div id="content-wrapper">

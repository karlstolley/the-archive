$(document).ready(function() {
  var size = $(window).width(); 
  if(size>1110) { $('body').addClass('wide'); }
  $('#header').dblclick(function() {
		$('body').toggleClass('projector');
	});
});
$(window).resize(function() {
  var size = $(window).width(); 
  if(size>1110) { $('body').addClass('wide'); }
  else { $('body').removeClass('wide'); }
});

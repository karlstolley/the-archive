# Course Website Template for WikkaWiki

This repository contains template files for running a WikkaWiki installation to power course websites; for recent examples, please see:

* <http://courses.karlstolley.com/530/>
* <http://courses.karlstolley.com/561/>

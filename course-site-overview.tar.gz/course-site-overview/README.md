Course Overview Page
====================

This is a small repository containing an index file, CSS, and a few
images for the overview of all of the courses that I teach at 
Illinois Institute of Technology.

I'm using it as an example for my presentation at the March 2010 
Association of Teachers of Technical Writing conference in 
Louisville, KY.


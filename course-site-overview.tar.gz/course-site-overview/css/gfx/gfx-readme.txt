The gfx folder is where you store all of the images and artwork files called by 
CSS (as opposed to the XHTML <img /> tag).


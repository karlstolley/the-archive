function running_total(arr) {
  var total = arr.reduce(function(accum,current) {
    return accum + current;
  });
  return total;
}

// let stack = [80,56,56,28,27]; // Grab from command line
// 83,78,84,46,80
// 55,56,28,82,55,82
// 56,28,80,27,56
// 56,56,83,84,39,82
// 56,84,82,71,82
// let stack = [56,28,79,27,56].sort().reverse();
let stack = process.argv[2].split(',').sort().reverse();
let sack = new Array(stack.length);

// Set up the empty folders
for(let i = 0; i < stack.length; i++) {
  sack[i] = { max: stack[i], folders: new Array(stack.length) };
}

while(running_total(stack) > 0) {
  let total = running_total(stack);
  // Loop through each item in the stack
  for(let i = 0; i < stack.length; i++) {
    for(let n = 0; n < sack.length; n++) {
      // sack[n].max > running_total(sack[n].folders) &&
      if(isNaN(sack[n].folders[i])) {
        sack[n].folders[i] = 0; // convert empty items to 0
      }
      if (i !== n && (sack[n].max > running_total(sack[n].folders)) && (stack[i] > 0)) {
        sack[n].folders[i]++;
        stack[i]--;
      }
    }
  }
  if (total === running_total(stack)) {
    break;
  }
}

// Most of these are down to a single remainder; but one data set is all wacky:
// 56,28,80,27,56 -> always has a remainder of 23 or 25
// The single remainders (1) should be easy to handle
// Bigger remainders can probably be handled by running a modulo test to split them:
// (n - (n % 2)) / 2

console.log(running_total(stack));
console.log(stack);

if(running_total(stack) > 0) {
  console.log("We have to fix a remainder.")
  for(let i = 0; i < stack.length; i++) {
    let j,k,l;
    if(stack[i] > 0) {
      switch(i) {
        case 0:
          j = i + 1;
          k = i;
          l = i + 2;
          break;
        case 1:
          j = i + 1;
          k = i;
          break;
        case 2:
          j = i + 1;
          k = i;
          break;
        case 3:
          j = i + 1;
          k = i;
          break;
        case 4:
          j = i + 1;
          k = i;
          break;
        case 5:
          j = 0;
          k = stack.length - 1;
          break;
      }
      // Fix remainders of 1 (common, from data sets)
      if(stack[i]===1) {
        sack[i].folders[j]++; // increment own stack from next neighbor by 1
        sack[i+1].folders[j]--; // decrement
        sack[i+1].folders[k]++;
        stack[i]--;
      } else {
        console.log(`Increment record ${j}`);
        let n = stack[i];
        let m = 0;
        if (n % 2 === 0) {
          n = n / 2;
        } else {
          n = (n - (n % 2)) / 2;
          m = (n % 2);
        }
        sack[i].folders[j] += n;
        sack[i].folders[l] += (n + m);
        sack[i+1].folders[0] += (n + m);
        sack[i+1].folders[l] -= (n + m);
        sack[i+2].folders[0] += n;
        sack[i+2].folders[j] -= n;
        stack[i] = stack[i] - (2*n + m);
      }
    }
  }
}


console.log(running_total(stack));
console.log(stack);
for(let n = 0; n < sack.length; n++) {
  console.log(`Instructor ${n+1}: ${running_total(sack[n].folders)} (Max: ${sack[n].max}); ${sack[n].folders}`);
}


/*
// State of sack after first full round of distribution
[
  { max: 5, folders: [ 0, 1, 1, 1 ] }, // 3
  { max: 7, folders: [ 1, 0, 1, 1 ] }, // 3
  { max: 10, folders: [ 1, 1, 0, 1 ] }, // 3
  { max: 12, folders: [ 1, 1, 1, 0 ] } //3
]
// State of stack after first full round of distribution
// [2,4,7,9]
*/

// Is this the instructors own papers?
// if sack[i]
// Can the instructor still take more papers?
// if sack[i].max < running_total(sack[i].folders)

// loop for as long as there are still papers
/*
while (total > 0) {
  for(let i = 0; i < stack.length; i++) {
    // distribute from stack[0], then stack[1], stack[2] ...
     if(sack[i] > 0) {

     }


  }
*/

/*
  // update total
  total = stack.reduce(function(running_total,current_value) {
    return running_total + current_value
  });
}
*/
// need to loop for the sum of papers
// need to cycle trough the array and
// reduce the paper stacks as they are
// assigned -> array of 1s with pop() ?
// or an assign(stack, sack)
// check for remaining papers
// check that assignments don’t exceed
// number of papers
//sack [
//  [ , , ] // zero for own
// ...
// ]

//Papers can’t be assigned to their own assigner; e.g., stack[0] can’t be added to sack[0]

// Total of stack[n] === sack[n]

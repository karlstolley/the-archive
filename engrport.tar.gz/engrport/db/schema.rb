# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20150225062546) do

  create_table "activities", force: :cascade do |t|
    t.string   "title"
    t.datetime "date"
    t.string   "theme"
    t.text     "description"
    t.datetime "created_at",  null: false
    t.datetime "updated_at",  null: false
  end

  create_table "experiences", force: :cascade do |t|
    t.string   "role"
    t.text     "reflection"
    t.integer  "activity_id"
    t.integer  "student_id"
    t.datetime "created_at",  null: false
    t.datetime "updated_at",  null: false
  end

  add_index "experiences", ["activity_id"], name: "index_experiences_on_activity_id"
  add_index "experiences", ["student_id"], name: "index_experiences_on_student_id"

  create_table "experiences_portfolios", id: false, force: :cascade do |t|
    t.integer "experience_id"
    t.integer "portfolio_id"
  end

  add_index "experiences_portfolios", ["experience_id"], name: "index_experiences_portfolios_on_experience_id"
  add_index "experiences_portfolios", ["portfolio_id"], name: "index_experiences_portfolios_on_portfolio_id"

  create_table "portfolios", force: :cascade do |t|
    t.string   "url"
    t.integer  "student_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.string   "descriptor"
  end

  add_index "portfolios", ["student_id"], name: "index_portfolios_on_student_id"

  create_table "students", force: :cascade do |t|
    t.string   "name"
    t.string   "cwid"
    t.string   "major"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

end

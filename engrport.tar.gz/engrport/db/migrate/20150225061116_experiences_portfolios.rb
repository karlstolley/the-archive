class ExperiencesPortfolios < ActiveRecord::Migration
  def change
    create_table :experiences_portfolios, id: false do |t|
      t.belongs_to :experience, index: true
      t.belongs_to :portfolio, index: true
    end
  end
end

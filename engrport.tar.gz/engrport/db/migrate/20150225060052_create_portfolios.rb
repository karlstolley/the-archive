class CreatePortfolios < ActiveRecord::Migration
  def change
    create_table :portfolios do |t|
      t.string :url
      t.belongs_to :student, index: true

      t.timestamps null: false
    end
  end
end

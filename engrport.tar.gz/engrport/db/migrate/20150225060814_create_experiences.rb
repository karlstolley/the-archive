class CreateExperiences < ActiveRecord::Migration
  def change
    create_table :experiences do |t|
      t.string :role
      t.text :reflection
      t.belongs_to :activity, index: true
      t.belongs_to :student, index: true

      t.timestamps null: false
    end
  end
end

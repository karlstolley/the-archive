class AddDescriptorToPortfolio < ActiveRecord::Migration
  def change
    add_column :portfolios, :descriptor, :string
  end
end

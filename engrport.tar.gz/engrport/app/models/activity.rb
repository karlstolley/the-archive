class Activity < ActiveRecord::Base
  has_many :experiences
end

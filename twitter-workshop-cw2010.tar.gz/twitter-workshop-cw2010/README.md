Twitter to Infinity and Beyond
==============================

These files and examples were used for a workshop, "Twitter to Infinity and 
Beyond," at the Computers and Writing Conference, Purdue University, May 2010.

All of the files are in a root web folder called ##htdocs/##, for use with the
XAMPP Web server (see http://www.apachefriends.org/en/xampp.html for details). 
It is advisable to rename the default ##htdocs/## folder that comes with XAMPP
to ##htdocs-original/##, and simply copy over the ##htdocs/## folder from this
project in its place. That way, if you ever need to access any of the setup
pages that ship with XAMPP, you can just rename folders accordingly.

The content of the examples are licensed under Creative Commons, and the scripts
and other source code is available under an MIT-style license (see below and the
accompanying LICENSE.txt file.


The Rapid Prototyping Kit (RPK)
===============================

The files for this workshop make use of the RPK,
http://github.com/karlstolley/rpk/

The Rapid Prototyping kit is a set of files for quickly building Web pages using
XHTML 1.0 Strict, Cascading Stylesheets (CSS), and JavaScript.


Licensing
=========

This version of the RPK includes the jQuery JavaScript Library, http://jquery.com,
which is licensed under an MIT-style License, as is the RPK itself.
(See the htdocs/LICENSE.txt and htdocs/js/JQUERY.LICENSE.txt files.)

It also includes the SimplePie PHP object for parsing RSS/Atom. (See the 
htdocs/SIMPLEPIE.LICENSE.txt file.)

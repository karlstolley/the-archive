/*Twitter @Anywhere - Hovercards and Custom Tweetbox*/
twttr.anywhere(function(twitter) {
	twitter.hovercards();
	twitter("#tbox").tweetBox({
		height: 100,
		width: 400,
		/*Setting defaultContent as
		defaultContent: window.location.href 
		will automatically put the page's 
		URL in the Tweet box*/
		defaultContent: window.location.href,
		label: "Tweet about this page:"
	});
});
/*Twitter @Anywhere - Hovercards*/
twttr.anywhere(function(twitter) {
	twitter.hovercards(); /*Create Twitter links and hovercards out of all @twitter names*/
});

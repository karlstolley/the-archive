/*Twitter @Anywhere - Hovercards and Tweetbox*/
twttr.anywhere(function(twitter) {
	twitter.hovercards();
	/*Add a TweetBox to <div id="tbox"></div>*/
	twitter("#tbox").tweetBox({
		height: 100, /*Height of box, in pixels.*/
		width: 400 /*Width of box, in pixels.*/
	});
});
/*Twitter @Anywhere - Hovercards, Tweetbox, and Bit.ly*/

/*Bit.ly Script*/
var shorty = new Array();
BitlyCB.shortenResponse = function(data) {
	var first_result;
	// Results are keyed by longUrl, so we need to grab the first one.
	for (var r in data.results) {
		first_result = data.results[r]; break;
	}
	for (var key in first_result) {
		shorty['params'] += key + ":" + first_result[key].toString() + "\n";
		shorty['shortUrl'] = first_result['shortUrl'].toString();
	}
}
BitlyClient.addPageLoadEvent(function(){
	BitlyClient.shorten(window.location.href, 'BitlyCB.shortenResponse');
});

/*Twitter @Anywhere Script; Takes shorty array from Bit.ly above*/
twttr.anywhere(function(twitter) {
	twitter.hovercards();
	twitter("#tbox").tweetBox({
		height: 100,
		width: 400,
		/*Set defaultContent: to 
		shorty['params']
		to see other responses from bit.ly*/
		defaultContent: shorty['shortUrl'],
		label: "Tweet about this page:"
	});
});
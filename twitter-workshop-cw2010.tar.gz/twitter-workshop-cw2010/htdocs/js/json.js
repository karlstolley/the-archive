var tweetsearch = "#cw2010";
var tweetnumber = 20;
$.getJSON('http://search.twitter.com/search.json?q='+escape(tweetsearch)+'&rpp='+tweetnumber+'&callback=?', function(data) {
	$.each(data.results, function(i, item) {
		$('#tweetstream').append(
		'<div class="tweet">' +
		'<p class="post">' +
		'<a href="http://twitter.com/' + item.from_user + '">' +
		'<img height="40" width="40" alt="Profile image." src="' + item.profile_image_url + '" />' +
		'@' + item.from_user + '</a>: ' + item.text +
		'</p>' +
		'<p class="posted">' + item.created_at + '</p>' +
		'</div>');
	});
});
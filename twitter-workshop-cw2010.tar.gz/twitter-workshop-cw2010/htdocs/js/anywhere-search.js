/*Twitter @Anywhere - Hovercards and Tweetbox*/
twttr.anywhere(function (twitter) {
	
	/*Put the hovercard on the profile image;
	grab the profile name from the title=""
	attribute on the <img /> tag*/
	twitter("#tweetstream img").hovercards({
		username: function(node) {
			return node.title; //Grab the username from the title attr
		}
	});

	/*Give users the option to connect up with Twitter;
	makes the Hovercards more awesome.*/
	twitter("#tconnect").connectButton();
	
	/*Add a TweetBox to <div id="tbox"></div>*/
	twitter("#tbox").tweetBox({
		height: 100, /*Height of box, in pixels.*/
		width: 400 /*Width of box, in pixels.*/
	});

});
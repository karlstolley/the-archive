<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Twitter SimplePie Example</title>
	<script type="text/javascript" charset="utf-8" src="http://bit.ly/javascript-api.js?version=latest&login=YOUR_LOGIN_HERE&apiKey=YOUR_KEY_HERE"></script>
	<!--Place script link to Twitter @anywhere API here-->
	<script type="text/javascript" src="http://platform.twitter.com/anywhere.js?id=YOUR_KEY_HERE&amp;v=1"></script>
	<!--Script link to local JavaScript; change this file for different demos-->
	<script type="text/javascript" src="js/anywhere-search.js"></script>
	<!--Some CSS to make things more interesting-->
	<link rel="stylesheet" type="text/css" href="styles.css" />
</head>
<body>
<div id="tweetstream" class="anywhere">
<?php include 'simplepie.class.php'; //This includes the SimplePie class ?>
<?php

/*Set up the search, including the terms and the number of Tweets to pull*/
$tweetsearch = '#cw2010'; 	//Tweets to search for; can be the same as what you'd
							//enter into the search box at search.twitter.com, e.g.,
							// #cw2010 
							//or
							// computers and writing
$tweetnumber = 5; 			//Number of Tweets to return

/*Now the hardcore SimpliePie code begins*/
$tweets = new SimplePie(); //Create a new instance of the SimplePie object

/*Set the feed URL, using the variables set above*/
$tweets->set_feed_url('http://search.twitter.com/search.atom?q='.urlencode($tweetsearch).'&rpp='.$tweetnumber);

/*Disable caching*/
$tweets->enable_cache(false); //For testing purposes only

/*	
	NOTE: Caching speeds up performance, but the cache location must
	exist and writable by the Web server; in this case
	a /cache folder is expected off of /htdocs (remove the // to use):
*/
//$tweets->$feed->set_cache_location($_SERVER['DOCUMENT_ROOT'] . '/cache');

/*Initialize the feed so we can now do something with it*/
$tweets->init();
echo "<h1>".$tweets->get_title()."</h1>"; //Output the feed title as the h1 for the page

/*Loop through all of the items returned by the Twitter search API:*/
foreach($tweets->get_items() as $tweet) {
	$twposter = $tweet->get_author(); //Grabs the author information; must be broken down further
	$twname = twrealname($twposter->get_name()); //Function below pulls out real name
	$twuser = twusername($twposter->get_name());
	$twavatar = $tweet->get_links('image'); //Grab the Tweeter's avatar
	$twtweet = $tweet->get_content(); //Grab the HTML content from the feed
	$twposted = $tweet->get_date(); //Date can be formatted using docs at http://php.net/date
	
	/*Output all of this information as HTML*/
	echo 	"<div class=\"tweet\">\n" .
			"<p>".
			"<img src=\"".$twavatar[0]."\" alt=\"Profile image for ".$twuser."\" title=\"".$twuser."\" />".
			"<a href=\"".$twposter->get_link()."\">".$twname."</a>: ".
			$twtweet.
			"</p>\n" .
			"<p class=\"posted\">".$twposted."</p>\n".
			"</div>";
}

/*And we're done...*/

/*This is just a little custom function that pulls out the Twitter
users name from the value returned by the feed:*/
function twrealname($twname) {
	$twname = explode("(", $twname); //break the name at the parentheses
	$twname = rtrim($twname[1], ")"); //trim off the closing parentheses
	return $twname; //Spit back out the name
}

function twusername($twuser) {
	$twuser = explode (" (", $twuser);
	$twuser = "@".$twuser[0];
	return $twuser;
}
	
?>
</div>
<div id="tbox"></div>
<div id="tconnect"></div>
</body>
</html>
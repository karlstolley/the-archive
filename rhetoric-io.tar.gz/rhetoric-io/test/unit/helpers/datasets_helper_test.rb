require 'test_helper'

class DatasetsHelperTest < ActionView::TestCase
end

# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Rhetoricio::Application.config.secret_token = '77c8dacc45d6838a2c15a6c885f5563659813021b75915c314c8b326da44b701691066ea4f2c9a01be79e27f01eabdf475035c3032a771b9e092d72024073c19'

---
title: About
description: A classically trained rhetorician with a GitHub account.
layout: default
classes: textheavy
---

My work strikes a balance between the humanities and digital technology to change how people communicate and design across networked screens.

I’m Associate Professor of Digital Writing and Rhetoric in the Humanities Department at the Illinois Institute of Technology in Chicago. As a humanities-based theorist and creator of digital media, I study and teach interdisciplinary approaches to design and communication problems in a screen-saturated culture.

My research develops theories and applied practices of digital production that account for the hidden layers of protocols, programming languages, data stores, and operating systems that shape the appearance and interactivity of screen artifacts.

My research builds upon ancient and modern rhetorical theory, the design arts (especially graphic and interaction design), human-computer interaction, and media and cultural theory. I have published a book on source-level web writing and design. My shorter works have appeared in journals and edited collections in rhetoric, communication, and the digital humanities. I am currently writing [a book on modular web development](http://mwd.karlstolley.com/) that examines the stack of technologies and production problems behind sophisticated systems for web communication.

In addition to academic research projects, I regularly take on digital design and development projects. I have done award-winning digital design work for *Kairos: A Journal of Rhetoric, Technology, and Pedagogy* and recently completed programming and designing for the Newberry Library a web application in the Ruby on Rails framework.

I teach a variety of courses, including web design and web application development, humanizing technology, and the culture of open source. In collaboration with librarians in IIT’s Paul V. Galvin Library, I maintain a lab of nineteen dual-screen workstations that run Linux and other free and open-source software to give my students access to leading-edge technology that isn’t easily found anywhere else on campus.

The ideas derived from my research and production work coupled with the infrastructure of my lab inspire me to push my course development into new topic areas, such as [application programming interfaces](http://courses.karlstolley.com/api/). I am also inspired by the success of my former students who have gone on to build careers in the university as well as the private sector with companies such as 37signals, YouTube, Encyclopedia Britannica, and the Mozilla Foundation.

My research, production work, and teaching illustrate the possibilities for a technology-infused approach to the humanities. But I am equally committed to a humanities-infused approach to technology: I consider it a special honor that I am regularly asked to review books for the Pragmatic Bookshelf, a technology press that publishes books for programmers and developers.

# In The Third Person

*Sometimes I'm asked for a short biographical statement, so I cannibalize from some of this one:*

Karl Stolley is Associate Professor of Digital Writing & Rhetoric and co-director of graduate studies in the Department of Humanities at the Illinois Institute of Technology in Chicago. Stolley regularly teaches courses on web design and development, information architecture, and humanizing technology. He directs Gewgaws Lab (http://gewga.ws), a digital design and development research group and physical lab space dedicated to investigating open-source technologies. Stolley is the author of the book *How to Design and Write Web Pages Today* (Greenwood Press 2011), which makes the argument for writers designing and developing websites at the source-code level according to Web standards. His publications have appeared in such journals as *IEEE Transactions on Professional Communication*, *Journal of Business and Technical Communication*, and *Kairos: A Journal of Rhetoric, Technology, and Pedagogy*. Stolley earned his doctorate from the rhetoric program at Purdue University in West Lafayette, IN, where he was webmaster of the world-renowned Purdue Online Writing Lab (OWL). He has also served as interface editor for *Kairos* and led its redesign, which was awarded the Council of Editors of Learned Journals’ Best Journal Design Award in 2008—the first Web-based journal to receive that distinction. Stolley maintains a Web presence at http://karlstolley.com/ and is on Twitter @karlstolley.

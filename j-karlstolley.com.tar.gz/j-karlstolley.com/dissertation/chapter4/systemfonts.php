<?php
include('functions.php');
show_header("System Fonts");
show_navigation();
?>

<div id="content">
  <div id="contenthead">
    <h2><span></span>Visual Rhetorical Task:</h2>
    <p>Present CSS typography for XHTML text.</p>
  </div>
  <div id="description">
    <h3><span></span>Description</h3>
    <p>Using CSS to define a family of fonts via the <code>font-family</code> property
      seems like it should be a straightforward design choice. But as the simulated
      examples in the Renderings area show, even across operating systems that
      have the font of a digital producer’s choice, there are considerable differences
      both in terms of how a font actually looks and, more importantly, whether
      it is even legible at certain small sizes.</p>
    <p>In both the Mac and Windows examples, Verdana is only somewhat legible
      at 9 pixels and above, while the 8- and 7-pixel sizes require font smoothing.
      Verdana is also a unique font in that it changes character dramatically
      across sizes, particularly when no smoothing is present: from the harsh
      angles of the 10-pixel size in Windows, to the rounded bubble-like forms
      of 16 pixels, to the sudden shift to what almost looks like bold text at
      17 pixels. And all sizes of Verdana smoothed in OS X appear bolder than
      the Window’s counterparts.</p>
    <p>Font smoothing also aids in the readability and distinction between italic
      and normal faces for sans-serif fonts (Renderings 3 and 4), versus a serif
      font like Georgia, whose italic face is distinct even without font smoothing
      (Rendering 5). <a href="examples/systemfonts.htm">A live page of examples</a> shows
      how fonts render on your system (if Verdana is not available, a serif font
      will display; if Georgia is missing, a sans-serif font will display so
      that it will be more readily obvious if the font is missing).</p>
  </div>
  <div id="examples">
    <div id="renderings">
      <hr />
      <h3><span></span>Renderings:</h3>
      <h4>1. Verdana in Windows XP: ClearType, Standard, None</h4>
      <img src="images/win-verdana.jpg" height="279" width="500" alt="Verdana rendered under Windows XP's three different font-smoothing settings." />
      <h4>2. Verdana in Mac OS X: Smoothing off under 12 pixels, 4 pixels</h4>
      <img src="images/mac-verdana.jpg" height="281" width="331" alt="Verdana rendered under Mac OS X's font-smoothing for font sizes greater than 12 pixels." />
      <h4>3. Verdana Italic in Windows XP: ClearType, Standard, None</h4>
      <img src="images/win-verdana-ital.jpg" height="279" width="500" alt="Verdana italic rendered under Windows XP's three different font-smoothing settings." />
      <h4>4. Verdana Italic in Mac OS X: Smoothing off under 12 pixels, 7 pixels</h4>
      <img src="images/mac-verdana-ital.jpg" height="181" width="257" alt="Verdana rendered under Mac OS X's font smoothing for font sizes greater than 12 pixels." />
      <h4>5. Georgia and Georgia Italic in Windows XP: No smoothing</h4>
      <img src="images/win-georgia.jpg" height="280" width="272" alt="Georgia and Gerogia italic rendered under Windows XP without any font smoothing." />
      <?php show_examplelink("View Renderings Only"); ?>
      <hr />
    </div>
    <div id="quanta">
      <h3><span></span>Quanta</h3>
      <h4>1., 2.</h4>
      <div class="code">
        <pre><code>/* CSS */<br />p { font-family: Verdana, sans-serif;}</code></pre>
      </div>
      <h4>3., 4.</h4>
      <div class="code">
        <pre><code>/* CSS */<br />p {<br />  font-family: Verdana, sans-serif;<br />  font-style: italic;<br />}</code></pre>
      </div>
      <h4>5.</h4>
      <div class="code">
        <pre><code>/* CSS */<br />p { font-family: Georgia, serif; }</code></pre>
      </div>
    </div>
    <div id="discussion">
      <h3><span></span>Discussion</h3>
      <p>Fonts are one of the first visual choices that digital producers learn
        how to implement in Word documents and elsewhere; and while Word is not
        as readily capable of “packaging” fonts with documents as Adobe Acrobat
        and Adobe (formerly Macromedia) Flash, the expectation that beginning
        producers have of being able to choose whichever fonts they wish is shared
        by advanced producers, too.</p>
      <p>Basic CSS text styling like bold, italics, line-height (leading), and
        first-line indentation are all well supported in even the oldest CSS-capable
        browsers (like Netscape 4). But the primary visual quanta of XHTML and
        CSS typography, font files and font smoothing, are dependent on a user’s
        computer, not her browser or the producer of a digital artifact (there
        is no method of transferring font files, which must be installed on a
        user’s system, and not merely downloaded).</p>
      <p>The choice of fonts via CSS properties is one of the more complex areas
        of networked digital production because there are so many contingencies
        governing font display of XHTML text, almost all of which are beyond
        the digital producers’s control. The first and most clear contingency
        is whether or not a person reading a CSS-enhanced XHTML page has a particular
        font installed on her system. CSS addresses this contingency by lists
        of fonts: CSS-capable browsers move down the list of fonts in either
        the <code>font</code> or <code>font-family</code> properties, and stop
        and display the first match found on the user’s system. For example:</p>
      <div class="code">
        <pre><code>p { font-family: Verdana, Arial, Helvetica, sans-serif; }</code></pre>
      </div>
      <p>If a machine has Verdana, the Web browser will use Verdana; if it has
        Arial, the browser will use Arial, and so on until a generic alternative, <code>sans-serif</code>,
        tells the system to use whatever sans-serif font it has on hand. The
        Verdana and Arial fonts are commonly installed on both Mac and Windows
        computers; however, there are other commonly installed fonts on each
        system that look very similar, but have different names: particularly
        Lucida Console on Windows, and Monaco on Mac. To account for both of
        these systems, an artful visual rhetorical choice would be to offer both
        in the CSS; the order does not matter, of course, because a Mac system
        will stop at Monaco, and Windows will stop at Lucida Console:</p>
      <div class="code">
        <pre><code>p { font-family: &quot;Lucida Console&quot;, Monaco, monospace; }</code></pre>
      </div>
      <p>But as the simulated renderings above show, even if a machine detects
        a particular font, it is impossible to predict how the font will actually
        render; Windows XP, for example, has two “font smoothing” settings that
        can be turned on: a “Standard” setting, which provides anti-aliasing
        on fonts sized larger than 17 pixels and smaller than 9 pixels (fonts
        between 9 and 17 pixels are rendered without any smoothing); and a “ClearType”
        setting, which provides anti-aliasing on all font sizes. Macintosh OS
        X has 5 settings—“Automatic,” “Standard,” “Light,” “Medium,” and “Strong”
        (none of which, from the experience of preparing the simulated renderings
        on this page, seems to differ greatly from another). OS X also offers
        users the ability to turn off font smoothing for smaller font sizes.
        The maximum size that can be turned off is 12, though it is unclear from
        the Mac Appearance interface what unit of measure is associated with
        12; testing suggests pixels.</p>
      <p>Font smoothing is entirely up to a user, and it is probably for the
        best that no way exists for a Web designer to insist upon or override
        it, as smoothing is actually established independent of the Web browser.
        (The new Internet Explorer 7, IE7, will allow users, though not a producer,
        to turn on ClearType from within the browser: a privilege IE7 enjoys
        because it is tied so closely to the Windows operating system, the very
        reason that IE is notorious for being a computer security risk).</p>
      <p>Beyond the choice of a font, the issue of sizing is even more interesting;
        the examples I have provided in the Renderings area are all sized in
        exact pixels in the CSS <code>font-size</code> property. This is the
        most reliable measure of font sizes (in that a pixel is a pixel, no matter
        what system a page is displayed on). However, Internet Explorer 6 and
        earlier will not allow users to resize fonts specified in exact pixels—which
        is a potential accessibility concern for visually impaired users (IE
        7 technically does not resize exact-pixel sizes, either, but rather magnifies
        the entire page—design and all.)</p>
      <p>The alternative to the IE problem is to offer font sizes relatively,
        either in percentage (<code>%</code>) or <code>em</code> units, or as
        font size keywords like <code>x-small</code>, <code>small</code>, <code>medium</code>,
        etc. All relative sizes are determined with respect to a base font-size
        in a given browser, which a user can adjust and which varies by default
        from browser to browser, platform to platform. Relative font sizes make
        type display unpredictable, which as the renderings above show presents
        a serious problem at smaller sizes: at some percentage or fraction of
        an em, displayed fonts would begin to look like the illegible 6-, 5-,
        and 4-pixel examples.</p>
      <p>The most significant advantage of relative font sizes is they allow
        users to resize text in older versions of Internet Explorer. As with
        many design choices that go into emergent visual rhetoric, font size
        units must be decided by weighing audience needs against the ideal visual
        experience a designer hopes to create. Particularly in the case of an
        unsmoothed rendering of the Verdana font, which varies so much in its
        character between the 9px and 16px rendering, some designers are more
        reluctant to give up size control (which is slightly easier to do with
        the Georgia font, which looks pretty much the same at most sizes—another
        visual rhetorical factor that should figure into choosing a font and
        sizing method).</p>
      <p>Regardless of sizing choices, fonts and font sizes declared in CSS are
        arguably the least predictable aspect of Web design. And while the CSS
        font properties allow the listing of alternative fonts, there is no corresponding
        option to provide alternatives for sizing. (That is, unless one provides
        entire alternative stylesheets—which would solve the resizing problem
        in Internet Explorer: just create a large-type or flexible font sheet;
        unfortunately, to provide accessible alternative stylesheets, one must
        use either JavaScript or a server-side solution because, again, versions
        of Internet Explorer 6 and earlier do not provide a means—as Firefox
        and other browsers have built-in—to switch stylesheets using the browser.)</p>
    </div>
  </div>
</div>
<?php show_footer(); ?>

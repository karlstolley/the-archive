<?php
include('functions.php');
show_header("Guide to Page Features");
show_navigation();
?>

<div id="content">
  <div id="contenthead">
    <h2 id="taskfeatures"><span></span>Guide to Task Page Features</h2>
    <p>A brief statement of the task appears here.</p>
  </div>
  <div id="description">
    <h3><span></span>Description</h3>
    <p>This area describes the examples in the Renderings area as they would
      appear under certain viewing conditions, and briefly describes the difference
      between examples.</p>
  </div>
  <div id="examples">
    <div id="renderings">
      <hr />
      <h3><span></span>Renderings:</h3>
      <p>The Renderings area contains multiple renderings that address the visual/rhetorical
        design task in different ways. Occasionally, the renderings are simulated
        (and are indicated as such). For all renderings, live and simulated,
        a link appears at the bottom of this area to view the renderings on a
        separate page:</p>
      <p class="renderlink"><a href="#renderingslink">View Renderings Only</a></p>
      <hr />
    </div>
    <div id="quanta">
      <h3><span></span>Quanta</h3>
      <p>The Quanta area presents the entire collection of individual components
        that go into each Rendering; these include listings of example code as
        well as links to individual single-media files (like JPEG images or Flash
        movies) and other stand-alone quanta.</p>
      <p>Code that changes from example to example in any way is highlighted
        to simplify comparison:
      <div class="code">
        <pre><code>&lt;!--XHTML Code--&gt;
<strong>&lt;p&gt;</strong>The paragraph tags are different.<strong>&lt;/p&gt;</strong></code></pre>
      </div>
    </div>
    <div id="discussion">
      <h3><span></span>Discussion</h3>
      <p>The Discussion describes the visual/rhetorical and technological implications
        of the task, and the technological and rhetorical considerations involved
        in each example Rendering. Immmediately below the discussion area is
        a list of links for accessing the page’s Web URL, the stand-alone renderings
        page, a PDF screen capture for commenting purposes, and a PNG screen
        capture for archiving the look of the pages in 2007 technology (the PNG
        screen captures are the basis for the PDFs). </p>
    </div>
  </div>
</div>
<div id="footer">
  <ul>
    <li><a href="http://www.karlstolley.com/dissertation/chapter4/pagefeatures.htm">URL:
        http://www.karlstolley.com/dissertation/chapter4/pagefeatures.htm</a></li>
    <li><a href="#renderingslink">Renderings Only</a></li>
    <li><a href="pdf/pagefeatures.pdf">PDF Screen Capture For Commenting</a></li>
    <li><a href="png/pagefeatures.png">Archived Page Image</a></li>
  </ul>
</div>
</div>
</body></html>
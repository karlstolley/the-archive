<?php
include('functions.php');
show_header("Introduction");
show_navigation();
?>

<div id="content">
  <div id="contenthead">
    <h2 id="intro"><span></span>Introduction</h2>
  </div>
  <div id="examples">
    <div id="discussiononly">
      <p>This chapter presents a series of visual/rhetorical design tasks, highlighting
        the rhetorical and technological decision-making that each requires in
        order to emerge from networked digital production. Each task is as simple
        and abstract as possible: “simple” in the sense that each task could
        reasonably be expected to be a part of any Web page; “abstract” in that
        each task is treated apart from other visual elements of page design,
        which would necessarily add additional layers of complexity to the choices
        going into Web production. However, as the coordinated example demonstrates,
        any of the task solutions in this chapter can work on the same page,
        without disrupting each other.</p>
      <p>There are often many possible solutions to any given design task in
        the Web medium that, under certain viewing conditions, appear identical.
        Throughout this chapter, there are numerous renderings that exhibit no
        visible difference whatsoever from other renderings on the same page.
        But each example responds to different readers’ technological conditions,
        and thus emerges in very different ways. Some of the solutions, like
        those to display a red square, could be combined to address multiple
        viewing contingencies. Others tasks, like replacing XHTML text with advanced
        typography, require the choice of one method over another. In some methods,
        the “best” solution with regard to the technology’s sustainability is
        the worst solution rhetorically, as in using the &lt;object&gt; tag to
        load content images—the more sustainable technological method of loading
        any media content (from images to Flash movies), but which will fail
        to load images in all versions of Internet Explorer, making it an ineffective
        visual rhetorical choice. And some tasks are only possible in conjunction
        with the choices made regarding other tasks, such as when applying a
        designed treatment to content images loaded in the image tag.</p>
      <p>Then there are the tasks, like adding richly descriptive structure to
        a page or designing layouts that function independently of content, that
        can be addressed in multiple ways and seem, again, to have the same exact
        visual effect in a contemporary, compliant browser but that vary significantly
        for older or alternative equipment. Occasionally there are methods, like
        that of declaring a page’s character encoding, that are not as much about
        choice among many alternatives as they are about a digital producer’s
        being literate with the medium and choosing correctly (which means, in
        the case of character encoding in the WYSIWYG editor Dreamweaver, choosing
        something other than Dreamweaver’s default). </p>
      <p>But for many, if not all, of the tasks presented in this chapter, the
        amount of control a digital producer has over page design is ultimately
        nowhere near the amount of control an end user’s device has (throughout
        the chapter, as in the rest of the dissertation, I refer to people as
        “users” in relation to their technology, and as “readers” in relation
        to their experience of a digital production). For just one example, the
        most talented digital producer cannot force a user’s device to display
        images if it is unable, or configured by the user not to.</p>
      <p>In the methods of networked digital production presented here, a rhetorical,
        artful producer would choose among different methods of production for
        each task and settle on the one or two that best serve her rhetorical
        purposes as well as the needs and contingencies of a variety of users.
        In other words, this imagined producer would leave as little to chance
        as possible, enabling many alternative experiences of the artifact she
        creates.</p>
      <p>Where chance erupts, then, is both the user’s body, particularly in
        case of blindness, and on the user’s machine: different operating systems,
        versions of various browsers, plus a wide variety of system settings,
        such as font smoothing or even the installation of various fonts. Given
        that users may not even know that there are multiple contingencies in
        their control and that the sheer number of contingencies make it impossible
        for a digital producer to account for them all, the production method
        examples offered in this chapter share a few basic assumptions:</p>
      <ul>
        <li>that all browsers should be served the same XHTML 1.0 Strict and
          CSS level 2; no server-side “sniffing,” where a Web server attempts
          to identify the make and model of a user’s browser, is employed.</li>
        <li>that the production methods provide a readers an experience without
          forcing them to choose between, say, a text-only version of a site
          and a fully graphical one. The emergent, networked methods presented
          here adjust to the readers’ technological conditions—some gracefully,
          others not—providing, in the best cases, the rhetorically effective
          illusion that each page was created especially for each reader’s viewing
          conditions. (This is sort of like the messages that TV stations informing
          viewers that “This movie has been modified from its original version.
          It has been formatted to fit your screen.”—but, in the Web medium,
          without the explicit message explaining what has happened).</li>
        <li>that the preferred solutions to each problem are arrived at through
          code literacy and respect W3C standards for XHTML and CSS, negotiated
          against the pragmatic rhetorical situation of users equipped with browsers
          that ignore or misinterpret W3C standards.</li>
      </ul>
      <!--<p>Each task page has a one-sentence statement of the task and a Renderings
        area that shows either live or simulated renderings. Each Renderings
        area is accompanied by a Description area that is meant to both describe,
        briefly, what can be seen, or to describe to non-CSS, non-image browsers
        what would be seen otherwise. Below the Renderings is an area called
        Quanta, which has all of the code and single-media files (images, Flash
        movies, extended source code) that are networked into each Rendering.
        Finally, there is a Discussion area that more thoroughly explains the
        production decisions and implications in each example from the Renderings
        area and makes explicit the role of rhetorical and technological considerations
        that must figure in even these simple visual/rhetorical design tasks.</p>-->
    </div>
  </div>
</div>
<?php show_footer_ne(); ?>

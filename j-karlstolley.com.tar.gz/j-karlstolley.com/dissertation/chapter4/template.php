<?php
include('functions.php');
show_header("Coordinated Example");
show_navigation();
?>

<div id="content">
  <div id="contenthead">
      <div id="contenthead">
    <h2 id="taskfeatures"><span></span>Visual/Rhetorical Task Page Features</h2>
  </div>
    <p>Incorporate image treatment, text replacement, and flexible layout.</p>
  </div>
  <div id="description">
    <h3><span></span>Description</h3>
    <p><!--Description of renderings goes here.--></p>
  </div>
  <div id="examples">
    <div id="renderings">
      <hr />
      <h3><span></span>Renderings:</h3>
      <div class="neutral">
	   <h4>1.</h4>
	  <div id="coordinated1">
	  <h2 class="photography"><span></span>Photography</h2>
	  <img src="images/facepot.jpg" height="267" width="200" alt="Photograph of a stone face among plants." />
	  <p class="caption">This stone face and foliage were photographed at the Harry P. Leu botanical gardens in Orlando, Florida.</p>
	  <ul class="imageinfo">
	  <li>Date Photographed: 10/19/2005</li>
	  </ul>
	  </div>
	  <h4>2.</h4>
	  <div id="coordinated2">
  	  <h2 class="photography"><span></span>Photography</h2>
	  <img src="images/facepot.jpg" height="267" width="200" alt="Photograph of a stone face among plants." />
	  <p class="caption">This stone face and foliage were photographed at the Harry P. Leu botanical gardens in Orlando, Florida.</p>
	  <ul class="imageinfo">
	  <li>Date Photographed: 10/19/2005</li>
	  </ul>
	  </div>
	  <h4>3.</h4>
	  <div id="coordinated3">
      <h2 class="photography"><span></span>Photography</h2>
	  <img src="images/facepot.jpg" height="267" width="200" alt="Photograph of a stone face among plants." />
	  <p class="caption">This stone face and foliage were photographed at the Harry P. Leu botanical gardens in Orlando, Florida.</p>
	  <ul class="imageinfo">
	  <li>Date Photographed: 10/19/2005</li>
	  </ul>
	  </div>
	  </div>
    </div>
    <div id="quanta">
      <h3><span></span>Quanta</h3>
      <h4>1. <!--Description--></h4>
	  <!--Use undordered list/list item tags for different types of quanta-->
      <div class="code">
        <pre><code><!--Sample code (in entities)--></code></pre>
      </div>
    </div>
    <div id="discussion">
      <h3><span></span>Discussion</h3>
      <p><!--Discussion goes here.--></p>
    </div>
  </div>
</div>

<?php show_footer(); ?>

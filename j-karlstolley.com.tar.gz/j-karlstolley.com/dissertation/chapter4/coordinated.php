<?php
include('functions.php');
show_header("Coordinated Example");
show_navigation();
?>

<div id="content">
  <div id="contenthead">
    <h2><span></span>Visual/Rhetorical Task Page Features</h2>
    <p>Coordinate image treatment, text replacement, and flexible layout together.</p>
  </div>
  <div id="description">
    <h3><span></span>Description</h3>
    <p>The renderings on this page demonstrate a progression from a basic, unstyled
      XHTML presentation (Rendering 1) of what might be the beginning of a photography
      portfolio. The same XHTML is used in all three renderings.</p>
    <p>Renderings 2 and 3 make use of image replacement on the “Photography”
      header; image replacement is preferable to sIFR because the replaced image
      includes an irregularly-shaped background and text that is rotated a few
      degrees counter-clockwise (effects not currently achievable with sIFR).</p>
    <p>Renderings 2 and 3 also use CSS positioning and text treatment on the
      photo caption and image information of “Date Photographed.” Rendering 3
      also builds on Rendering 2, adding a dotted line to the top of the flexible
      container, and moving the header slighlty above the top of the container,
      so that only part of the dotted line is visible.</p>
  </div>
  <div id="examples">
    <div id="renderings">
      <hr />
      <h3><span></span>Renderings:</h3>
      <div class="neutral">
        <h4>1.</h4>
        <div id="coordinated1">
          <h2 class="photography"><span></span>Photography</h2>
          <img src="images/facepot.jpg" height="267" width="200" alt="Photograph of a stone face among plants." />
          <p class="caption">This stone face and foliage were photographed at
            the Harry P. Leu botanical gardens in Orlando, Florida.</p>
          <ul class="imageinfo">
            <li>Date Photographed: 10/19/2005</li>
          </ul>
        </div>
        <h4>2.</h4>
        <div id="coordinated2">
          <h2 class="photography"><span></span>Photography</h2>
          <img src="images/facepot.jpg" height="267" width="200" alt="Photograph of a stone face among plants." />
          <p class="caption">This stone face and foliage were photographed at
            the Harry P. Leu botanical gardens in Orlando, Florida.</p>
          <ul class="imageinfo">
            <li>Date Photographed: 10/19/2005</li>
          </ul>
        </div>
        <h4>3.</h4>
        <div id="coordinated3">
          <h2 class="photography"><span></span>Photography</h2>
          <img src="images/facepot.jpg" height="267" width="200" alt="Photograph of a stone face among plants." />
          <p class="caption">This stone face and foliage were photographed at
            the Harry P. Leu botanical gardens in Orlando, Florida.</p>
          <ul class="imageinfo">
            <li>Date Photographed: 10/19/2005</li>
          </ul>
        </div>
      </div>
      <?php show_examplelink("View Renderings Only"); ?>
      <hr />
    </div>
    <div id="quanta">
      <h3><span></span>Quanta</h3>
      <h4>1., 2., 3.</h4>
      <ul>
        <li><a href="images/facepot.jpg">Face/Foliage JPEG</a></li>
        <li>XHTML Code:
          <div class="code">
            <pre><code>&lt;div id=&quot;coordinated&quot;&gt;
  &lt;h2 class=&quot;photography&quot;&gt;&lt;span&gt;&lt;/span&gt;Photography&lt;/h2&gt;<br />  &lt;img src=&quot;images/facepot.jpg&quot; height=&quot;267&quot; width=&quot;200&quot; alt=&quot;Photograph of a stone face among plants.&quot; /&gt;<br />  &lt;p class=&quot;caption&quot;&gt;This stone face and foliage were photographed at<br />    the Harry P. Leu botanical gardens in Orlando, Florida.&lt;/p&gt;<br />  &lt;ul class=&quot;imageinfo&quot;&gt;<br />    &lt;li&gt;Date Photographed: 10/19/2005&lt;/li&gt;<br />  &lt;/ul&gt;
&lt;/div&gt;</code></pre>
          </div>
        </li>
      </ul>
      <h4>2.</h4>
      <ul>
        <li><a href="images/h_photography.jpg">Photography Header JPEG</a></li>
        <li><a href="images/stagger_pixels.jpg">Image Background JPEG</a></li>
        <li>CSS Code:
          <div class="code">
            <pre><code>
div#coordinated { 
  width: 420px;
  background-image: url(../images/bg_photography.jpg);
  background-repeat: no-repeat;
  background-position: bottom left;
  padding-bottom: 30px;
  font-family: Verdana, Arial, Helvetica, sans-serif;
  font-size: 10px;
}
div#coordinated h2.photography {
  height: 48px;
  font-size: 14px;
}
div#coordinated h2.photography span {
  position: absolute;
  height: 48px;
  width: 286px;
  background-image: url(../images/h_photography.jpg);
}
div#coordinated img {
  float: left;
  background-image: url(../images/stagger_pixels.jpg);
  background-repeat: no-repeat;
  background-position: 10px 10px;
  padding: 0px 10px 10px 0px;
  margin: 0px 20px 0px 18px;
}
div#coordinated p.caption {
  margin: 0px;
  padding: 0px;
  line-height: 3;
}
div#coordinated ul {
  clear: both;
  list-style-type: none;
  font-weight: bold;
  margin: 0px 0px 0px 18px;
  padding: 20px 0px 0px 0px;
}
div#coordinated ul li {
  margin: 0px;
  padding: 0px;
}</code></pre>
          </div>
        </li>
      </ul>
      <h4>3.</h4>
      <ul>
        <li>Additional CSS:
          <div class="code">
            <pre><code>
div#coordinated { 
  width: 420px;
  background-image: url(../images/bg_photography.jpg);
  background-repeat: no-repeat;
  background-position: bottom left;
  padding-bottom: 30px;
  font-family: Verdana, Arial, Helvetica, sans-serif;
  font-size: 10px;
  <strong>border-top: 1px dotted #666666;</strong>
  <strong>margin-top: 30px;</strong>
}
div#coordinated h2.photography {
  height: 48px;
  font-size: 14px;
  <strong>margin-top: -24px;</strong>
}
div#coordinated h2.photography span {
  position: absolute;
  height: 48px;
  width: 286px;
  background-image: url(../images/h_photography.jpg);
}
div#coordinated img {
  float: left;
  background-image: url(../images/stagger_pixels.jpg);
  background-repeat: no-repeat;
  background-position: 10px 10px;
  padding: 0px 10px 10px 0px;
  margin: 0px 20px 0px 18px;
}
div#coordinated p.caption {
  margin: 0px;
  padding: 0px;
  line-height: 3;
}
div#coordinated ul {
  clear: both;
  list-style-type: none;
  font-weight: bold;
  margin: 0px 0px 0px 18px;
  padding: 20px 0px 0px 0px;
}
div#coordinated ul li {
  margin: 0px;
  padding: 0px;
}</code></pre>
          </div>
        </li>
      </ul>
    </div>
    <div id="discussion">
      <h3><span></span>Discussion</h3>
      <p>CSS presentation is dependent on descriptive document structure. The
        presence of classes and ids in addition to descriptive tags (headers,
        paragraphs, lists) allows digital producers to refer exactly to the portions
        of a document they wish to style. Renderings 2 and 3 use the same XHTML
        as Rendering 1. (As I will discuss in Chapter Five, this allows producers
        who are less visually oriented to gradually build upon the structure
        of their written and visual content.) Provided that an XHTML document
        provides structural specificity, any of the design techniques demonstrated
        in this chapter may be used with any other: no one style or technique
        will disrupt another. And as in the other examples in this chapter, CSS
        and images can be turned off without disrupting user experience of the
        renderings on this page.</p>
      <p>As Renderings 2 and 3 show, CSS can also control the placement of a
        page’s elements in relation to one another. Rendering 2 and 3 both “float”
        the content image, allowing paragraph text to appear immediately to the
        right. Rendering 3 uses negative margins on the header tag to compensate
        for a positive margin on the container, which gives the illusion that
        the header appears above/outside the container. The simple dotted border,
        which is set on the very top of the container, is meant to help demonstrate
        this illusion. Additional styles can be added, even experimentally, to elements of a page
        without disrupting the overall design. If a producer decides that a particular
        visual choice is ineffective (like the dotted line), it can be removed
        without affecting the rest of the design. This allows producers to invent
        and revise portions of their designs without adjusting their content, either
        (a common problem with table-based design, as
        I discussed in Chapter Three).</p>
      <p>Like the CSS design, the XHTML in this example can also be extended:
        the use of an unordered list and single list item for the “Date Photographed”
        information, for example, could be expanded to contain other information
        about the photograph, like the camera used or shutter speed, making the
        list a more effective structural choice than a simple paragraph.
        Extending this portfolio to a dynamic system that uses advanced server
        technologies (like PHP and MySQL) would allow a producer to build a function
        that reads the Exchangeable image file format (Exif) data that digital
        cameras typically write to image files at the moment a photograph is
        taken; the producer could then choose to include some of that information
        with each of her photographs in the portfolio, dynamically and automatically
        adding them to the unordered list that is already in place.</p>
    </div>
  </div>
</div>
<?php show_footer(); ?>

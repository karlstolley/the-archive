<?php
include('functions.php');
show_header("Character Encoding");
show_navigation();
?>

<div id="content">
  <div id="contenthead">
    <h2><span></span>Visual Rhetorical Task:</h2>
    <p>Present correctly encoded text characters to all readers.</p>
  </div>
  <div id="description">
    <h3><span></span>Description</h3>
    <p>The two renderings on this page simulate the effects of specifying an
      incorrect (Rendering 1) or correct (Rendering 2) character set for the
      characters contained in the page’s XHTML.</p>
    <p>Many software programs, like Microsoft Word, automatically insert all
      sorts of special characters as one writes: typographers’ quotes (sometimes
      called “smart quotes,” versus &quot;straight quotes&quot;); em dashes—the
      long dashes that function like commas or colons; a single-character ellipsis,
      …; and even a copyright mark, ©.</p>
    <p>However, authoring programs like Macromedia Dreamweaver often default
      to the ISO-8859-1 character set (Western or US-ASCII encoding), placing
      it in a meta tag in a Web document’s <code>&lt;head&gt;</code> area. Being
      a limited character set, though, ISO-8859-1 does not contain many of the
      “special characters” most readers have come to expect in digital text.
      In fact, the paragraph above beginning with “Many software programs…” looks
      something like the first rendering in the Renderings area when incorrectly
      presented with the IS0-8859-1 character set (<a href="examples/badcharset.htm">see
      the live example</a>).</p>
    <p>A page that specifies the UTF-8 set in the document’s <code>&lt;head&gt; area</code> (<a href="examples/goodcharset.htm">see
        the live example</a>) will enable the display of special characters
        correctly by informing a user’s Web browser of the page text’s proper
        character encoding.</p>
  </div>
  <div id="examples">
    <div id="renderings">
      <hr />
      <h3><span></span>Renderings:</h3>
      <h4>1. ISO-8859-1 (Simulated; <a href="examples/badcharset.htm">see live
          example</a>)</h4>
      <img class="simulation" src="images/badchar.jpg" height="158" width="475" alt="Simulated, almost illegible display of incorrect character encoding." />
      <h4>2. UTF-8 (Simulated; <a href="examples/goodcharset.htm">see live example</a>)</h4>
      <img class="simulation" src="images/goodchar.jpg" height="117" width="475" alt="Simulated, almost illegible display of incorrect character encoding." />
      <hr />
    </div>
    <div id="quanta">
      <h3><span></span>Quanta</h3>
      <h4>1. ISO-8859-1 (Incorrect Encoding)</h4>
      <div class="code">
        <pre><code>&lt;!--XHTML, in the &lt;head&gt; area--&gt;<br />&lt;meta http-equiv=&quot;Content-Type&quot; content=&quot;text/html; <strong>charset=iso-8859-1</strong>&quot; /&gt;
<br />&lt;!--XHTML, in the &lt;body&gt; area--&gt;<br />&lt;p&gt;Many software programs, like Microsoft Word, automatically insert<br />  all sorts of special characters: typographers’ quotes (sometimes <br />  called “smart quotes,” versus &quot;straight quotes&quot;); em dashes—the<br />  long dashes that function like commas or colons; a single-character<br />  ellipsis, …; and even a copyright mark, ©.&lt;/p&gt;</code></pre>
      </div>
      <h4>2. UTF-8 (Correct Encoding)</h4>
      <div class="code">
        <pre><code>&lt;!--XHTML, in the &lt;head&gt; area--&gt;<br />&lt;meta http-equiv=&quot;Content-Type&quot; content=&quot;text/html; <strong>charset=utf-8</strong>&quot; /&gt;
<br />&lt;!--XHTML, in the &lt;body&gt; area (same as above)--&gt;<br />&lt;p&gt;Many software programs, like Microsoft Word, automatically insert<br />  all sorts of special characters: typographers’ quotes (sometimes <br />  called “smart quotes,” versus &quot;straight quotes&quot;); em dashes—the<br />  long dashes that function like commas or colons; a single-character<br />  ellipsis, …; and even a copyright mark, ©.&lt;/p&gt;</code></pre>
      </div>
    </div>
    <div id="discussion">
      <h3><span></span>Discussion</h3>
      <p>Because any Web-capable device can access text, ensuring that the characters
        of a producer’s writing appear to her readers is an important part of
        a page’s emergent visual rhetoric. Character encoding is not a matter
        of font choice (some fonts do contain incomplete character sets—though
        not the system fonts that Web producers should specify in CSS); rather,
        character encoding is a code-level technological choice that has a significant
        and potentially detrimental visual effect on a page, even in a text-only
        browser like Lynx.</p>
      <p><a href="http://validator.w3.org/docs/help.html#faq-charset">UTF-8 is
          the encoding recommended by the W3C</a> (n.d.), despite Dreamweaver’s
          default character encoding of ISO-8859-1. UTF-8 includes most Western
          languages’s symbols and characters, making it possible to include Greek
          words like λόγος (logos) on systems that support them (but not all
          do, thus the rhetorical choice of writing a Roman alphabetic alternative
          in parentheses).</p>
      <p>And while the soundest rhetorical choice, in most circumstances, is
        to design pages using the UTF-8 encoding, knowing how to work at the
        code level and change <code>charset=ISO-8859-1</code> to <code>charset=utf-8</code> is
        representative of a digital producer’s attitude toward digital literacy—and
        demonstrates the benefits of working directly with code. A code-literate
        producer could correct the IS0-8859-1 issue in 5 keystrokes (versus 
        navigating the menu systems in a WYSIWYG; for example, to change character
        encoding in Dreamweaver, one must select Modify &gt; Page Properties &gt; Title/Encoding
        and then choose from large list of possible character sets; and even
        if a Dreamweaver user makes it that far, she must still know to choose
        “Unicode (UTF-8)”). </p>
      <p>In addition to making text with advanced characters readable, an XHTML
        page in UTF-8 contributes to an XHTML page’s sustainability, in part
        because UTF-8 is also the recommended encoding for XML. XHTML has over
        252 “entities,” or codes for special characters, which begin with an
        ampersand (<code>&amp;</code>) and end with a semi-colon (<code>;</code>)
        (e.g., the © symbol is encoded in XHTML as <code>&amp;copy;</code>).
        However, few XHTML entities (five, to be exact, which in XML are called
        “Internal Entities”) are supported automatically by XML—meaning that
        any XHTML-only entities would have to be removed before the XHTML code
        could be repurposed as XML. (Valid XHTML is also valid XML, because XHTML
        is HTML written according to the rules of XML). Sustainability should
        always be a highly ranked motive behind a digital rhetorical choice,
        so aside from the 5 entities shared by the XML set, it is advisable for
        digital producers to use the actual UTF-8 characters in the source code
        (which is made more readable without the presence of entities). And over
        a large document, UTF-8 text represents less data to transfer: the single
        character versus a 5- or 6-character entity.</p>
    </div>
  </div>
</div>
<?php show_footer(); ?>

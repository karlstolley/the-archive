<?php
include('functions.php');
show_header("Text Replacement");
show_navigation();
?>

<div id="content">
  <div id="contenthead">
    <h2><span></span>Visual Rhetorical Task:</h2>
    <p>Present short chunks of text using advanced typography.</p>
  </div>
  <div id="description">
    <h3><span></span>Description</h3>
    <p>A pure XHTML/CSS method of providing sustainable, customizable typography
      on large portions of text has yet to be developed; working with <a href="systemfonts.htm">system
      fonts</a> is clearly the best solution. However, there are a number of
      methods suited to providing customizable typography for small amounts of
      text, like headings or pullquotes. There are three such methods demonstrated
      in the Renderings area of this page. Under ideal conditions, the three
      examples should appear the same.</p>
    <p>Rendering 1 is a slightly modified version of Fahrner Image Replacement
      (FIR) which replaces XHTML text with the CSS <code>background-image</code> property.
      The problem with FIR is that no text is available to a user who might have
      CSS on and images turned off—a problem that the Shea Enhancement of Rendering
      2 addresses by attaching the background image to an empty <code>&lt;span&gt;</code>.</p>
    <p>Rendering 3 is the most advanced, networked example in this chapter, in
      that it uses a technology called sIFR (pron. “siffer”), which requires
      JavaScript and Flash’s ActionScript language to “read” the text of the
      XHTML, and then render each letter as its own Flash movie. This allows
      text rendered with sIFR to work dynamically (changing the text in the XHTML
      automatically changes the final, sIFR-ed text) and unobtrusively on browsers
      that are missing either JavaScript or a recent version of the Flash player.
      And unlike Renderings 1 and 2, which are simply JPEGs that a digital producer
      must (or should) match up with identical XHTML text, the text in Rendering
      3 can actually be selected and thus copied and pasted.</p>
  </div>
  <div id="examples">
    <div id="renderings">
      <hr />
      <h3><span></span>Renderings:</h3>
      <div class="neutral">
        <h4>1. Fahrner Image Replacement (FIR)</h4>
        <!--http://www.stopdesign.com/articles/replace_text/-->
        <h2 id="fir"><span>Emergent Visual Rhetoric</span></h2>
        <h4>2. Shea Enhancement</h4>
        <!--http://www.mezzoblue.com/tests/revised-image-replacement/-->
        <h2 id="shea"><span></span>Emergent Visual Rhetoric</h2>
        <h4>3. Scalable Inman Flash Replacement (sIFR)</h4>
        <!--Named after Shaun Inman; http://www.mikeindustries.com/sifr/-->
        <h2 id="sifr">Emergent Visual Rhetoric</h2>
        <?php show_examplelink("View Renderings Only"); ?>
      </div>
      <hr />
    </div>
    <div id="quanta">
      <h3><span></span>Quanta</h3>
      <h4>1. Fahrner Image Replacement (FIR)</h4>
      <ul>
        <li><a href="images/fir_evrhetoric.jpg">JPEG Image</a></li>
        <li>Code:
          <div class="code">
            <pre><code>&lt;!--XHTML--&gt;<br />&lt;h2 id=&quot;fir&quot;&gt;<strong>&lt;span&gt;</strong>Emergent Visual Rhetoric<strong>&lt;/span&gt;</strong>&lt;/h2&gt;<br />
/* CSS */
h2#fir { 
  height: 26px;
  padding: 0;
  background-image: url(../images/fir_evrhetoric.jpg);
  background-repeat: no-repeat;
}
h2#fir span {display: none;}</code></pre>
          </div>
        </li>
      </ul>
      <h4>2. Shea Enhancement</h4>
      <ul>
        <li><a href="images/fir_evrhetoric.jpg">JPEG Image</a></li>
        <li>Code:
          <div class="code">
            <pre><code>&lt;!--XHTML--&gt;<br />&lt;h2 id=&quot;shea&quot;&gt;<strong>&lt;span&gt;&lt;/span&gt;</strong>Emergent Visual Rhetoric&lt;/h2&gt;<br />
/* CSS */
h2#shea { 
  height: 26px;
  font-size: 12px;
}
h2#shea span {
  background-image: url(../images/fir_evrhetoric.jpg);
  background-repeat: no-repeat;
  position: absolute;
  height: 100%;
  width: 500px;
}</code></pre>
          </div>
        </li>
      </ul>
      <h4>3. Scalable Inman Flash Replacement</h4>
      <ul>
        <li><a href="swf/oranda_cn_bd.swf">SWF with Embedded Font &amp; ActionScript</a></li>
        <li><a href="scripts/sifr.js">Core sIFR Javascript</a></li>
        <li><a href="scripts/sifr-addons.js">Add-ons sIFR Javascript</a></li>
        <li>Code:
          <div class="code">
            <pre><code>&lt;!--XHTML--&gt;<br />&lt;h2 id=&quot;sifr&quot;&gt;Emergent Visual Rhetoric&lt;/h2&gt;<br />
&lt;!--XHTML and on-page Javascript--&gt;<br />
&lt;script type=&quot;text/javascript&quot;&gt;<br />//&lt;![CDATA[<br />if(typeof sIFR == &quot;function&quot;){<br />  sIFR.replaceElement(named({sSelector:&quot;h2#sifr&quot;, sFlashSrc:&quot;swf/oranda_cn_bd.swf&quot;, sColor:&quot;#CC0000&quot;, sBgColor:&quot;#FFFFFF&quot;, nPaddingTop:5, nPaddingBottom:5, nPaddingLeft:5}));<br />};<br />//]]&gt;<br />&lt;/script&gt;</code></pre>
          </div>
        </li>
      </ul>
    </div>
    <div id="discussion">
      <h3><span></span>Discussion</h3>
      <p>Advanced typography, the ability to apply any font a producer wishes
        in any style, is best reserved for smaller portions of text. In both
        of the CSS-based replacments above, a separate JPEG image must be maintained
        along with the text in the XHTML. (If only the image were provided, the
        page would be inaccessible to readers who rely on XHTML text, including
        blind people and users of text-only browsers). Because JPEGs must be
        maintained, any revision to XHTML text treated with image-replacement
        methods requires a revision of the JPEG, and vice-versa. This makes page
        revision much more time-consuming.</p>
      <p>Rendering 1 and Rendering 2 also require additional markup in the XHTML.
        In Rendering 1, a <code>&lt;span&gt;</code> tag is placed around the
        text in the <code>&lt;h2&gt;</code> tag, making the <code>&lt;span&gt;</code> tag
        structurally meaningless and employing it for visual effect only. (In
        the case of Rendering 1, a CSS style, <code>display:none;</code>, hides
        the text in the <code>&lt;span&gt;</code> tag—which is why a CSS on/images
        off experience leaves a reader with no access to the <code>&lt;h2&gt;</code> tag’s
        text; this has caused problems even for screen readers, as Dave Shea
        (n.d.) noted in his <a href="http://www.mezzoblue.com/tests/revised-image-replacement/">exhaustive
        collection of image-replacement methods</a>). The empty <code>&lt;span&gt;</code> tags
        in Rendering 2, while solving the problem of providing XHTML text to
        users with no image display, are an even less structurally meaningful
        use of the tag.</p>
      <p>Image-replacement-based typography is one instance where ideals of Web
        standards (<em>don’t use structurally meaningless tags in the service
        of visual presentation</em>) must be negotiated with a visual rhetoric;
        advanced typography has the potential to greatly enhance the visual interest
        of a page, but it must be provided in an experience that works well in
        a variety of situations. The Shea enhancement does this the best. (And
        if, in the future, an image-replacement method presents itself that does
        not require the empty <code>&lt;span&gt;</code> tags, a quick search
        and replace for “<code>&lt;span&gt;&lt;/span&gt;</code>” in the source
        XHTML code can quickly remove them.)</p>
      <p>The sIFR Rendering is the most faithful to Web standards as it requires
        only the XHTML that would appear on a page anyway. (For the sake of this
        example in the context of this page of the dissertation chapter, I had
        to assign the <code>id</code> of <code>sifr</code> to the <code>&lt;h2&gt;</code> tag;
        but sIFR works on regular <code>class</code>- and <code>id</code>-less
        tags, too). sIFR text also enlarges with the rest of the text on a page
        (after a page refresh, at least on Firefox), something the image-replacement
        methods cannot replicate. And in terms of sustainability, sIFR’s run-time
        reliance on the text in the XHTML for display means that only the XHTML
        text would need to be revised. And as the creators of sIFR have remarked,
        “should you decide at some point in the future that you don’t want to
        use [sIFR], simply remove the .js [JavaScript] file and you’re back to
        browser text” (<a href="http://www.mikeindustries.com/sifr/">Davidson,
        2005</a>).</p>
      <p>However, sIFR relies on JavaScript and a recent Flash player, plus a
        standards-compliant browser that understands the Document Object Model
        (DOM). And an over-use of sIFR (including use on too many different tags,
        or over extended passages of text) takes a large amount of a user’s computer
        processing power: sIFR, being a client-side technology, is entirely rendered
        on an end-user’s computer—causing potential problems for older computers,
        or computers of users with many different applications active.</p>
    </div>
    <div id="browser">
      <h3><span></span>Sample Browser Rendering</h3>
      <p>Note that with images disabled but Flash active, Rendering 3 still functions.
        Rendering 1, however, leaves no text visible, unlike rendering 2 (Figure
        4.2).</p>
      <img class="screencap" src="captures/ff_noimages_replacement.jpg" height="270" width="510" alt="JPEG detail of example renderings Firefox, images turned off." />
      <p class="figurecaption">Figure 4.2: Detail of Firefox screen capture of <a href="examples/replacement.htm">example
          renderings</a>, images turned off.</p>
    </div>
  </div>
</div>
<script type="text/javascript">
//<![CDATA[
/* Replacement calls. Please see documentation for more information. */

if(typeof sIFR == "function"){

// This is the preferred "named argument" syntax
	sIFR.replaceElement(named({sSelector:"h2#sifr", sFlashSrc:"swf/oranda_cn_bd.swf", sColor:"#CC0000", sBgColor:"#FFFFFF", nPaddingTop:5, nPaddingBottom:5, nPaddingLeft:5}));

};

//]]>
</script>
<?php show_footer(); ?>

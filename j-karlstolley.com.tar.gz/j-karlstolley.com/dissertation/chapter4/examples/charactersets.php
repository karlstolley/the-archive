<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link href="../css/examples.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body id="example">
<div>
<h4>1. ISO-8859-1 (Simulated; <a href="badcharset.htm">see live example</a>)</h4>
<img class="simulation" src="../images/badchar.jpg" alt="Simulated, almost illegible display of incorrect character encoding." height="158" width="475" />
<h4>2. UTF-8 (Simulated; <a href="goodcharset.htm">see live example</a>)</h4>
<img class="simulation" src="../images/goodchar.jpg" alt="Simulated, almost illegible display of incorrect character encoding." height="117" width="475" />
</div>
</body>
</html>

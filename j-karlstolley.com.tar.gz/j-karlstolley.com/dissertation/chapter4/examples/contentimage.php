<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Content Images</title>
<link href="../css/examples.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body id="example">
<div>
<h4>1. CSS</h4>
<div id="flowercon">
<p>I photographed these lovely flowers in Orlando, Florida.</p>
</div>
<h4>2. &lt;img&gt; Tag</h4>
<img src="../images/flower_sm.jpg" height="240" width="320" alt="I photographed these lovely flowers in Orlando, Florida." />
<h4>3. &lt;object&gt; Tag</h4>
<object data="../images/flower_sm.jpg" type="image/jpeg" height="240" width="320">
<p>I photographed these lovely flowers in Orlando, Florida.</p>
</object>
</div>
</body>
</html>

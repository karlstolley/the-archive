<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link href="../css/examples.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body id="example">
      <h4>1.</h4>
	  <div id="coordinated1">
	  <h2 class="photography"><span></span>Photography</h2>
	  <img src="../images/facepot.jpg" height="267" width="200" alt="Photograph of a stone face among plants." />
	  <p class="caption">This stone face and foliage were photographed at the Harry P. Leu botanical gardens in Orlando, Florida.</p>
	  <ul class="imageinfo">
	  <li>Date Photographed: 10/19/2005</li>
	  </ul>
	  </div>
	  <h4>2.</h4>
	  <div id="coordinated2">
  	  <h2 class="photography"><span></span>Photography</h2>
	  <img src="../images/facepot.jpg" height="267" width="200" alt="Photograph of a stone face among plants." />
	  <p class="caption">This stone face and foliage were photographed at the Harry P. Leu botanical gardens in Orlando, Florida.</p>
	  <ul class="imageinfo">
	  <li>Date Photographed: 10/19/2005</li>
	  </ul>
	  </div>
	  <h4>3.</h4>
	  <div id="coordinated3">
      <h2 class="photography"><span></span>Photography</h2>
	  <img src="../images/facepot.jpg" height="267" width="200" alt="Photograph of a stone face among plants." />
	  <p class="caption">This stone face and foliage were photographed at the Harry P. Leu botanical gardens in Orlando, Florida.</p>
	  <ul class="imageinfo">
	  <li>Date Photographed: 10/19/2005</li>
	  </ul>
	  </div>
</body>
</html>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link href="../css/examples.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body id="example">
      <h4>1. Fixed Layout</h4>
	  <div class="inflex">
	  <p>Readers will appreciate the ability to resize text without breaking a page’s layout.</p>
	  </div>
	  <h4>2. Fixed Layout, More Content</h4>
	  <div class="inflex">
	  <p>Readers will appreciate the ability to resize text without breaking a page’s layout. (Of course, Internet Explorer still wont resize text specified in pixel units.)</p>
	  </div>
	  <h4>3. Flexible Layout</h4>
	  <div class="flex">
	  <p>Readers will appreciate the ability to resize text without breaking a page’s layout.</p>
	  </div>
	  <h4>4. Flexible Layout, More Content</h4>
	  <div class="flex">
	  <p>Readers will appreciate the ability to resize text without breaking a page’s layout. (Of course, Internet Explorer still wont resize text specified in pixel units.)</p>
	  </div>
</body>
</html>

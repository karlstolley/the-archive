<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>System Fonts</title>
<link href="../css/examples.css" rel="stylesheet" type="text/css" media="screen" />
</head>

<body id="example">
<h4>Verdana</h4>
<div id="verdana">
<p class="size4">Verdana at 4px.</p>
<p class="size5">Verdana at 5px.</p>
<p class="size6">Verdana at 6px.</p>
<p class="size7">Verdana at 7px.</p>
<p class="size8">Verdana at 8px.</p>
<p class="size9">Verdana at 9px.</p>
<p class="size10">Verdana at 10px.</p>
<p class="size11">Verdana at 11px.</p>
<p class="size12">Verdana at 12px.</p>
<p class="size13">Verdana at 13px.</p>
<p class="size14">Verdana at 14px.</p>
<p class="size15">Verdana at 15px.</p>
<p class="size16">Verdana at 16px.</p>
<p class="size17">Verdana at 17px.</p>
<p class="size18">Verdana at 18px.</p>
<p class="size19">Verdana at 19px.</p>
<p class="size20">Verdana at 20px.</p>
<p class="size21">Verdana at 21px.</p>
<p class="size22">Verdana at 22px.</p>
<p class="size23">Verdana at 23px.</p>
<p class="size24">Verdana at 24px.</p>
<p class="size25">Verdana at 25px.</p>
</div>
<h4>Verdana Italic</h4>
<div id="verdanaitalic">
<p class="size4">Verdana at 4px.</p>
<p class="size5">Verdana at 5px.</p>
<p class="size6">Verdana at 6px.</p>
<p class="size7">Verdana at 7px.</p>
<p class="size8">Verdana at 8px.</p>
<p class="size9">Verdana at 9px.</p>
<p class="size10">Verdana at 10px.</p>
<p class="size11">Verdana at 11px.</p>
<p class="size12">Verdana at 12px.</p>
<p class="size13">Verdana at 13px.</p>
<p class="size14">Verdana at 14px.</p>
<p class="size15">Verdana at 15px.</p>
<p class="size16">Verdana at 16px.</p>
<p class="size17">Verdana at 17px.</p>
<p class="size18">Verdana at 18px.</p>
<p class="size19">Verdana at 19px.</p>
<p class="size20">Verdana at 20px.</p>
<p class="size21">Verdana at 21px.</p>
<p class="size22">Verdana at 22px.</p>
<p class="size23">Verdana at 23px.</p>
<p class="size24">Verdana at 24px.</p>
<p class="size25">Verdana at 25px.</p>
</div>
<h4>Georgia</h4>
<div id="georgia">
<p class="size4">Georgia at 4px.</p>
<p class="size5">Georgia at 5px.</p>
<p class="size6">Georgia at 6px.</p>
<p class="size7">Georgia at 7px.</p>
<p class="size8">Georgia at 8px.</p>
<p class="size9">Georgia at 9px.</p>
<p class="size10">Georgia at 10px.</p>
<p class="size11">Georgia at 11px.</p>
<p class="size12">Georgia at 12px.</p>
<p class="size13">Georgia at 13px.</p>
<p class="size14">Georgia at 14px.</p>
<p class="size15">Georgia at 15px.</p>
<p class="size16">Georgia at 16px.</p>
<p class="size17">Georgia at 17px.</p>
<p class="size18">Georgia at 18px.</p>
<p class="size19">Georgia at 19px.</p>
<p class="size20">Georgia at 20px.</p>
<p class="size21">Georgia at 21px.</p>
<p class="size22">Georgia at 22px.</p>
<p class="size23">Georgia at 23px.</p>
<p class="size24">Georgia at 24px.</p>
<p class="size25">Georgia at 25px.</p>
</div>
<h4>Georgia Italic</h4>
<div id="georgiaitalic">
<p class="size4">Georgia at 4px.</p>
<p class="size5">Georgia at 5px.</p>
<p class="size6">Georgia at 6px.</p>
<p class="size7">Georgia at 7px.</p>
<p class="size8">Georgia at 8px.</p>
<p class="size9">Georgia at 9px.</p>
<p class="size10">Georgia at 10px.</p>
<p class="size11">Georgia at 11px.</p>
<p class="size12">Georgia at 12px.</p>
<p class="size13">Georgia at 13px.</p>
<p class="size14">Georgia at 14px.</p>
<p class="size15">Georgia at 15px.</p>
<p class="size16">Georgia at 16px.</p>
<p class="size17">Georgia at 17px.</p>
<p class="size18">Georgia at 18px.</p>
<p class="size19">Georgia at 19px.</p>
<p class="size20">Georgia at 20px.</p>
<p class="size21">Georgia at 21px.</p>
<p class="size22">Georgia at 22px.</p>
<p class="size23">Georgia at 23px.</p>
<p class="size24">Georgia at 24px.</p>
<p class="size25">Georgia at 25px.</p>
</div>
</body>
</html>

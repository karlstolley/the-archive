<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<?php
for ($i=4; $i<26; $i++) {
$style .= "p.size" . $i . " { font-size: " . $i . "px; }\n";
$paras .= "<p class=\"size" . $i ."\">Verdana at " . $i . "px.</p>\n";
}
?>
<style type="text/css">
<!--
p { font-family: Verdana, Helvetica, sans-serif; margin: 0; padding: 0px 0px 5px 0px; font-style: italic;}
<?php print $style; ?>
-->
</style>
</head>

<body>
<?php
print $paras;
?>
</body>
</html>

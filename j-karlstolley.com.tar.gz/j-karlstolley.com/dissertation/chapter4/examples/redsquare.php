<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Red Squares</title>
<link href="../css/examples.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body id="example">
<div>
<h4>1. XHTML/CSS Square</h4>
<div class="redsquarecss" title="Square 1">
  <p>Square 1: Most visual browsers for sighted users will render a red square
    here, using instructions from the CSS file this page links to. (The CSS hides
    this text.)</p>
</div>
<h4>2. JPEG Square</h4>
<img class="redsquarejpg" src="../images/red-square.jpg" height="150" width="150" alt="Square 2: A JPEG image of a red square. (This is text in the img tag's alt attribute.)" title="Square 2"/>
<h4>3. Flash Square</h4>
<object class="redsquareswf" type="application/x-shockwave-flash" data="../swf/red-square.swf" width="150" height="150" title="Square 3">
  <param name="movie" value="../swf/red-square.swf" />
  <p title="Square 3">Square 3: Browsers without Flash capability will display
    this text instead of the red square Flash movie.</p>
</object>
</div>
</body>
</html>

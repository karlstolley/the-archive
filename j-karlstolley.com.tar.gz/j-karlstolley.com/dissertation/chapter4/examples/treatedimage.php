<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Treated Images</title>
<link href="../css/examples.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body id="example">
<div>
<h4>1. &lt;img&gt; tag only, borders as part of JPEG</h4>
<img src="../images/flower_sm_fr.jpg" height="252" width="332" alt="I photographed these lovely flowers in Orlando, Florida." />
<h4>2. &lt;img&gt; tag with &lt;div&gt; and CSS</h4>
<div class="treatedimage"> <img src="../images/flower_sm.jpg" height="240" width="320" alt="I photographed these lovely flowers in Orlando, Florida." /> </div>
<h4>3. Same CSS and XHTML as 2., different JPEG</h4>
<div class="treatedimage"> <img src="../images/treefog_sm.jpg" height="320" width="240" alt="I photographed this foggy scene at night in Lafayette, Indiana." /> </div>
</div>
</body>
</html>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link href="../css/examples.css" rel="stylesheet" type="text/css" media="screen" />
<script src="../scripts/sifr.js" type="text/javascript"></script>
<script src="../scripts/sifr-addons.js" type="text/javascript"></script>
</head>
<body id="example">
<h4>1. Fahrner Image Replacement (FIR)</h4>
<!--http://www.stopdesign.com/articles/replace_text/-->
<h2 id="fir"><span>Emergent Visual Rhetoric</span></h2>

<h4>2. Shea Enhancement</h4>
<!--http://www.mezzoblue.com/tests/revised-image-replacement/-->
<h2 id="shea"><span></span>Emergent Visual Rhetoric</h2>
<h4>3. Scalable Inman Flash Replacement (sIFR)</h4>
<!--Named after Shaun Inman; http://www.mikeindustries.com/sifr/-->
<h2 id="sifr">Emergent Visual Rhetoric</h2>

<script type="text/javascript">
//<![CDATA[
/* Replacement calls. Please see documentation for more information. */

if(typeof sIFR == "function"){

// This is the preferred "named argument" syntax
	sIFR.replaceElement(named({sSelector:"h2#sifr", sFlashSrc:"../swf/oranda_cn_bd.swf", sColor:"#CC0000", sBgColor:"#FFFFFF", nPaddingTop:5, nPaddingBottom:5, nPaddingLeft:5}));

};

//]]>
</script>

</body>
</html>

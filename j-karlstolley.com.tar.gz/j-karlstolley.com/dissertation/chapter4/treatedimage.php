<?php
include('functions.php');
show_header("Treated Images");
show_navigation();
?>

<div id="content">
  <div id="contenthead">
    <h2><span></span>Visual Rhetorical Task:</h2>
    <p>Present an image with some treatment or framing.</p>
  </div>
  <div id="description">
    <h3><span></span>Description</h3>
    <p>Content images can gain additional visual interest when enhanced by even
      a simple border or other treatment. Readers experiencing this page under
      ideal conditions will see three images “treated” with a simple frame in
      the Renderings area. Renderings 1 and 2, which will appear identical to
      some readers, both originated as the same photographic image file; but
      Rendering 1’s image file has been edited in Photoshop to add the fading
      corners to the image file itself. Rendering 2 uses CSS and a small image
      for each corner to assemble the frame at run time.</p>
    <p>Renderings 3, which uses the same XHTML and CSS as Rendering 2, demonstrates
      that CSS-based image treatments can be reused multiple times, even for
      images of different sizes or orientations.</p>
  </div>
  <div id="examples">
    <div id="renderings">
      <hr />
      <h3><span></span>Renderings:</h3>
      <div class="neutral">
        <h4>1. &lt;img&gt; tag only, borders as part of JPEG</h4>
        <img src="images/flower_sm_fr.jpg" height="252" width="332" alt="I photographed these lovely flowers in Orlando, Florida." />
        <h4>2. &lt;img&gt; tag with &lt;div&gt; and CSS</h4>
        <div class="treatedimage"> <img src="images/flower_sm.jpg" height="240" width="320" alt="I photographed these lovely flowers in Orlando, Florida." /> </div>
        <h4>3. Same CSS and XHTML as 2., different JPEG</h4>
        <div class="treatedimage"> <img src="images/treefog_sm.jpg" height="320" width="240" alt="I photographed this foggy scene at night in Lafayette, Indiana." /> </div>
        <?php show_examplelink("View Renderings Only"); ?>
      </div>
      <hr />
    </div>
    <div id="quanta">
      <h3><span></span>Quanta</h3>
      <h4>1. &lt;img&gt; tag only, borders as part of JPEG</h4>
      <ul>
        <li><a href="images/flower_sm_fr.jpg">Flower and Border JPEG</a></li>
        <li>Code:
          <div class="code">
            <pre><code>&lt;!--XHTML--&gt;<br />&lt;img src=&quot;images/flower_sm_fr.jpg&quot; height=&quot;252&quot; width=&quot;332&quot; alt=&quot;I photographed these lovely flowers in Orlando, Florida.&quot; /&gt;</code></pre>
          </div>
        </li>
      </ul>
      <h4>2. &lt;img&gt; tag with &lt;div&gt; and CSS</h4>
      <ul>
        <li><a href="images/flower_sm.jpg">Flower JPEG</a></li>
        <li><a href="images/if_topleft.jpg">Border Top-Left JPEG</a></li>
        <li><a href="images/if_bottomright.jpg">Border Bottom-Right JPEG</a></li>
        <li>Code:
          <div class="code">
            <pre><code>&lt;!--XHTML--&gt;<br />&lt;div class=&quot;treatedimage&quot;&gt;<br />  &lt;img src=&quot;images/flower_sm.jpg&quot; height=&quot;240&quot; width=&quot;320&quot; alt=&quot;I photographed these lovely flowers in Orlando, Florida.&quot; /&gt;<br />&lt;/div&gt;<br />
/* CSS * /
div.treatedimage {
  background-color: #FFFFFF;
  background-image: url(../images/if_topleft.jpg);
  background-repeat: no-repeat;
  padding: 6px 0px 0px 6px;
}
div.treatedimage img {
  background-image: url(../images/if_bottomright.jpg);
  background-repeat: no-repeat;
  padding: 0px 6px 6px 0px;
  background-position: bottom right;
}</code></pre>
          </div>
        </li>
      </ul>
      <h4>3. Same CSS and XHTML as 2., different JPEG</h4>
      <ul>
        <li><a href="images/treefog_sm.jpg">Trees JPEG</a></li>
        <li><a href="images/if_topleft.jpg">Border Top-Left JPEG</a></li>
        <li><a href="images/if_bottomright.jpg">Border Bottom-Right JPEG</a></li>
        <li>Code:
          <div class="code">
            <pre><code>&lt;!--XHTML--&gt;<br />&lt;div class=&quot;treatedimage&quot;&gt;<br />  &lt;img src=&quot;<strong>images/treefog_sm.jpg</strong>&quot; height=&quot;<strong>320</strong>&quot; width=&quot;<strong>240</strong>&quot; alt=&quot;I photographed these lovely flowers in Orlando, Florida.&quot; /&gt;<br />&lt;/div&gt;<br />
/* CSS * /
div.treatedimage {
  background-color: #FFFFFF;
  background-image: url(../images/if_topleft.jpg);
  background-repeat: no-repeat;
  padding: 6px 0px 0px 6px;
}
div.treatedimage img {
  background-image: url(../images/if_bottomright.jpg);
  background-repeat: no-repeat;
  padding: 0px 6px 6px 0px;
  background-position: bottom right;
}</code></pre>
          </div>
        </li>
      </ul>
    </div>
    <div id="discussion">
      <h3><span></span>Discussion</h3>
      <p>To add visual interest to photographs and other content images as well
        as to suggest the care going into their presentation (or, in a more fully
        developed design concept, to frame the image to bring it into visual
        harmony with the rest of the page’s visual design), a digital producer
        might add a few simple visual elements to serve as a kind of frame for
        a content image. This can be done in an image-editing program, and made
        part of the photograph or other content image, as in Rendering 1. However,
        adding the frame to the image mixes content (the actual photograph of
        the flowers) with presentation (the fading corners of the “frame”)—something
        that run-time production seeks to avoid. But because the frame is included
        as part of the image file, it would be available to image-capable, non-CSS
        browsers.</p>
      <p> A more flexible and reusable solution for treating images might take
        advantage of CSS, as in Rendering 2, leaving the flower photograph file
        untouched and instead loading two smaller design-image quanta (the top-left
        and bottom-right frame corners) at run time. The CSS solution can be
        reused for other images, as in Rendering 3, due to both the technological
        methods for achieving it and the relative neutrality of the simple, fading
        lines of the frame. Provided that the dimensions of the content image
        are at least the size of the fading frame corners, this solution could
        be used for any image. Of course, for extraordinarily large images, the
        fading corners would not have the same effect of allowing the eye to
        follow the implied line of the frame.</p>
      <p> At the same time, the CSS solution does involve the introduction of
        a potentially meaningless <code>&lt;div&gt;</code> tag. The extra <code>&lt;div&gt;</code> is
        required because it takes the top-left corner of the frame; CSS can only
        assign one background image per element so, in order to have the same
        code work for multiple images at different sizes and orientations, the <code>&lt;div&gt;</code> tag
        serves, in Renderings 2 and 3, a visual function, so long as the <code>&lt;img&gt;</code> tag
        is all it contains. But it could be extended to contain an image caption
        or other text in the <code>&lt;div&gt;</code> that would then be structurally
        associated with the image (XHTML also requires the <code>&lt;img&gt;</code> tag
        to be nested in a block-level tag; one cannot put the <code>&lt;img&gt;</code> tag
        directly in the <code>&lt;body&gt;</code> tag—so in that sense, the <code>&lt;div&gt;</code> tag
        does serve an important function in Renderings 2 and 3.)</p>
      <p>When CSS is used to treat images, as in Renderings 2 and 3, revision
        to the visual treatment is made much easier in the future: changing the
        background image and CSS quanta would change the treatment of images
        for an entire page or site. Keeping presentational and design elements
        in the JPEG image file, as in Rendering 1, adds an additional step to
        any visual design revisions the site’s producer might make; in a collection
        of even a dozen photographs, revision to the treatment is made that much
        more difficult and time-consuming.</p>
    </div>
  </div>
</div>
<?php show_footer(); ?>

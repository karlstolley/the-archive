<?php
include('functions.php');
show_header("Content Images");
show_navigation();
?>

<div id="content">
  <div id="contenthead">
    <h2><span></span>Visual Rhetorical Task:</h2>
    <p>Display a content image.</p>
  </div>
  <div id="description">
    <h3><span></span>Description</h3>
    <p>Much like the Red Square task, in a CSS- and image-enabled browser, the
      Renderings area should contain three identical images of a flower. Each
      Rendering provides for alternate text: a paragraph of text, hidden by CSS,
      for Rendering 1; <code>alt</code> text in the <code>&lt;img&gt;</code> tag
      for Rendering 2; and a paragraph nested inside of the <code>&lt;object&gt;</code> tag
      for Rendering 3.</p>
    <p>However, on older versions of Netscape and all versions of Internet Explorer,
      Rendering 3, which loads the image via the <code>&lt;object&gt;</code> tag,
      may have scroll bars and other distracting features to it. Virtually all
      graphical browsers and devices, including those without CSS, will render
      the image in Rendering 2.</p>
  </div>
  <div id="examples">
    <div id="renderings">
      <hr />
      <h3><span></span>Renderings:</h3>
      <h4>1. CSS</h4>
      <div id="flowercon">
        <p>I photographed these lovely flowers in Orlando, Florida.</p>
      </div>
      <h4>2. &lt;img&gt; Tag</h4>
      <img src="images/flower_sm.jpg" height="240" width="320" alt="I photographed these lovely flowers in Orlando, Florida." />
      <h4>3. &lt;object&gt; Tag</h4>
      <object data="images/flower_sm.jpg" type="image/jpeg" height="240" width="320">
        <p>I photographed these lovely flowers in Orlando, Florida.</p>
      </object>
      <?php show_examplelink("View Renderings Only"); ?>
      <hr />
    </div>
    <div id="quanta">
      <h3><span></span>Quanta</h3>
      <h4>1. CSS</h4>
      <div class="code">
        <pre><code>&lt;!--XHTML--&gt;<br />&lt;div id=&quot;flowercon&quot;&gt;<br />  &lt;p&gt;I photographed these lovely flowers in Orlando, Florida.&lt;/p&gt; <br />&lt;/div&gt;<br />
/* CSS */<br />div#flowercon {
  height: 240px;
  width: 320px;
  background-image: url(../images/flower_sm.jpg);
}
div#flowercon * { display: none; }</code></pre>
      </div>
      <h4>2. &lt;img&gt; Tag</h4>
      <div class="code">
        <pre><code>&lt;!--XHTML--&gt;<br />&lt;img src=&quot;images/flower_sm.jpg&quot; height=&quot;240&quot; width=&quot;320&quot; alt=&quot;I photographed these lovely flowers in Orlando, Florida.&quot; /&gt;</code></pre>
      </div>
      <h4>3. &lt;object&gt; Tag</h4>
      <div class="code">
        <pre><code>&lt;!--XHTML--&gt;<br />&lt;object data=&quot;images/flower_sm.jpg&quot; type=&quot;image/jpeg&quot; height=&quot;240&quot; width=&quot;320&quot;&gt;<br />  &lt;p&gt;I photographed these lovely flowers in Orlando, Florida.&lt;/p&gt;<br />&lt;/object&gt;</code></pre>
      </div>
      <h4>1., 2., 3.</h4>
      <p><a href="images/flower_sm.jpg">JPEG Image</a></p>
    </div>
    <div id="discussion">
      <h3><span></span>Discussion</h3>
      <p>The methods of loading the flower image are another example of that
        what a producer sees differing from what users get under different viewing
        conditions. The use of CSS in Rendering 1, aside from being incapable
        of display on older browsers, is clumsy and overkill: even if all images
        on a page were exactly the same size and could be declared so in the
        CSS, a page would require a large number of unique <code>id</code>s in
        the XHTML and CSS to load each unique image. “Content images” function
        rhetorically as “Have a look at this picture of <em>x</em>,” meaning
        that a content image (and its text alternative) would appear on a page
        regardless of how the page’s design degrades or changes over time. The
        CSS <code>background-image</code> property, then, is more appropriate
        for design images: images whose appearance is contingent on the overall
        design of a page.</p>
      <p>The use of the <code>&lt;img&gt;</code> tag for Rendering 2 is the most
        common and well-supported method for loading content images. Because
        the image tag is self-closing, it cannot wrap around other XHTML tags
        and text; however, standard XHTML requires the <code>alt</code> attribute
        for specifying alternate text, which can be styled by applying font attributes
        for the <code>&lt;img&gt;</code> tag in CSS. However, alternate text
        does not have any solid structural qualities to it (as a paragraph, caption,
        etc).</p>
      <p>Ideally, the <code>&lt;object&gt;</code> tag would enjoy the same level
        of support. And in most of the latest versions of browsers, including
        Netscape, Opera, Safari, and of course Firefox, this support exists.
        The one glaring omission is Internet Explorer 7, which as of this writing
        still, like all previous versions of Internet Explorer, is incapable
        of loading simple text or image content in the <code>&lt;object&gt;</code> tag.</p>
      <p>The <code>&lt;object&gt;</code> tag, when rendered properly, allows
        alternate content to be nested inside of it. This would enable a digital
        producer to provide richly structured text (instead of the unstructured <code>alt</code> text
        of the image tag) without having to hide it from view using CSS (as is
        done in Rendering 1). Richly structured text, in addition to providing
        a better experience for blind readers or readers in text-only environments,
        also improves search engines’ indexing. In a Web that continues to expand
        at an almost exponential rate, rhetorical success is dependent in large
        part on a page’s visibility/higher rankings in search engines, which
        clearly have no means to “index” an image. Image searches are actually
        searches for text that is located near another image; in the case of
        an <code>&lt;object&gt;</code> tag containing structured text, the association
        between text and image would be much clearer. In a page composed primarily
        of content images, nested content inside of the <code>&lt;object&gt;</code> tag
        could, at least in theory, raise the page’s visibility in search engines.</p>
      <p>But even though the <code>&lt;object&gt;</code> tag offers the most
        benefits to a page’s structure and graceful degradation, it must be carefully
        weighed against the more universal support of the <code>&lt;img&gt;</code> tag.
        In the rhetorical move of “Have a look at this picture of <em>x</em>,”
        it is probably best to choose the latter method, unless a digital producer
        can be certain that her audience will not include users of Internet Explorer—which
        is unlikely.</p>
    </div>
    <div id="browser">
      <h3><span></span>Sample Browser Rendering</h3>
      <p>Even the very latest Internet Explorer, version 7, fails to correctly
        present an image loaded in the <code>&lt;object&gt;</code> tag.</p>
      <img class="screencap" src="captures/ie7_content.jpg" height="281" width="510" alt="JPEG screen capture detail of IE7’s incorrect rendering of the object tag." />
      <p class="figurecaption">Figure 4.4: Detail of IE7’s incorrect rendering
        of <a href="examples/contentimage.htm">the <code>&lt;object&gt;</code> tag</a> (Rendering
        3).</p>
    </div>
  </div>
</div>
<?php show_footer(); ?>

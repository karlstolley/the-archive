<?php
include('functions.php');
show_header("Flexible Layout");
show_navigation();
?>

<div id="content">
  <div id="contenthead">
    <h2><span></span>Visual Rhetorical Task:</h2>
    <p>Present a layout that adjusts according to text size or content.</p>
  </div>
  <div id="description">
    <h3><span></span>Description</h3>
    <p>The <code>background-image</code> property in CSS supports advanced visual
      design for the Web medium. In addition to aiding in <a href="replacement.htm">text
      replacement</a> and the <a href="treatedimage.htm">treatment</a> of <a href="contentimage.htm">content
      images</a>, background images are essential for moving away from simple
      rectangles of color to more intricate designs.</p>
    <p>The Renderings area on this page demonstrates two methods for using background
      images to create a small text box with rounded corners. Renderings 1 and
      2 both rely on a background image with fixed dimensions; while the solution
      works for text under a certain length viewed at the default size, the text
      spills over the background when a user resizes it or a when producer adds
      additional text (Rendering 2).</p>
    <p>Renderings 3 and 4 are arguably more visually appealing, in that both
      resize to fit content—including the shorter text in Rendering 3. Users
      can also resize the text (in many browsers, this can be achieved from the
      View menu) until it is improbably large before the layouts in Renderings
      3 and 4 break. And because Renderings 3 and 4 use the <code>background-color:</code> property
      to match the images containing the rounded corners means, the white text
      will still be legible in a CSS on/images off viewing contingency (which
      might include a broken or missing background image, and not merely user
      preference).</p>
  </div>
  <div id="examples">
    <div id="renderings">
      <hr />
      <h3><span></span>Renderings:</h3>
      <h4>1. Fixed Layout</h4>
      <div class="inflex">
        <p>Readers will always appreciate the ability to resize text without
          breaking a page’s layout.</p>
      </div>
      <h4>2. Fixed Layout, More Content</h4>
      <div class="inflex">
        <p>Readers will always appreciate the ability to resize text without
          breaking a page’s layout. (Of course, Internet Explorer still won’t
          resize text specified in pixel units.)</p>
      </div>
      <h4>3. Flexible Layout</h4>
      <div class="flex">
        <p>Readers will always appreciate the ability to resize text without
          breaking a page’s layout.</p>
      </div>
      <h4>4. Flexible Layout, More Content</h4>
      <div class="flex">
        <p>Readers will always appreciate the ability to resize text without
          breaking a page’s layout. (Of course, Internet Explorer still won’t
          resize text specified in pixel units.)</p>
      </div>
      <?php show_examplelink("View Renderings Only"); ?>
      <hr />
    </div>
    <div id="quanta">
      <h3><span></span>Quanta</h3>
      <h4>1. Fixed Layout</h4>
      <ul>
        <li><a href="images/back_inflex.gif">Background Image</a></li>
        <li>Code:
          <div class="code">
            <pre><code>&lt;!--XHTML--&gt;<br />&lt;div class=&quot;inflex&quot;&gt;<br />  &lt;p&gt;Readers will always appreciate the ability to resize text without<br />    breaking a page’s layout.&lt;/p&gt;<br />&lt;/div&gt;<br />
/* CSS */
div.inflex {
  min-height: 150px;
  width: 200px;
  background-image: url(../images/back_inflex.gif);
  background-repeat: no-repeat;
}
div.inflex p {
  color: white;
  font-size: 14px;
  font-weight: bold;
  line-height: 1.1;
  padding: 16px;
}</code></pre>
          </div>
        </li>
      </ul>
      <h4>2. Fixed Layout, More Content</h4>
      <ul>
        <li><a href="images/back_inflex.gif">Background Image</a></li>
        <li>Code:
          <div class="code">
            <pre><code>&lt;!--XHTML--&gt;<br />&lt;div class=&quot;inflex&quot;&gt;<br />  &lt;p&gt;Readers will always appreciate the ability to resize text without<br />    breaking a page’s layout. <strong>(Of course, Internet Explorer still</strong><br />    <strong>won’t resize text specified in pixel units.)</strong>&lt;/p&gt;<br />&lt;/div&gt;<br />
/* CSS */
div.inflex {
  min-height: 150px;
  width: 200px;
  background-image: url(../images/back_inflex.gif);
  background-repeat: no-repeat;
}
div.inflex p {
  color: white;
  font-size: 14px;
  font-weight: bold;
  line-height: 1.1;
  padding: 16px;
}</code></pre>
          </div>
        </li>
      </ul>
      <h4>3. Flexible Layout</h4>
      <ul>
        <li><a href="images/back_flextop.gif">Top Background Image</a></li>
        <li><a href="images/back_flexbtm.gif">Bottom Background Image</a></li>
        <li>Code:
          <div class="code">
            <pre><code>&lt;!--XHTML--&gt;<br />&lt;div class=&quot;flex&quot;&gt;<br />  &lt;p&gt;Readers will always appreciate the ability to resize text without<br />    breaking a page’s layout.&lt;/p&gt;<br />&lt;/div&gt;<br />
/* CSS */
div.flex {
  width: 200px;
  <strong>background-color: #999933;</strong>
  background-image: url(<strong>../images/back_flexbtm.gif</strong>);
  background-repeat: no-repeat;
  <strong>background-position: bottom;</strong>
}
div.flex p {
  color: white;
  font-size: 14px;
  font-weight: bold;
  line-height: 1.1;
  padding: 16px;
  <strong>background-image: url(../images/back_flextop.gif);</strong>
  <strong>background-repeat: no-repeat;</strong>
}</code></pre>
          </div>
        </li>
      </ul>
      <h4>4. Flexible Layout, More Content</h4>
      <ul>
        <li><a href="images/back_flextop.gif">Top Background Image</a></li>
        <li><a href="images/back_flexbtm.gif">Bottom Background Image</a></li>
        <li>Code:
          <div class="code">
            <pre><code>&lt;!--XHTML--&gt;<br />&lt;div class=&quot;inflex&quot;&gt;<br />  &lt;p&gt;Readers will always appreciate the ability to resize text without<br />    breaking a page’s layout. <strong>(Of course, Internet Explorer still</strong><br />    <strong>won’t resize text specified in pixel units.)</strong>&lt;/p&gt;<br />&lt;/div&gt;<br />
/* CSS */
div.flex {
  width: 200px;
  background-color: #999933;
  background-image: url(../images/back_flexbtm.gif);
  background-repeat: no-repeat;
  background-position: bottom;
}
div.flex p {
  color: white;
  font-size: 14px;
  font-weight: bold;
  line-height: 1.1;
  padding: 16px;
  background-image: url(../images/back_flextop.gif);
  background-repeat: no-repeat;
}</code></pre>
          </div>
        </li>
      </ul>
    </div>
    <div id="discussion">
      <h3><span></span>Discussion</h3>
      <p>In emergent visual rhetoric, presentation and content are kept in separate
        quanta, only to emerge together at run-time. This means that, ideally,
        one’s content may change without affecting (breaking) the layout, and
        that layout will likewise not compromise a reader’s ability to experience
        content. Visual solutions that require content to be of a particular
        length or size are not sustainable because they close off the possibility
        of revising content—or force a producer to revise a page’s design based
        on revisions to content (and vice-versa).</p>
      <p>The flexible visual presentation in Renderings 3 and 4 also makes better
        use of the structure of the document: instead of placing the whole background
        image on the <code>&lt;div&gt;</code> tag, as in Renderings 1 and 2,
        Renderings 3 and 4 are dependent on additional quanta: an image of the
        top rounded corners (applied to the <code>&lt;p&gt;</code> tag) and the
        bottom (applied to the <code>&lt;div&gt;</code> tag) and the CSS quantum
        of the <code>background-color</code> property (which is rendered by a
        user’s browser with the <code>&lt;div&gt;</code>, rather than downloaded
        as an image.) Renderings 3 and 4 are both excellent examples of networked
        production: the more quanta there are and the more a design relies on
        instructions executed at run-time, the more flexible the solution is.
        In other words, because it responds to different lengths of text (another
        important quantum), Rendering 3 is more visually balanced and appealing
        than its fixed-height counterpart in Rendering 1.</p>
      <p></p>
    </div>
    <div id="browser">
      <h3><span></span>Sample Browser Rendering</h3>
      <p>The flexible layouts, Renderings 3 and 4, make use of CSS’s <code>background-color</code> property,
        keeping the white text readable even when a browser does not display
        images (Figure 4.5).</p>
      <img class="screencap" src="captures/ff_noimages_flexpoints.jpg" height="930" width="510" alt="JPEG screen capture of Firefox rendering examples, images off." />
      <p class="figurecaption">Figure 4.5: Text is still readable in <a href="examples/flexpoints.htm">Renderings
          3 and 4</a> with images off.</p>
    </div>
  </div>
</div>
<?php show_footer(); ?>

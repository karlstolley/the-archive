<?php
include('functions.php');
show_header("Colophon");
show_navigation();
?>

<div id="content">
  <div id="contenthead">
    <h2 id="colophon"><span></span>Colophon</h2>
  </div>
  <div id="description"> </div>
  <div id="examples">
    <div id="discussiononly">
      <p>The Web pages of this chapter are coded in W3C-standard <a href="http://www.w3.org/TR/xhtml1/">XHTML
          1.0 Strict</a> and <a href="http://www.w3.org/TR/REC-CSS2/">CSS Level
          2</a>, and have been checked against W3C validators. Character encoding
          is in <a href="http://unicode.org/">Unicode (UTF-8)</a>.</p>
      <p>Archived PNG images offered on each page were captured from the <a href="http://www.mozilla.com/en-US/firefox/">Mozilla
          Firefox</a> Web browser version 2.0.0.3 on running on <a href="http://www.microsoft.com/windowsxp/default.asp">Microsoft
          Windows XP</a> Professional SP3 with no font smoothing, using the <a href="http://pearlcrescent.com/products/pagesaver/">Pearl
          Crescent Page Saver Basic</a> page capture utility version 1.4. This
          was done to attempt to preserve the look of these pages as they appeared
          in 2007 technology.</p>
      <p>PDF images to aid dissertation committee members’ responses were created
        from the archived PNG images, using <a href="http://www.adobe.com/products/acrobat/">Adobe
        Acrobat</a> 7.0 Professional.</p>
      <p>Some pages in this chapter use <a href="http://www.mikeindustries.com/sifr/">Scalable
          Inman Flash Replacement</a> (sIFR, release 2.0.2) licensed under the
          CC-GNU LGPL (<a href="http://creativecommons.org/licenses/LGPL/2.1/">http://creativecommons.org/licenses/LGPL/2.1/</a>).</p>
      <p>The design of the pages in this chapter is based on the design of my <a href="http://www.sustainablewebdesign.com/">Sustainable
          Web Design</a> resource, the writing of which continues to inform my
          Web design practices as I attempt to teach them to others.</p>
      <img class="screencap" src="images/swd.jpg" height="391" width="510" alt="JPEG screen capture of Sustainable Web Design home page on April 15, 2007." />
      <p class="figurecaption">Figure 4.6: Screen capture of <a href="http://www.sustainablewebdesign.com/">Sustainable
          Web Design</a> home page on April 15, 2007.</p>
    </div>
  </div>
</div>
<?php show_footer_ne(); ?>

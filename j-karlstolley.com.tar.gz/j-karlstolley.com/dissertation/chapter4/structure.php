<?php
include('functions.php');
show_header("Richly Descriptive Structure");
show_navigation();
?>

<div id="content">
  <div id="contenthead">
    <h2><span></span>Visual Rhetorical Task:</h2>
    <p>Use XHTML to structure a text’s important terms and display them in bold
      text.</p>
  </div>
  <div id="description">
    <h3><span></span>Description</h3>
    <p>In a CSS-capable browser that understands the definition tag (<code>&lt;dfn&gt;</code>),
      the word “specification” should appear as bold text in all four renderings.
      Standards-compliant browsers should also display a short contextual definition
      of “specification” when the word is moused over.</p>
    <p>However, in text-only or non-CSS renderings, only Renderings 1 and 4 will
      display “specification” in bold. “Specification” in Rendering 3 may appear
      in italics (if a Web browser understands the <code>&lt;dfn&gt;</code> tag),
      or it may be no different than the other text in the sentence, as in Rendering
      2 (there is no visual default in any browser for the <code>&lt;span&gt;</code> tag;
      only CSS can change the tag’s appearance).</p>
  </div>
  <div id="examples">
    <div id="renderings">
      <hr />
      <h3><span></span>Renderings:</h3>
      <h4>1. <code>&lt;strong&gt;</code> Tag</h4>
      <p>Even though the definition tag is in the W3C <strong title="Specifications, or “recommendations,” are the guidelines for Web languages.">specification</strong> for
        XHTML, older versions of Netscape do not support it (neither does Lynx).</p>
      <h4>2. <code>&lt;span&gt;</code> Tag</h4>
      <p>Even though the definition tag is in the W3C <span class="keyterm" title="Specifications, or “recommendations,” are the guidelines for Web languages.">specification</span> for
        XHTML, older versions of Netscape do not support it (neither does Lynx).</p>
      <h4>3. <code>&lt;dfn&gt;</code> (Definition) Tag</h4>
      <p>Even though the definition tag is in the W3C <dfn title="Specifications, or “recommendations,” are the guidelines for Web languages.">specification</dfn> for
        XHTML, older versions of Netscape do not support it (neither does Lynx).</p>
      <h4>4. <code>&lt;strong class=&quot;keyterm&quot;&gt;</code> Tag</h4>
      <p>Even though the definition tag is in the W3C <strong class="keyterm" title="Specifications, or “recommendations,” are the guidelines for Web languages.">specification</strong> for
        XHTML, older versions of Netscape do not support it (neither does Lynx).</p>
      <?php show_examplelink("View Renderings Only"); ?>
      <hr />
    </div>
    <div id="quanta">
      <h3><span></span>Quanta</h3>
      <h4>1. <code>&lt;strong&gt;</code> Tag</h4>
      <div class="code">
        <pre><code>&lt;!--XHTML--&gt;<br />&lt;p&gt;Even though the definition tag is in the W3C &lt;<strong>strong</strong> title=&quot;Specifications, or “recommendations,” are the guidelines for Web languages.&quot;&gt;specification&lt;/strong&gt;
  for XHTML, older versions of Netscape do not support it (neither does Lynx).&lt;/p&gt;</code></pre>
      </div>
      <h4>2. <code>&lt;span&gt;</code> Tag</h4>
      <div class="code">
        <pre><code>&lt;!--XHTML--&gt;<br />&lt;p&gt;Even though the definition tag is in the W3C &lt;<strong>span class=&quot;keyterm&quot;</strong> title=&quot;Specifications, or “recommendations,” are the guidelines for Web languages.&quot;&gt;specification&lt;/span&gt;
  for XHTML, older versions of Netscape do not support it (neither does Lynx).&lt;/p&gt;</code></pre>
      </div>
      <h4>3. <code>&lt;dfn&gt;</code> (Definition) Tag</h4>
      <div class="code">
        <pre><code>&lt;!--XHTML--&gt;<br />&lt;p&gt;Even though the definition tag is in the W3C &lt;<strong>dfn</strong> title=&quot;Specifications, or “recommendations,” are the guidelines for Web languages.&quot;&gt;specification&lt;/dfn&gt;
  for XHTML, older versions of Netscape do not support it (neither does Lynx).&lt;/p&gt;</code></pre>
      </div>
      <h4>4. <code>&lt;strong class=&quot;keyterm&quot;&gt;</code> Tag</h4>
      <div class="code">
        <pre><code>&lt;!--XHTML--&gt;<br />&lt;p&gt;Even though the definition tag is in the W3C &lt;<strong>strong class=&quot;keyterm&quot;</strong> title=&quot;Specifications, or “recommendations,” are the guidelines for Web languages.&quot;&gt;specification&lt;/strong&gt;
  for XHTML, older versions of Netscape do not support it (neither does Lynx).&lt;/p&gt;</code></pre>
      </div>
      <h4>1., 2., 3., 4.</h4>
      <p>CSS for making the defnition tag (<code>&lt;dfn&gt;</code>) and <code>keyterm</code> class
        bold:</p>
      <div class="code">
        <pre><code>/* CSS */<br />dfn, .keyterm {
  font-weight: bold;
  font-style: normal;
}</code></pre>
      </div>
    </div>
    <div id="discussion">
      <h3><span></span>Discussion</h3>
      <p>Making key terms of a text bold should be the simplest of design choices:
        email editors, Microsoft Word, and just about any other piece of software
        that enables text enhancement feature a bold <strong>B</strong> icon
        that will turn any selected text bold.</p>
      <p>But in a sustainable Web artifact based on richly descriptive structure,
        choosing the bold icon in a WYSIWYG Web editor might not be the most
        sound visual/structural rhetorical choice: it solves the immediate problem
        of making key terms bold, but the bold button does nothing to structurally
        distinguish key terms from any other bold text.</p>
      <p>There is a structural tag recommended by the W3C called the definition
        tag, <code>&lt;dfn&gt;</code>, that, combined with special instructions
        in CSS, could potentially work for the particular visual-rhetorical choice
        of structurally marking a text’s key terms and displaying them in bold.
        However, even though <a href="http://www.w3.org/TR/html401/index/elements.html"><code>&lt;dfn&gt;</code> is
        in the W3C specification for (X)HTML</a> (World Wide Web Consortium,
        1999), older versions of Netscape do not support it (neither does Lynx).
        Text tagged as <code>&lt;dfn&gt;</code> exhibits no visual difference
        in these browsers; but it is not merely a visual rendering problem. Older
        versions of Netscape do not structurally understand the <code>&lt;dfn&gt;</code> tag,
        so even supplying Netscape with CSS rules for bolding <code>&lt;dfn&gt;</code> will
        have no effect. In the case of designing for users with older browsers,
        the rhetorical choice of descriptive structure is clearly at odds with
        effective visual presentation.</p>
      <p>Another alternative would be to use the all-purpose inline/phrase tag, <code>&lt;span&gt;</code>,
        and assign a unique class to it, like <code>&lt;span class=&quot;keyterm&quot;&gt;</code>.
        This would be more structurally sound than <code>&lt;strong&gt;</code> tags,
        but in non-CSS devices, there would again be no apparent difference in
        the text enclosed in the <code>&lt;span&gt;</code> tag.</p>
      <p>So, in case it is of high importance that all users see key terms in
        bold, neither of the more structurally rich choices—<code>&lt;dfn&gt;</code> or <code>&lt;span
        class=&quot;keyterm&quot;&gt;</code>—will work. The rhetorical choice
        for reaching the most users would be to use the <code>&lt;strong&gt;</code> tag,
        but add a class to it, much like the <code>&lt;span&gt;</code> example
        in Rendering 2 above: <code>&lt;strong class=&quot;keyterm&quot;&gt;</code>.
        While not the best structural solution (which would be <code>&lt;dfn&gt;</code>),
        aided by the <code>keyterm</code> class, it does approach a richer structure
        than the <code>&lt;strong&gt;</code> tag alone while providing bold text
        in a variety of different viewing conditions: a modest visual choice
        that a producer could make available to almost all users, regardless
        of their equipment.</p>
      <p>The only additional drawback is that <code>&lt;strong&gt;</code> is
        audibly rendered, for users of screen readers, using a strong voice—which
        could be addressed in an aural CSS file. Discussions go on for pages
        across the Web among developers as to whether the old <code>&lt;b&gt;</code> (bold)
        tag might not be a better solution for cases like this, in that it provides
        bold text while not disturbing screen readers. The strongest evidence
        against using <code>&lt;b&gt;</code> rather than <code>&lt;strong&gt;</code> is
        that <code>&lt;b&gt;</code> will not, according to the July 26, 2006
        W3C working draft specification, be part of XHTML 2.0 (<a href="http://www.w3.org/TR/2006/WD-xhtml2-20060726/elements.html">http://www.w3.org/TR/2006/WD-xhtml2-20060726/elements.html</a>;
        the latest specification’s elements, or tag names, can be accessed via
        the “elements” link at the top of <a href="http://www.w3.org/TR/xhtml2">http://www.w3.org/TR/xhtml2</a>).</p>
    </div>
    <div id="browser">
      <h3><span></span>Sample Browser Rendering</h3>
      <p>Renderings 2 and 3 exhibit no visible difference for the word “specification,”
        as expected, given that Lynx does not render the span or definition tag
        (Figure 4.1).</p>
      <img class="screencap" src="captures/lynx_structure.jpg" height="541" width="510" alt="JPEG screen capture of example renderings in the Lynx browser." />
      <p class="figurecaption">Figure 4.1: Screen capture of <a href="examples/structure.htm">the
          Renderings-only page</a> in the text-only Lynx browser.</p>
    </div>
  </div>
</div>
<?php show_footer(); ?>

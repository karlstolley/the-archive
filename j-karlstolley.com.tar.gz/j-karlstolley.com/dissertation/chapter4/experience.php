<?php
include('functions.php');
show_header("How to Experience");
show_navigation();
?>

<div id="content">
  <div id="contenthead">
    <h2 id="experience"><span></span>How to Experience</h2>
  </div>
  <div id="examples">
    <div id="discussiononly">
      <blockquote>
        <p>Words about art and design are best explained in the presence of the
          artist’s work. The reader, then, can more readily understand what the
          writer is talking about, and whether opinions expressed are based on
          empirical or theoretical values.<br />
          —Paul Rand (1993, p. xii).</p>
      </blockquote>
      <p>If the renderings-only pages in this chapter are viewed in a fully standards-compliant,
        CSS- and image-capable browser with the Flash plugin, most pages of renderings
        will appear to have the same visual example shown multiple times. While it is
        advisable to experience the chapter in the ideal conditions of an up-to-date
        graphical browser with the most current Flash player and Adobe Reader
        (and Adobe Acrobat, for those who would like to comment on the fully
        graphical screen captures of this chapter), the full impact of the chapter’s use of 
        networked digital production is more apparent under less-than-ideal conditions.
        Readers wishing to view the chapter and its examples under alternative
        conditions may wish to try one or more of the following methods of viewing:</p>
      <ul>
        <li>with the <a href="http://www.mozilla.com/firefox/">Firefox</a> Web
          browser and <a href="https://addons.mozilla.org/firefox/60/">Chris
          Pederick’s Web Developer plugin</a> for Firefox, which allows one to
          turn on or off CSS, images, and a number of other page features in
          order to view a page under a wide variety of different contingencies
          from within a single, standards-compliant browser.</li>
        <li>via the Web browser emulator at <a href="http://www.dejavu.org/emulator.htm">dejavu.org</a> (works only for live Web URLs, not files stored on disk).</li>
        <li>in the text-only Lynx browser:
          <ul>
            <li>Mac OS X users can <a href="http://www.apple.com/downloads/macosx/unix_open_source/lynxtextwebbrowser.html">download
                the text-only Lynx browser</a> for use with Mac OS X’s command-line
                Terminal program (located in the Utilities folder, under Applicatons)</li>
            <li>Readers who have command-line access on a Linux server can also
              try typing “lynx” on their command line.</li>
          </ul>
        </li>
        <li>in older versions of browsers on a test computer
          (this should only be attempted by those with access to a secondary
          computer, and not one’s main personal computer):
          <ul>
            <li>Readers can <a href="http://browser.netscape.com/ns8/download/archive.jsp">download
                and install previous versions of Netscape Navigator</a> (the
                4.x versions are especially interesting).</li>
            <li>Yousif Al Saif (2006) has <a href="http://tredosoft.com/Multiple_IE">created
                an installer for multiple versions of Internet Explorer</a> for
                download. </li>
          </ul>
        </li>
      </ul>
      <p>Pages throughout the chapter also include JPEG images of example screen
        captures in different browsers that render the stand-alone examples in
        interesting or unusual ways.</p>
    </div>
  </div>
</div>
<?php show_footer_ne(); ?>

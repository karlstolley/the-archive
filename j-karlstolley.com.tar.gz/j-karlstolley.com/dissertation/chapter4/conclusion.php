<?php
include('functions.php');
show_header("Conclusion");
show_navigation();
?>

<div id="content">
  <div id="contenthead">
    <h2 id="conclusion"><span></span>Conclusion</h2>
  </div>
  <div id="description"> </div>
  <div id="examples">
    <div id="discussiononly">
      <p>The variety of solutions to each visual/rhetorical design task in this
        chapter suggest the affordances of code-level production literacy, which
        enables the exploration of alternative solutions not readily apparent
        in WYSIWYG Web editors, whose menu-based systems generally limit producers
        to a single, default solution (e.g., for loading a content image).</p>
      <p>However, there are some significant limitations/constraints to the examples
        provided here. First is that there is no way to effectively represent
        revisions over time, which is one of the benefits of separating XHTML
        structured content and CSS presentation. Alternate style sheets could
        have demonstrated the flexibility of working with richly structured XHTML,
        but not the ability of a producer to revisit and revise a design—independent
        of content—over time. Another limitation is the contained, single-page
        nature of each example: in actual practice, CSS would be used again and
        again over multiple pages in a site. While the design of this chapter’s
        pages is an example of that, the individual renderings lack CSS’s reusability.
        Also, with the exception of the coordinated example, each solution is
        devoid of any sense of context with respect to other page elements.</p>
      <p>But those limitations aside, there are some common threads running through
        each example in relation to production:</p>
      <ul>
        <li>Because the structure of the document, especially classes and ids,
          must be coordinated with style declarations in the CSS, becoming code-literate
          greatly improves a producer’s ability to control the connections between
          quanta that result in user experience. This is as much a visual design
          task as it is a writing task; but rather than having the writing task
          be limited to typing text into a new interface (like a WYSIWYG editor),
          networked producers must begin to think more structurally about their
          written and visual content, and how they are structured in relation
          to one another, to a single Web document, and to an entire Web site.</li>
        <li>Readers and producers alike benefit from producers who test their
          networked artifacts under a variety of conditions. Over time, producers
          may begin to get a sense of how their production choices will appear
          for readers with different kinds of equipment without having to test;
          but testing and subsequent revision is still important even for more
          experienced producers—particularly when they are employing solutions
          that respond to unique or unusual visual/rhetorical design tasks.</li>
        <li>While Web standards provide a framework for a basic approach to design
          tasks (e.g., separating structured content in a standard set of XHTML
          tags from visual presentation instructions in CSS), networked digital
          production also takes the rhetorical situation into account. A company’s
          logo, for example, might be integrated with a design image and loaded
          as a background image in CSS; however, to maintain branding in non-CSS
          devices, the logo might be loaded in the XHTML image tag and positioned
          using CSS to fit it with the rest of the design. In other words, any
          networked production choice must be context-dependent, responding to
          more than just the ideals suggested by Web standards.</li>
        <li>It is not rhetorically sound to assume that a standards-based, ideal
          solution will always be viewed by readers in ideal conditions (something
          that may be hard to grasp in an educational or corporate setting where
          everyone seems to have ideal means of access—up-to-date computers on
          fast connections); to reach the widest possible audience (not necessarily
          in terms of number, but in terms of diversity), sometimes multiple
          solutions must be employed to achieve a single design choice: for example,
          using a tiled background image plus a background color that could stand
          in for the tiled image in non-image CSS environments. Although this
          may seem, to the producer, to be extra work that only replicates another,
          preferable design choice, multiple solutions in a single Web page are
          still far superior than creating and maintaining separate, redundant
          Web pages (e.g., a text-only page)—a common practice on the Web that,
          while well intentioned, does not take full advantage of the medium’s
          capacity for single-sourced documents. In other words, addressing multiple
          reader contingencies does not have to mean significantly more work
          for the producer in the future (as when making the same revisions to
          multiple redundant documents).</li>
        <li>Finally, the producer’s awareness of designing and testing for different
          reader experiences introduces some humanity into the medium. This may
          seem antithetical, particularly at first, when a producer is just trying
          to learn to manage the different languages of the medium. (But even
          the languages that seem so robotic and distant start to reveal their
          human sides and inconsistencies, like the CSS <code>background-repeat</code> requiring
          the value <code>no-repeat</code> rather than <code>none</code>, which
          appears much more frequently for other properties.) Developing a digital
          concern for others—disabled people, poor people, or even people whose
          computers don’t function properly—is an important goal in a medium
          that is still largely the product of privileged people: those who can
          afford the advanced software for building in it, and who are used to
          having access to all of the very latest and best browsers and plugins
          for their own ideal experiences on the Web.</li>
      </ul>
    </div>
  </div>
</div>
<?php show_footer_ne(); ?>

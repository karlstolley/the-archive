<?php

function show_header($title) {
print "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\">
<head>
  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
  <title>" . $title ."</title>
  <style type=\"text/css\" media=\"screen\">
    <!--
    @import url(\"css/advanced.css\");
    @import url(\"css/examples.css\");
    -->
  </style>
  <!--[if IE]>
    <link rel=\"stylesheet\" type=\"text/css\" href=\"css/advanced_ie.css\" media=\"screen\" />
  <![endif]-->
  <!--[if IE 6]>
    <link rel=\"stylesheet\" type=\"text/css\" href=\"css/advanced_ie6.css\" media=\"screen\" />
  <![endif]-->
  <link rel=\"stylesheet\" type=\"text/css\" href=\"css/printable.css\" media=\"print\" />
  <script src=\"scripts/sifr.js\" type=\"text/javascript\"></script>
  <script src=\"scripts/sifr-addons.js\" type=\"text/javascript\"></script>
</head>\n";
if ($title=='Introduction' || $title=='How to Experience' || $title=='Conclusion' || $title=='References' || $title=='Colophon') {print "<body id=\"discussionpage\">\n";}
else { print "<body>\n"; }
print"<div id=\"container\">
  <div id=\"header\">
  	<span></span>
    <h1>Chapter 4: Design, Emergence, Experience</h1>
    <p>Karl Stolley, <em>An Art of Emergent Visual Rhetoric</em> (Doctoral Dissertation)</p>
  </div>";
}

function show_navigation() {
print "  <div id=\"navigation\">
    <h3><span></span>Chapter Contents</h3>
    <ol>
      <li><a href=\"index.htm\">Introduction</a></li>
	  <li><a href=\"experience.htm\">How to Experience</a></li>
	  <li><strong>Visual/Rhetorical Design Tasks:</strong>
	    <ul>
          <li><a href=\"charactersets.htm\">Character Encoding</a></li>
	      <li><a href=\"structure.htm\">Richly Descriptive Structure</a></li>
	      <li><a href=\"systemfonts.htm\">System Fonts</a></li>
	      <li><a href=\"replacement.htm\">Text Replacement</a></li>
	      <li><a href=\"redsquare.htm\">Red Squares</a></li>
          <li><a href=\"contentimage.htm\">Content Images</a></li>
          <li><a href=\"treatedimage.htm\">Treated Images</a></li>
	      <li><a href=\"flexpoints.htm\">Flexible Layout</a></li>
		  <li><a href=\"coordinated.htm\">Coordinated Example</a></li>
	  </ul>
	  </li>
	  <li><a href=\"conclusion.htm\">Conclusion</a></li>
	  <li><a href=\"pagefeatures.htm\">Guide to Page Features</a></li>
	  <li><a href=\"references.htm\">References</a></li>
	  <li><a href=\"colophon.htm\">Colophon</a></li>
	</ol>
	<!--<ul>
	  <li><a href=\"#\">Complete Dissertation (PDF)</a></li>
    </ul>-->
  </div>";
 }
function show_examplelink($linktext) {
$request = array('/dissertation/chapter4/', '.htm');
$exmpfile = array('examples/', '.htm');
$exmpuri = str_replace($request, $exmpfile, $_SERVER['REQUEST_URI']);
print "<p class=\"renderlink\"><a href=\"" . $exmpuri . "\">" . $linktext . "</a></p>";
}
function show_footer() {
/*This will eventually need some additional stuff for the JPEG, PDF, etc. 
Reusing file names so that a different extension can be used would be smart 
(e.g., redsquare.htm, redsquare.jpg, redsquare.pdf)*/
$fullurl = "http://www.karlstolley.com" . $_SERVER['REQUEST_URI'];
$request = array('/dissertation/chapter4/', '.htm');
/*$exmpfile = array('/dissertation/chapter4/examples/', '.htm');*/
$exmpfile = array('examples/', '.htm');
$jpegfile = array('png/', '.png');
$pdffile = array('pdf/', '.pdf');
$jpeguri = str_replace($request, $jpegfile, $_SERVER['REQUEST_URI']);
$pdfuri = str_replace($request, $pdffile, $_SERVER['REQUEST_URI']);
$exmpuri = str_replace($request, $exmpfile, $_SERVER['REQUEST_URI']);
print "  <div id=\"footer\"><ul><li><a href=\"" . $fullurl . "\">URL: " . $fullurl . "</a></li>
<li><a href=\"" . $exmpuri . "\">Renderings Only</a></li>
<li><a href=\"" . $pdfuri . "\">PDF Screen Capture For Commenting</a></li>
<li><a href=\"" . $jpeguri . "\">Archived Page Image</a></li>
</ul></div>
</div>
</body>
</html>";
}
function show_footer_ne() {
/*This will eventually need some additional stuff for the JPEG, PDF, etc. 
Reusing file names so that a different extension can be used would be smart 
(e.g., redsquare.htm, redsquare.jpg, redsquare.pdf)*/
$fullurl = "http://www.karlstolley.com" . $_SERVER['REQUEST_URI'];
$request = array('/dissertation/chapter4/', '.htm');
$exmpfile = array('/dissertation/chapter4/examples/', '.htm');
$jpegfile = array('png/', '.png');
$pdffile = array('pdf/', '.pdf');
$jpeguri = str_replace($request, $jpegfile, $_SERVER['REQUEST_URI']);
$pdfuri = str_replace($request, $pdffile, $_SERVER['REQUEST_URI']);
$exmpuri = str_replace($request, $exmpfile, $_SERVER['REQUEST_URI']);
print "  <div id=\"footer\"><ul><li><a href=\"" . $fullurl . "\">URL: " . $fullurl . "</a></li>
<li><a href=\"" . $pdfuri . "\">PDF Screen Capture For Commenting</a></li>
<li><a href=\"" . $jpeguri . "\">Archived Page Image</a></li>
</ul></div>
</div>
</body>
</html>";
}
?>
	
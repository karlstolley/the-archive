<?php
include('functions.php');
show_header("References");
show_navigation();
?>

<div id="content">
  <div id="contenthead">
    <h2 id="references"><span></span>References</h2>
  </div>
  <div id="description"> </div>
  <div id="examples">
    <div id="discussiononly">
      <p class="ref">Al Saif, Y. (2006). <cite>Install multiple versions of IE
          on your PC.</cite> Retrieved April 4, 2007, from <a href="http://tredosoft.com/Multiple_IE">http://tredosoft.com/Multiple_IE</a></p>
      <p class="ref">Barthes, R. (1977). <cite>Image, music, text</cite> (S.
        Heath, Trans.). New York: Hill and Wang.</p>
      <p class="ref">Bertalanffy, L. von (1968). <cite>General system theory:
          Foundations, development, applications</cite>. New York: Gorge Braziller.</p>
      <p class="ref">Davidson, M. (2005, April 27). <cite>sIFR 2.0: Rich accessible
          typography for the masses</cite>.  Retrieved April 13, 2007, from <a href="http://www.mikeindustries.com/sifr/">http://www.mikeindustries.com/sifr/</a></p>
      <p class="ref">Farrell, T. B. (1993). <cite>Norms of rhetorical culture</cite>.
        New Haven, CT: Yale University Press.</p>
      <p class="ref">McLellan, D. (2002, November 9). Flash satay: Embedding
        Flash while supporting standards. <cite>A List Apart: For People Who
        Make Websites, 154 </cite>. Retrieved April 13, 2007 from <a href="http://alistapart.com/articles/flashsatay">http://alistapart.com/articles/flashsatay</a></p>
      <p class="ref">Rand, P. (1993). <cite>Design, form, and chaos</cite>. New
        Haven: Yale UP.</p>
      <p class="ref">Shea, D. (n.d.). Revised image replacement. <cite>mezzoblue:
          Testing grounds.</cite> Retrieved April 13, 2007, from <a href="http://www.mezzoblue.com/tests/revised-image-replacement/">http://www.mezzoblue.com/tests/revised-image-replacement/</a></p>
      <p class="ref">World Wide Web Consortium. (1999, December 24). Index of
        elements. In <cite>HTML 4.01 specification</cite>. Retrieved April 10,
        2007, from <a href="http://www.w3.org/TR/2006/WD-xhtml2-20060726/elements.html">http://www.w3.org/TR/2006/WD-xhtml2-20060726/elements.html</a></p>
      <p class="ref">World Wide Web Consortium. (2006, July 26). List of elements.
        In <cite>XHTML™ 2.0 (W3C working draft)</cite>. Retrieved April 10, 2007,
        from <a href="http://www.w3.org/TR/2006/WD-xhtml2-20060726/elements.html">http://www.w3.org/TR/2006/WD-xhtml2-20060726/elements.html</a></p>
      <p class="ref">World Wide Web Consortium. (n.d.). <cite>Help for the W3C markup
        validation service</cite>. Retrieved April 12, 2007, from http://validator.w3.org/docs/help.html</p>
    </div>
  </div>
</div>
<?php show_footer_ne(); ?>

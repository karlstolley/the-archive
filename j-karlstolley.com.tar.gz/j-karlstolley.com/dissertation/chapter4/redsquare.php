<?php
include('functions.php');
show_header("Red Squares");
show_navigation();
?>

<div id="content">
  <div id="contenthead">
    <h2><span></span>Visual Rhetorical Task:</h2>
    <p>Present readers with a red square.</p>
  </div>
  <div id="description">
    <h3><span></span>Description</h3>
    <p>Readers experiencing this page in <a href="http://www.mozilla.com/en-US/" class="external">a
        fully standards-compliant browser</a> with CSS and images enabled and <a href="http://www.adobe.com/products/flashplayer/" class="external">the
        latest Flash plugin</a>, should indeed see what appear to be three identical
        150 pixel by 150 pixel red squares in the Renderings area.</p>
    <p>But each red square has a different type of emergence to it. The square
      in Rendering 1 is generated purely through CSS manipulating XHTML; it is
      visible only when a browser renders it according to the instructions written
      in the CSS. Th square in Rendering 2 is a JPEG image, loaded via the XHTML <code>&lt;img&gt;</code> tag,
      while Rendering 3 is a square, one-frame Flash movie loaded through the <code>&lt;object&gt;</code> tag,
      using a modified version of McLellan’s (2002) <a href="http://alistapart.com/articles/flashsatay" class="external">standards-compliant
      “Satay Method”</a> for loading Flash.</p>
  </div>
  <div id="examples">
    <div id="renderings">
      <hr />
      <h3><span></span>Renderings:</h3>
      <h4>1. XHTML/CSS Square</h4>
      <div class="redsquarecss" title="Square 1">
        <p>Square 1: Most visual browsers for sighted users will render a red
          square here, using instructions from the CSS file this page links to.
          (The CSS hides this text.)</p>
      </div>
      <h4>2. JPEG Square</h4>
      <img class="redsquarejpg" src="images/red-square.jpg" height="150" width="150" alt="Square 2: A JPEG image of a red square. (This is text in the img tag's alt attribute.)" title="Square 2"/>
      <h4>3. Flash Square</h4>
      <object class="redsquareswf" type="application/x-shockwave-flash" data="swf/red-square.swf" width="150" height="150" title="Square 3">
        <param name="movie" value="swf/red-square.swf" />
        <p title="Square 3">Square 3: Browsers without Flash capability will
          display this text instead of the red square Flash movie.</p>
      </object>
      <hr />
      <?php show_examplelink("View Renderings Only"); ?>
    </div>
    <div id="quanta">
      <h3><span></span>Quanta</h3>
      <h4>1. XHTML/CSS Square</h4>
      <div class="code">
        <pre><code>&lt;!--XHTML--&gt;<br />&lt;div class=&quot;redsquarecss&quot; title=&quot;Square 1&quot;&gt;<br />  &lt;p&gt;Square 1: Most visual browsers for sighted users will render<br />     a red square here, using instructions from the CSS file this page<br />    links to. (The CSS hides this text.)&lt;/p&gt;<br />&lt;/div&gt;<br />

/* CSS */<br />div.redsquarecss {<br />  height: 150px;<br />  width: 150px;<br />  background-color: #FF0000;<br />}<br />div.redsquarecss * {<br />  display: none;<br />}</code></pre>
      </div>
      <h4>2. JPEG Square</h4>
      <ul>
        <li><a href="images/red-square.jpg">Image (JPEG)</a></li>
        <li>Code:
          <div class="code">
            <pre><code>&lt;img class=&quot;redsquarejpg&quot; src=&quot;images/red-square.jpg&quot; height=&quot;150&quot; width=&quot;150&quot; alt=&quot;Square 2: A JPEG image of a red square. (This is text in the img tag's alt attribute.)&quot; title=&quot;Square 2&quot;/&gt;</code></pre>
          </div>
        </li>
      </ul>
      <h4>3. Flash Square</h4>
      <ul>
        <li><a href="swf/red-square.swf">Flash Movie (SWF)</a></li>
        <li>Code:
          <div class="code">
            <pre><code>&lt;!--XHTML--&gt;
&lt;object class=&quot;redsquareswf&quot; type=&quot;application/x-shockwave-flash&quot; data=&quot;swf/red-square.swf&quot; width=&quot;150&quot; height=&quot;150&quot; title=&quot;Square 3&quot;&gt;<br />  &lt;param name=&quot;movie&quot; value=&quot;swf/red-square.swf&quot; /&gt;<br />  &lt;p title=&quot;Square 3&quot;&gt;Square 3: Browsers without Flash capability will<br />    display this text instead of the red square Flash movie.&lt;/p&gt;<br />&lt;/object&gt;
</code></pre>
          </div>
        </li>
      </ul>
    </div>
    <div id="discussion">
      <h3><span></span>Discussion</h3>
      <p>Four key ideas regarding the rhetorical nature of networked digital
        production that can be taken from this simple rendering of a red square:</p>
      <ul>
        <li>There are usually multiple technological solutions to any given problem—but
          different solutions are most apparent when production for the Web medium
          is engaged at the code level. The most obvious solution, the JPEG image,
          could be easily employed by a WYSIWYG like Dreamweaver—but the solution
          is dependent on a low-compression JPEG to accurately match system color
          (in hexadecimal, <code>#FF0000</code>). Flash may seem to be another
          simple WYSIWYG solution, but Flash’s HTML output is non-standard, which
          certainly cannot be rectified except by writing new code, as McLellan
          (2002) demonstrated. To arrive at a best design solution requires a
          solid rhetorical and technological understanding of the digital/Web
          medium.</li>
        <li>An essential aspect of ensuring positive user experience is providing
          for alternative experiences in the production: in the case of the red
          squares, different media types (Flash, JPEG); XHTML text hidden by
          CSS; alternate text for images using the <code>alt</code> attribute.
          Some alternatives might also be gracefully kept hidden from browsers
          that would otherwise render them incorrectly, as by loading the CSS
          for creating the first red square by using <code>@import</code> rather
          than a <code>&lt;link&gt;</code> tag.</li>
        <li>In addition to the user’s physical abilities (sight), her browser,
          technological conditions, and preferences (e.g., turning off CSS) are
          the ultimate determining factors of a page’s appearance—despite all
          of a rhetorically-minded designer’s best intentions, including allowances
          for user contingencies like those affecting the red squares. Emergent
          visual rhetoric is never the same at all times, for all users; instead,
          it guides digital producers in allowing for some of the more common
          viewing contingencies of a digital artifact, so that the best possible
          visual experience emerges.</li>
        <li>And finally, the overall rhetorical effect of the visual content
          or design in question must be addressed: just how important is it,
          for example, to display a red square? That level of importance will
          also help a producer determine which technique to use.</li>
      </ul>
      <p>Because the three red squares are identical under many conditions, the
        best solution depends largely on audience. If it is a matter of reaching
        the most browsers, including older ones or alternative devices (like
        cell phones), the JPEG image would work best, as older browsers, like
        Netscape 4.x, and cell phones cannot properly size the <code>&lt;div&gt;</code> in
        the source code. As purely a matter of economy, the XHTML/CSS square
        would work best—especially for an audience that could be expected to
        be using a standards-compliant browser.</p>
      <p>Individual squares work well for a demonstration, but in actual use,
        all three would might be nested together in attempt to guarantee that
        under almost any circumstances, readers would encounter a red square:
        in Flash; then the JPEG or the CSS square (depending on whether images
        and/or CSS were enabled on the reader’s browser, were the Flash plugin
        unavailable). And if nothing else, users will see the alternate text
        “Red square image” from the <code>&lt;img&gt;</code> tag’s alt attribute.
        And if the different squares were merged together, which version a user
        sees is moot, as the CSS, JPEG, and Flash squares should be completely
        identical. However, the Flash square is overkill: the lowest-tech, sustainable
        solution is almost always preferable.</p>
    </div>
    <div id="browser">
      <h3><span></span>Sample Browser Rendering</h3>
      <p>Netscape 4.8 correctly renders the JPEG square; but not understanding
        the “box model” of CSS nor the <code>display: none;</code> CSS property,
        it offers an interesting rendering of the XHTML/CSS square. The Flash
        square is displayed correctly, but Netscape 4.8 incorrectly displays
        the paragraph nested inside the <code>&lt;object&gt;</code> tag, too.
        (Figure 4.3).</p>
      <img class="screencap" src="captures/ns4_redsquare.jpg" height="776" width="510" alt="JPEG screen capture of Netscape 4.8’s renderings of the red squares." />
      <p class="figurecaption">Figure 4.3: Netscape 4.8’s renderings of <a href="examples/redsquare.htm">the
          red squares</a>.</p>
    </div>
  </div>
</div>
<?php show_footer(); ?>

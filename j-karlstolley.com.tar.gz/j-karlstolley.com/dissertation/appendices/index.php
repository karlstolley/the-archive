<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>An Art of Emergent Visual Rhetoric, Appendices</title>
</head>
<body>
<div id="disscontainer">
<h1><span><cite>An Art of Emergent Visual Rhetoric</cite></span></h1>
<h2>Appendices</h2>
<p>Note: Follow the [View...code] links to see plain-text rendering of the code. <strong>Certain
		browsers, like Firefox, will add syntax-highlighting to the XHTML if you follow
		the page links and choose View Source from your browser's menu.</strong> Syntax
		highlighting makes the code much more readable.</p>
<ul>
	<li><a href="roscoe_original/index.htm">Appendix A: Professor Roscoe's Original Page</a> (Invalid
		HTML with Display Attributes and Tables [<a href="roscoe_original/index.htm.txt">View
		HTML code</a>]</li>
	<li>Structural Revisions:
		<ul>
			<li><a href="roscoe_revision/pure_structure_revision.htm">Appendix B: Pure Structure Revision</a> (tag
				elements only, no links for clarity) [<a href="roscoe_revision/pure_structure_revision.htm.txt">View
				XHTML code with comments</a>]</li>
			<li><a href="roscoe_revision/pure_structure_revision_links.htm">Appendix C: Pure Structure
					Revision Plus Links</a> (tag elements only, with links) [<a href="roscoe_revision/pure_structure_revision_links.htm.txt">View
					XHTML code with comments</a>]</li>
			<li><a href="roscoe_revision/local_structure_revision.htm">Appendix D: Local Structure
					Revision</a> (tag elements plus unique <code>ids</code>) [<a href="roscoe_revision/local_structure_revision.htm.txt">View
					XHTML code with comments</a>]</li>
			<li><a href="roscoe_revision/additional_structure_revision.htm">Appendix E: Additional
					Structure Revision</a> (<code>div</code> tags plus <code>ids</code>) [<a href="roscoe_revision/additional_structure_revision.htm.txt">View
					XHTML Code</a>]</li>
		</ul>
	</li>
	<li>CSS Recreations of Roscoe's Page Design:
		<ul>
			<li><a href="roscoe_revision/local_styles_revision.htm">Appendix F: Local Structure, Basic
					Styles</a> [<a href="roscoe_revision/basic_styles.css">View Basic CSS code
					with comments</a>]</li>
			<li><a href="roscoe_revision/local_styles_advanced_revision.html">Appendix G: Local Structure,
					Advanced Styles</a> [<a href="roscoe_revision/advanced_styles.css">View Advanced
					CSS code with comments</a>]</li>
			<li><a href="roscoe_revision/all_styles.htm">Appendix H: Additional Structure, Advanced
					Styles</a> [<a href="roscoe_revision/basic_styles.css">View Basic CSS code</a> with
					comments, <a href="roscoe_revision/advanced_styles.css">Advanced CSS code</a> with
					comments]</li>
			<li><a href="roscoe_revision/clean_styles.htm">Appendix I: Final Page Revision</a> (no
				comments) [<a href="roscoe_revision/basic_clean.css">View Basic CSS</a>, <a href="roscoe_revision/advanced_clean.css">View
				Advanced CSS</a>, <a href="roscoe_revision/clean_styles.htm.txt">View XHTML</a>]</li>
		</ul>
	</li>
</ul>
</li>
</ul>
</div>
</body>
</html>

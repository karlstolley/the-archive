$(function(){
  $('html').removeClass('no-js').addClass('has-js');

  //Take the first child paragraph inside of .main, and make it a subhead in <header>
  //Iterate over possibly multiple article elements (as will be the case on Tumblr)
  $.each($('article'), function() {
    var tagline = $(this).find('.section .main > p:first-child');
    if (tagline.text() != '') {
      tagline.closest('.section').prev('header').append('<h3>'+tagline.html()+'</h3>');
      tagline.detach();
    }
  });

});

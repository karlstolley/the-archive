---
title: Home
description: A quick look at my projects and teaching.
layout: default
classes: showcase
---

Read more [about me](/about/), or have a look at [my vita](/cv/).

# Current Courses

<ul>
<li>
  <figure>
    <div class="image">
      <a href="https://courses.karlstolley.com/hci/">
        <img srcset="/assets/img/course-hci-1160.png 1160w, /assets/img/course-hci-660.png 660w, /assets/img/course-hci-410.png 410w, /assets/img/course-hci-330.png 330w" sizes="(min-width: 1000px) 30vw, (min-width: 600px) 41vw, 100vw"  src="/assets/img/course-hci-330.png" alt="Screen capture of HCI and Web Design course site." />
      </a>
    </div>
    <figcaption>
      <h2><a href="https://courses.karlstolley.com/hci/">Human-Computer Interaction and Web Design</a></h2>
      <p>
        Principles and practices of HCI through a mobile-first approach to web design and
        development.
      </p>
    </figcaption>
  </figure>
</li>
<li>
  <figure>
    <div class="image">
      <a href="https://courses.karlstolley.com/te/">
        <img srcset="/assets/img/course-te-1160.png 1160w, /assets/img/course-te-660.png 660w, /assets/img/course-te-410.png 410w, /assets/img/course-te-330.png 330w" sizes="(min-width: 1000px) 30vw, (min-width: 600px) 41vw, 100vw" src="/assets/img/course-te-330.png" alt="Screen capture of Technical Editing course site." />
      </a>
    </div>
    <figcaption>
      <h2><a href="https://courses.karlstolley.com/te/">Technical Editing</a></h2>
      <p>
        Online course covering theory and principles of editing through intensive applied practice.
      </p>
    </figcaption>
  </figure>
</li>
<!--
<li class="extra">
  <figure>
    <div class="image">
      <a href="https://courses.karlstolley.com/dw/">
        <img srcset="/assets/img/course-dw-1160.png 1160w, /assets/img/course-dw-660.png 660w, /assets/img/course-dw-410.png 410w, /assets/img/course-dw-330.png 330w" sizes="(min-width: 1000px) 30vw, (min-width: 600px) 41vw, 100vw" src="/assets/img/course-dw-330.png" alt="Screen capture of Digital Writing course site." />
      </a>
    </div>
    <figcaption>
      <h2><a href="https://courses.karlstolley.com/dw/">Digital Writing</a></h2>
      <p>
        Rhetorical theory and applied practice of digital writing.
      </p>
    </figcaption>
  </figure>
</li>
-->
</ul>

# Recent Work

* <div class="image">
    <a href="https://github.com/karlstolley/kairos-toolbar/">
      <img srcset="/assets/img/work-kairos-toolbar-1160.png 1160w, /assets/img/work-kairos-toolbar-660.png 660w, /assets/img/work-kairos-toolbar-410.png 410w, /assets/img/work-kairos-toolbar-330.png 330w" sizes="(min-width: 1000px) 30vw, (min-width: 600px) 41vw, 100vw" src="/assets/img/work-kairos-toolbar-330.png" alt="Screen capture of the Kairos Toolbar." />
    </a>
  </div>

  ## [Kairos Toolbar](https://github.com/karlstolley/kairos-toolbar/)
  A jQuery plugin and structural/visual redesign of the Kairos Toolbar, which brands [Kairos webtexts](http://kairos.technorhetoric.net/) and provides citation information in multiple styles. Fully responsive, whether the webtexts loading it are or not.

# Greatest Hits

* <div class="image">
    <a href="http://kairos.technorhetoric.net/20.2/inventio/stolley/">
      <img srcset="/assets/img/work-lofi-v2-1160.png 1160w, /assets/img/work-lofi-v2-660.png 660w, /assets/img/work-lofi-v2-410.png 410w, /assets/img/work-lofi-v2-330.png 330w" sizes="(min-width: 1000px) 30vw, (min-width: 600px) 41vw, 100vw" src="/assets/img/work-lofi-v2-330.png" alt="Screen capture of the Lo-Fi Manifesto webtext." />
    </a>
  </div>

  ## [The Lo-Fi Manifesto](http://kairos.technorhetoric.net/20.2/inventio/stolley/)
  Probably my most cited work, released in v. 2.0 for Kairos’s 20th birthday. If you want to get what I’m about, just read that.
* <div class="image">
    <a href="http://sustainablewebdesign.com/book/">
      <img srcset="/assets/img/work-webbook-1160.png 1160w, /assets/img/work-webbook-660.png 660w, /assets/img/work-webbook-410.png 410w, /assets/img/work-webbook-330.png 330w" sizes="(min-width: 1000px) 30vw, (min-width: 600px) 41vw, 100vw" src="/assets/img/work-webbook-330.png" alt="Screen capture of companion site for my first book." />
    </a>
  </div>

  ## [How to Design and Write Web Pages Today](http://sustainablewebdesign.com/book/)
  My first book, a theoretical and applied treatment of web writing and design at the source level. The title was chosen by the publisher; it’s not my favorite. Currently under contract for a revised & expanded edition (ms due July 2016).

# Contact Me
My contact information is all over [the top](#page) of the page. You’re welcome to use it. I prefer Twitter @-messages to email, and email to the phone. All three make it to some device or another more or less instantaneously. So don’t be a stranger.

<!-- From new (mt) server -->

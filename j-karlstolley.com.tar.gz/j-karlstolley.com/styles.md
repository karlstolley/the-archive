---
title: Site Styles
description: It’s all styles, all the time.
layout: default
classes: textheavy
---

This short paragraph actually becomes part of the header when everything works right.

# First-Level Heading of Heading Levels

## The Second Level is Quite Good, Obviously

### Drilling Down to the Third Level of Heading

#### The Rarely Seen, Fourth-Level Heading is Here

I am just a normal paragraph of text, absolutely as vanilla and uninteresting as you might imagine. However, given that Karl’s is an academic’s website, there is always a temptation to go nuts on the text, and so I will probably be showing up a lot.

That’s true.

1. **And here is an ordered list**, of the vanilla variety. It’s quite boring, even if some of it’s items can get quite long, as in this one.
1. Some items can be *a bit on the shorter side*.
1. And some.
1. Are very, very.
1. Very short indeed.

And here’s an interceding paragraph, because it seems impossible to conceive of one list immediately follow another without some vapid commentary first.

Before the next bulleted list, let’s have a look at some ``inline code``, as that gets used in ``different places``.

* That brings us to the garden-variety unordered (or bulleted) list. It’s quite boring, even if some of it’s items can get *quite long, as in this one*.
* Some items can be a bit on the shorter side.
* And some.
* Are very, very.
* Very short indeed.

Yet more paragraph nonsense. Perhaps it could be a transition to a blockquote:

  > Blockquotes are of course my favorite. Because who doesn’t like a good quote?

And while this probably won’t show up on my personal site, I expect the blog will have more source code examples; here’s Coderay doing it’s thing:

~~~~
@karl = Karl.new
@karl.does_something_awesome
@karl.favorite_number = 4 + 4
~~~~
{:.language-ruby}

I also might need something like this:

[A Nice Button](#null){:.button}

And one last paragraph to close things off, because that’s how paragraphs do.

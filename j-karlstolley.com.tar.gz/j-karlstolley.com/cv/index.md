---
title: CV
description: Curriculum Vitae
layout: default
classes: cv textheavy
---

An abridged version of my professional resume. Last updated May 2016.

# Education

* ### PhD in English. Purdue University, August 2007.
  * **Specializations**: Rhetoric, Technology, and Digital Writing; Theory and Cultural Studies.
  * **Dissertation**: *An Art of Emergent Visual Rhetoric*.
  * **Committee**: Patricia Sullivan (Chair), David Blakesley, Thomas Rickert, and Petrônio Bendito.
* ### MA in English. Purdue University, August 2002.
* ### BA in English Writing. Millikin University, May 2000.
  * **Honors Thesis**: *‘Hideously and Improbably Deformed’: A Reader’s Guide to David Foster Wallace’s* Infinite Jest. Advisor: Becky Bradway.


# Professional History

* **Associate Professor of Digital Writing & Rhetoric** (Tenured). Illinois Institute of Technology, Chicago, IL, 2012-present.
* **Director of Graduate Studies**. Illinois Institute of Technology, Department of Humanities, Chicago, IL, 2011-2016.
* Assistant Professor of Technical Communication. Illinois Institute of Technology, Chicago, IL. 2007-2012.
* Visiting Adjunct for the New Media Studies program. DePaul University, Chicago, IL. Winter 2007.
* Graduate Lecturer, Purdue University, West Lafayette, IN. 2006-2007.
* Teaching Assistant, Purdue University, West Lafayette, IN. 2000-2006.

# Publications

## Books

* *How to Design and Write Web Pages Today*. Greenwood Writing Today Series. (Greenwood Press, 2011)
* *How to Design and Write Web Pages Today*, 2nd ed. ABC-CLIO/Greenwood. (Under contract; ms due July 2016)

## Refereed Articles

* “The Lo-Fi Manifesto, v. 2.0.” Available http://kairos.technorhetoric.net/20.2/ (January 2016).
* “Source Literacy: A Vision of Craft,” *Enculturation: A Journal of Rhetoric, Writing, and Culture* 14. Available http://enculturation.net/node/5271 (October 2012).
* “Using Microformats: Gateway to the Semantic Web.” *IEEE Transactions on Professional Communication* 52(3), 291-302. (September 2009).
* “Integrating Social Media into Existing Work Environments: The Case of Delicious.” *Journal of Business and Technical Communication* 23(3), 350-371. (July 2009).
* “The Lo-Fi Manifesto.” *Kairos: A Journal of Rhetoric, Technology, and Pedagogy* 12(3). Available http://kairos.technorhetoric.net/12.3/ (May 2008).
* “Teaching Sustainable Web Design and Development.” (In process for the IEEE International Professional Communication Conference proceedings.)
* “Curricular Implementations of Sustainable Web Production.” CPTSC Conference Proceedings, 2007.
* “Rhetorical Arts of Invention in Visual Communication.” In R. E. Griffin, B. D. Cowden, & M. Avgerinou (Eds.). *Imagery and Artistry: Animating the Mind’s Eye*. Loretto, PA: International Visual Literacy Association, 2006. 213-217.

## Book Chapters

* “MVC, Materiality, and the Magus: The Rhetoric of Source-Level Production.” In Ridolfo, J. and W. Hart-Davidson, eds., *Rhetoric and the Digital Humanities*. University of Chicago Press. (Refereed. Fall 2014); book received the 2016 Computers & Composition Distinguished Book Award.
* “Developing a Course Wiki for Accessibility and Sustainability.” In Pullman, G. & Gu, B., eds., *Designing Web-Based Applications for 21st Century Classrooms*. Baywood. (Invited; refereed, 2013).
* “Designing for the Web.” In Riley, K. & Mackiewicz, J., *Visual Composing*. Prentice Hall. (Non-refereed; Prentice Hall, 2011).

## Edited

* Editor, with David Blakesley, Bob Stein, et al. *Digital Publishing F5 &brvbar; Refreshed*. West Lafayette, IN: Parlor Press, 2003.

## Technology Press

* “Reading Ruby for Professional Development,” *SitePoint Ruby*. Available http://www.sitepoint.com/reading-ruby-professional-development/ (Non-refereed; April 2014).

## Selected In-Progress Projects

* *Writing Teachers Writing Software* (ed.) A critical, open-access edition of Paul LeBlanc’s 1993 classic book. Securing the copyright and critical essays to accompany a digital release. Publisher TBD.


## Interviews

* “My Teaching Life: Karl Stolley,” *Association of Teachers of Technical Writing Bulletin*. Available http://www.attw.org/blogs/bulletin/my-teaching-life-karl-stolley (June 2014).

# Digital Production Work

* ### Push: Research & Applied Theory in Writing with Source
  Founded and designed experimental new open-access journal that uses GitHub to make all stages of publishing and review public. Push received mention in Nature as part of an article on open-access publishing; early open-review participants include Ward Cunningham, creator of wiki technology. http://push.cwcon.org/ Project is ongoing.

* ### Newberry Library Digital Collections for Classroom Use
  Design and development of a Ruby on Rails application to deliver a Web-accessible collection of digitized artifacts and supporting materials for secondary schoolteachers’ classroom use. Emphasizing interactivity on tablet devices. (September 2011-May 2013.) http://dcc.newberry.org/

* ### Rhetoric.io
  Design and development of a Ruby on Rails application to support research exchange in rhetoric and communication over an open API written in JSON. Project is ongoing.

* ### Kairos: A Journal of Rhetoric, Technology, and Pedagogy Redesign
  Award-winning redesign to improve accessibility and long-term sustainability of the longest-running digital journal in rhetoric and writing. Included developing a citation tool to simplify citation of the journal. Redesign completed in collaboration with Kathie Gossett (Iowa State University) and Doug Eyman (George Mason University).

* ### Gewgaws Lab
  Design, development, execution, and ongoing improvement and maintenance of a computer lab, dedicated to the technical communication program, that runs Linux and pursues open-source technologies for instruction and research in technical communication and related areas. Run in collaboration with librarians and library IT staff at IIT’s Paul V. Galvin Library.

* ### Purdue OWL. Content management system creation and visual redesign, 2004-2007.
  This project aimed at increasing the accessibility and usability of the Purdue OWL, which receives tens of millions of visitors each year. The redesigned OWL features a robust back-end management interface to easily add and modify content, while employing Web standards to improve future access to OWL materials.

# Honors and Awards

* **CCCC Technology Innovator Award**, May 2016. “Presented, as occasion demands, to a person who has served or serves as an exemplar for teachers working with computer technologies in their classes and who represents the highest ideals of scholarship, teaching, and service to the entire profession.” Full award description at <http://computersandwriting.org/innovator>.
* **Dean’s Award for Excellence in Teaching**, IIT College of Science and Letters, December 2010. Award presented for superlative teaching evaluations and letters of support from current and former students.
* **Computers & Composition Michelle Kendrick Outstanding Digital Production/Scholarship Award**, June 2009. Received along with Douglas Eyman (George Mason University) and Kathie Gossett (Iowa State University) for the *Kairos* redesign.
* **Council of Editors of Learned Journals Best Journal Design Award**, December 2008.
Award presented to the journal Kairos following the journal redesign project that I lead, in collaboration with Douglas Eyman and Kathie Gossett.
* **Purdue University Excellence in Graduate Teaching Award**, 2005.
* **Janice M. Lauer Award for Excellence in Dissertation Work**, 2005.

# Presentations, Lectures, and Workshops

## Invited

* “Writing Teachers Writing Software.” (Invited public dialog). Conference on College Composition and Communication, Tampa, FL, March 2015.
* “Developing Web Apps: Foundations in HTML5.” (Invited workshop). Society for Technical Communication Summit, Phoenix, AZ, May 2014.
* “Developing Web Apps: Front-end Interaction.” (Invited workshop). Society for Technical Communication Summit, Phoenix, AZ, May 2014.
* “In Search of Troublesome Digital Writing: A Meditation on Difficulty.” (Keynote). Computers and Writing, Frostburg State University, June 8, 2013.
* “Threshold Concepts, Accessibility, and Student Development.” (Keynote). Student Affairs Technology Chicago (#SATechChi), Northwestern University, July 29, 2013.
* “Program or Be Programmed.” (Featured ‘town hall’ presentation with Mark Sample, Annette Vee, and Alexandria Lockett). Computers and Writing, North Carolina State University, May 19, 2012.
* “Web Accessibility and Universal Design.” (Workshop). Northern Illinois University/Society for Technical Communication Institute for Professional Development. Northern Illinois University Naperville Campus, July 16, 2011.
* “Learning from Linux: Revision Beyond Track Changes.” (Lecture). Virginia Tech Composition Speakers Series 2010-2011, Virginia Polytechnic Institute and State University, October 18, 2010.
* “DIY Digital Literacies.” (Invited workshop; with Amy Ferdinandt Stolley). Summer Seminar in Rhetoric & Composition, Michigan State University, June 8, 2010.
* “More Than ‘What You See’: Alternatives to WYSIWYG Web Development.” (Lecture.) Michigan State University Rhetoric and Writing Program’s Distinguished Speaker Series, January 17, 2008.
* “Rhetorical Design.” (Workshop/lecture). Spelman College, Atlanta, GA, September 20, 2005.

## Theoretical Treatments of Communication, Technology, and Design
* “The Boutique is Open: rhetoric.io and Linked Data.” (Co-presented with Cheryl E. Ball). Computers and Writing, Washington State University, June 7, 2014.
* “Teaching a Course Dedicated to APIs.” Association of Teachers of Technical Writing Conference, Indianapolis, IN, March 19, 2014.
* “Yes, We Are Digital Humanists.” (Featured session with Matthew K. Gold, et al.) Computers and Writing, North Carolina State University, May 17, 2012.
* “Activity Theory and Open Source Literacies.” Computers and Writing, University of California-Davis, June 21, 2009.
* “What You See Is What You Look At: Digital Literacies of Code-Level Development.” Computers and Writing, Athens, GA, May 23, 2008.
* “Rethinking Digital Literacy in Terms of ‘Open Source.’” Association of Teachers of Technical Writing Conference, New Orleans, LA, April 2, 2008.
* “A Techne for Artful Choices in Digital Writing.” Conference on College Composition and Communication, Chicago, IL, March 2006.
* “Inventing the Mind’s Eye: Rhetorical Arts of Invention in Visual Communication.” International Visual Literacy Association, Orlando, FL, October 18, 2005.
* “Encountering Actio in Online Visual Design Performance.” Conference on College Composition and Communication, San Antonio, TX, March 2004.

## Applied Treatments of Communication, Technology, and Design
* “Learn to Program with Everyday Household Items: JavaScript.” (Day-long workshop). Computers and Writing, Washington State University, June 5, 2014.
* “End-to-End Agile Web Application Development from Basically Nothing.” (Day-long workshop). Computers and Writing, North Carolina State University, June 17, 2012.
* “Distributed Version Control with Git.” (Workshop). The Humanities and Technology Camp (THATCamp) Chicago, Northwestern University, November 20, 2010.
* “You Gotta Get Git: Fearless Digital Revision and Distributed Collaboration.” Computers and Writing, West Lafayette, IN, May 21, 2010.
* “Technical Communicators and Open Source Development.” Association of Teachers of Technical Writing, Louisville, KY, March 17, 2010.

## Digital Pedagogy and Teaching
* “Dynamic Rhetorics: Incorporating Programming into the Technical Communication Curriculum.” (with J.D. Applen and Sonia Stephens.” IEEE International Professional Communication Conference, Pittsburgh, PA, October 2014.
* “Teaching Sustainable Web Design and Development.” IEEE International Professional Communication Conference, University of Cincinnati, October 2011.
* “Twitter to Infinity and Beyond.” (Workshop; leader. With Julie Meloni, Rachael Sullivan, and Bill Wolff.) Computers and Writing, West Lafayette, IN, May 20, 2010.
* “Twitter from the Ground Up.” (Workshop; facilitator. With Julie Meloni, Rachael Sullivan, and Bill Wolff.) Computers and Writing, Purdue University, West Lafayette, IN, May, 20, 2010.

# Course Development

## Graduate Courses
* **Standards-Based Web Design** (formerly Online Design; Illinois Institute of Technology, COM530)
  A course in the theory and practice of structuring and designing information for web-enabled devices. This course emphasizes web standards, accessibility, and rapid prototyping.
* **Web Application Development** (Illinois Institute of Technology, COM531)
  A production-intensive course in applied theory and practice of developing web-based applications, emphasizing interface and experience design using HTML5, CSS3, and the DOM; and backend development using Ruby-based web application frameworks.
* **Application Programming Interfaces** (Illinois Institute of Technology, COM580)
  A course in the access and manipulation of application programming interfaces (APIs) for data exchange. Broad coverage of historical and theoretical approaches to API construction and availability, and legal ramifications of working within API terms of service agreements.
* **Rhetoric of Technology** (Illinois Institute of Technology, COM532)
  A course in designing with cutting-edge communication technologies (particularly Ruby and git), emphasizing production practices informed by rhetorical principles that lead to pleasing and useful digital designs.
* **Open Source** (Illinois Institute of Technology, COM580)
  A special topics graduate course that investigates the nature and production of open-source technologies and intellectual property, and the ethics and legalities of open source as it impacts communication and related fields.
* **Instructional Design** (Illinois Institute of Technology, COM535, 1 Section)
  A course in a conceptual approach to the process of instructional design, featuring studio-style, project-driven class meetings for exploring and practicing the design of instructional materials and objects.
* **The Rhetoric of Design** (DePaul University, MA Program in New Media Studies, NMS 509, 1 Section)
  This graduate course addressed the DePaul New Media Studies program’s need for a theory-driven multimedia production course.

## Undergraduate Courses
* **Humanizing Technology** (Illinois Institute of Technology, Required course for new Digital Humanities major, originally taught as blended graduate/undergraduate course)
  Historical and theoretical treatments of humanizing technology. Readings from philosophy, media theory, and rhetoric, featuring assignments in interface design and close-readings of technologies as cultural texts.
* **Multimedia Writing: Web Standards Edition** (Purdue University, Elective in PW Undergraduate Major, ENGL419, 1 Section)
  A significant revision of my previous Multimedia Writing courses by more consistently and thoroughly following World Wide Web Consortium (W3C) standards for Web languages.
* **Multimedia Writing** (Purdue University, Elective in PW Undergraduate Major, ENGL 419, 3 Sections)
  This course engaged students in simultaneous visual and text production using Flash to explore the use of visuals, video, and audio; and to develop material treatment strategies for repurposing visuals and text for different electronic media and print.

# Administration
* **Director of Graduate Studies**, Illinois Institute of Technology Department of Humanities, August 2011-2016.
* **Director and Founder of Gewgaws Lab**, 2009-present.
  A virtual lab aimed at the development of open-source humanized interfaces and digital communication technologies.
* **Co-Director of the Usability Testing and Evaluation Center** (UTEC), Illinois Institute of Technology, 2009-2011.
* **Purdue University OWL Webmaster**, 2004-2007.

# Institutional Service

## Department of Humanities
* Undergraduate Curriculum Committee (chair), 2011-present.
* Digital Humanities Undergraduate Major Committee, 2012-2013.
* Assistant Professor of Digital Humanities Search Committee (chair), 2011-2012.
* Department Chair Search Committee, 2009.
* Assistant Professor of Technical Communication Search Committee, 2009-2010.

## Illinois Institute of Technology
* University Faculty Council Library Committee (chair), 2009-present.
* Innovation Center Steering Committee, 2013-present.
* Graduate Studies Committee, 2011-present.
* Digital Humanities and Computer Science Program Committee, 2009.

# Professional Service

## Editorial
* Editor and Founder, *Push: Research and Applied Theory in Writing with Source*, 2012-present.
* Editor, Computers and Composition Digital Press, 2008-2013.
* Lead Designer and Interface Editor, *Kairos*, 2006-2009.
* Inventio Section Co-Editor with Madeleine Sorapure, Kairos, 2006-2009.

## Manuscript and Proposal Review
* Editorial Board, Kairos: A Journal of Rhetoric, Technology, and Pedagogy. 2014-present.
* Board of Reviewers, Journal of Business and Technical Communication, 2009-present.
* Technical Reviewer for Pragmatic Programmers, 2011-present.
* Editorial Advisory Board Member and Reviewer for Social Software and the Evolution of User Expertise (Tatjana Takseva, ed.), 2010-2011.
* Manuscript reviewer, *Technical Communication*, 2010.
* Manuscript reviewer, *IEEE Transactions in Professional Communication*, 2008.

## National Organizations
* College Conference on Composition and Communication (CCCC) Committee on Intellectual Property, 2010-2013.
* International Visual Literacy Association, Board of Directors, 2006-2009.
* International Visual Literacy Association, Membership and Electronic Presence Committees, 2006-2009.
* Council of Programs in Scientific and Technical Communication, Web Consultant for Annual Conference, 2004.

# Media Appearances
* “Graph Search Announced for Facebook.” ABC7 Chicago (5pm, 6pm, and 10pm television newscasts and Web), January 15, 2013.
* “Virtual Sustainability.” IIT Magazine, Winter 2010.
* “The Truth Behind ChicagoansForRio.com.” FOX Chicago 32 (9pm television newscast and Web), September 28, 2009.
* “Using Microformats: Gateway to the Semantic Web.” IEEE Professional Communication Society (Podcast), September 8, 2009.
* “Web Professional Roles and Responsibilities.” World Organization of Webmasters (Podcast interview), March 19, 2008.
* “Best Practices in Web Design.” World Organization of Webmasters (Podcast interview), January 21, 2008.

# Technology Proficiencies
* **Front-end Languages, Frameworks, and Compiled Forms**: XHTML/HTML5 (HAML,ERB); CSS (SCSS); JavaScript (CoffeeScript; jQuery, MooTools), Document Object Model
* **Back-end Languages and Frameworks**: Ruby (Jekyll, Sinatra, Rails); JavaScript (Node.js); PHP (CakePHP, WordPress, Drupal)

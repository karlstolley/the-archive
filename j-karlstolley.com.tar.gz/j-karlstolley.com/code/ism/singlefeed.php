<?php
/*
$ourfeeds specifies students' or project members' names and feed URLs.
Additional feeds can be added by adding a comma at the end of the last
feed and creating a new line; see the multifeeds example.
*/
$ourfeeds = array(
  'Social Media Bookmarks'=>'http://feeds.delicious.com/v2/rss/tag/social-media'
  );

/*
Randomize the array, using a little custom PHP, so as to not appear to favor
any one team member; to show the feeds in the order above, remove or comment
out this line (two slashes, //, will comment it out).
*/
$ourfeeds = ks_feed_shuffle($ourfeeds);

/*To show tagspace links, set this to yes; otherwise, set it to no*/
$usetaglinks = 'yes';

/*Specify the base URL for tagspaces; this uses Delicious's tagspace
pattern*/
$basetagurl = 'http://delicious.com/tag/';

/*Now the script jumps out of PHP and lists a standard XHTML Strict DOCTYPE, some CSS, etc.*/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Feed Testing Grounds</title>
<style type="text/css" media="screen">
body { font-size: small; font-family: Arial, Verdana, sans-serif; }
h1, h2 { font-weight: bold; margin: 0; padding: 0;}
h1 { font-size: 150%; border-bottom: 1px solid black; margin-bottom: .25em; }
h2 { font-size: small; margin-top: 1em; }
ul.tags, p { margin: 0; padding: 0; }
p { padding-bottom: .5em; }
ul.tags li { list-style-type: none; display: inline; margin-right: .5em; }
ul.tags a { background-color: blue; color: white; text-decoration: none; padding: 0 .2em 0 .2em; }
ul.tags + h1 { margin-top: 1.5em; }
</style>
</head>

<body>
<?php
/* 
If your feeds aren't working, try commenting out this line, which will
print all of the items in the feed array.
*/
//print_r($ourfeeds);

/*Essential SimplePie things*/
/*Include the simplepie.inc file*/
require_once('./simplepie.inc');

/*Create the SimplePie object*/
$feed = new SimplePie();

/*
Disable caching for testing purposes; on a live use of SimplePie,
it's best to cache & therefore limit hits to the sites where the
feeds live.
*/
$feed->enable_cache(false);

/*
Now comes the real work of moving through the group of feeds,
using a foreach() loop
*/
foreach($ourfeeds as $feedname => $feedurl) {
	/*Set up a different feed URL each time through the loop;
	 target through the $ourfeeds array */
	$feed->set_feed_url($feedurl);
	/*Test to see if the feed was initialized corectly*/
	$success = $feed->init();
	/*If the feed initializes...*/
	if($success) {
	    	/* Set maximum items to 5; change this number to display more.*/
			$max = $feed->get_item_quantity(5);
				/*Now run through feed items and grab their link, title, and descrip.*/
				for ($x = 0; $x < $max; $x++) {
					$item = $feed->get_item($x);
					$ilink = $item->get_link();
					$ititle = $item->get_title();
					$idescrip = $item->get_description();
				/*Use the 'So-and-So ’s Feed' from the array on the first item*/
					if($x==0) { print "<h1>". $feedname . "</h1>"; }
					/*Print the link in an <h2> w/ <a> tag*/
					print "<h2><a href=\"".$ilink."\">" . $ititle . "</a></h2>";
					/*Print the description*/
					print "<p>" . $idescrip . "</p>";
					/*Spit out the list of tags w/ the item, if specified*/
					if($usetaglinks=='yes') { ks_get_tag_links($item, $basetagurl); }
		}
	}
	
	/* If the feed doesn't initialize, allow an error for each feed,
	   so as to track down individual feed problems, if they exist. */
	else { print  $feed->error(); }
/*Close "foreach" loop*/
}

/* Custom tag listing function */
function ks_get_tag_links($item, $basetagurl="http://delicious.com/tag/") {
	print "\n<ul class=\"tags\">";
		foreach ($item->get_categories() as $category) {
			$taglist = explode(' ', $category->get_label());
			if(count($taglist) < 1) { print "<li>No tags associated with this item</li>"; }
			else {
				foreach($taglist as $tag) {			
					if ($skiptag!==$tag) {print "\n  <li><a href=\"".$basetagurl.$tag."\" rel=\"tag\">".$tag."</a></li>";}
				}
			}
		}
    print "\n</ul>";
}
/*Custom shuffle function*/
function ks_feed_shuffle($feed_array=array()) {
  $copy = array();
  while(count($feed_array)) {
    $element = array_rand($feed_array);
    $copy[$element] = $feed_array[$element];
    unset($feed_array[$element]);
  }
  return $copy;
}
?>
   
</body>
</html>

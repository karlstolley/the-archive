Repository for work that I’m doing for the Newberry Library Digital Collections for Classroom Use project.

What follows here in this ``README`` file, for the time being, are my notes and thought processes as I’m working through the project’s early stages.

### Key problems and potential solutions

Here’s the main problem in terms of the site’s information architecture: item <-> document  (same thing; “items” are a list of individual things; “documents” are what make up an exhibit; links to items kick you out of the exhibit, with no way back save the Back button).

  * What needs to happen is to detach the ‘item’ from the exhibit; that is, the exhibit page should list the complete information about each item. jQuery can be thrown in after it to keep things manageable for users, but a complete listing of all the items and their details/image links will remain viable for JavaScript-less users, while also radically simplifying the ability to print out exhibits and make printable/portable versions of the content later on.


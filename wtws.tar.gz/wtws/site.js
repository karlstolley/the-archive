jQuery(document).ready(function($) {
  // Treat any <strong> tags (** in Markdown) for use as pullquotes
  // TODO: Disallow this for the final paragraph
  $('html').removeClass('nojs').addClass('js');
  $('.text p strong').each(
    function() {
      $(this).parent().after('<div class="pullquote">'+$(this).html()+'</div>');
    }
  );
  // Replace Tumblr usernames with real names, custom URLs
  $('.author').each(
    function() {
      authorNames($(this));
    }
  );
  // Isolate first phrase or first sentence
  $('.text > p:first-child').each(
    function() {
      openerHTML = $(this).html();
      openerHTML = openerHTML.replace(/(^[“]?[\w\s'’]*(?:,”|\?”|[^\w'"“’]))/m,'<b class="opener">$1</b>');
      //console.log(openerHTML);
      $(this).html(openerHTML);
    }
  );
});

function authorNames(author) {
  var authorNames = {
    'karlstolley': { 'name': 'Karl Stolley', 'url': 'http://twitter.com/karlstolley' },
    'jerryt': { 'name': 'Jerry Taft', 'url': 'http://abc7chicago.com/' }
  }
  user = authorNames[author.data('username')];
  // If a username hasn't yet been added to the authorNames object,
  // leave it alone
  if (user != undefined) {
    author.html(user.name).attr('href',user.url);
  }
}

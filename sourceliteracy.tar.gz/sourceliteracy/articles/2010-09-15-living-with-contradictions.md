--- 
author: Karl Stolley
title: Living with Contradictions
github: 2010-09-15-living-with-contradictions.md
date: 15/09/2010
description: "How I justify being an Apple fan despite loathing Microsoft and Adobe."

So anyone who follows [me on Twitter](http://twitter.com/karlstolley/) would know that [I've](http://twitter.com/karlstolley/status/24601256470) [got](http://twitter.com/karlstolley/status/24120100431) [no love](http://twitter.com/karlstolley/status/22905981705) [for Microsoft](http://twitter.com/karlstolley/status/22821052085) or [Adobe](http://twitter.com/karlstolley/status/22905793492).

The number of recent gripey Tweets about Microsoft and Adobe is a direct result of how I spent most of the month of August: setting up a new computer lab for my tech comm students. Configuring the free and open-source (FOSS) side of the machines (running [Ubuntu Linux](http://www.ubuntu.com/)) was a fantastic learning experience; but setting up the Windows side deepened, in equal measure, my love of open source and my disdain for Microsoft and, especially as of CS5, Adobe.~

Even before the lab setup, though, I had a well developed penchant for launching into passionate diatribes against those two companies, right in the middle of class or a conference presentation. But one glaring contradiction, whether it's occurred to my students and professional colleagues or not, is my fandom (I wouldn't call it deep love) for Apple and its products.

To live contradiction-free, I suppose I should be carrying around an Android phone. I'd swear off the iPad that IIT supplied me with. I'd ditch the MacBook Pro I'm composing this post on.

But I won't. And here are a few reasons why:

*	**Sometimes hardware matters more than software.** In a certain sense, you have to almost take pity on Windows--it has to run on a lot of different hardware. That's what gives it such a huge market share. (Of course, you can run Linux on a whole lot more hardware--including truly ancient computers that rise Lazarus-like from the dead when Linux calls them forth.) Android might be shipping on a whole lot of phones, but a recent trip through the phone area at my local Best Buy was enough to convince me that despite everything there is to love about Android, the phones that run it are 
	
	But software considerations aside, what's really appealing about Apple is the hardware, and the close and careful (some would say tinfoil-hat) protectionism that Apple takes in wedding its hardware to its software. When it comes to any device I'll cart away from a desk--a music player, a smart phone, a laptop--I'll go with Apple every time. I still use an aging iBook G4 for when I do presentations. It doesn't have OS X on it anymore, though. It runs Linux.
	
* **Multiple roads to Rome.** What gets lost in [the ongoing of the criticism](http://www.google.com/search?hl=en&q=apple%20app%20store) of Apple's centralized app store and its [still relatively ambiguous rules for app approval](http://www.nytimes.com/2010/09/10/technology/10apple.html) is that Apple provides two important ways to build content for iOS devices: the iOS version of the Safari web browser and the iBooks application, just to name two.

	I have yet to begin seriously developing a native iOS app, but that's partially because anything I've wanted to do for iPhone I've done by leveraging Safari (particularly using [CSS media queries](http://www.w3.org/TR/css3-mediaqueries/) [specific to iOS devices](http://developer.apple.com/library/safari/#codinghowtos/mobile/userExperience/index.html)) or iBooks, which supports and will arguably popularize [the EPUB standard](http://www.daisy.org/epub/).
	
	Sure, if you want to leverage the iPhone's SDK and APIs, and by extension its hardware, you're going to have to build a native app, and you're going to have to go through the app store--or convince a whole lot of people to jailbreak the phone (which I did once, to my 3G iPhone, and will never do again).
	
* **Mac OS X and iOS are open-source upstream.** Not unlike RedHat or even Canonical, two companies that are making money off of different distributions of Linux, Apple is quite literally capitalizing on open-source software. Both OS X and iOS are based on Darwin, itself a variant built on components of BSD Unix. Part of the promise of open source that Eric S. Raymond outlines in <cite>The Cathedral and the Bazaar</cite> is for companies, like Apple, to extend and make money off of open source software. Which is what they're doing. Of course, OS X is far more open than is iOS, allowing for neat projects like [MacPorts](http://www.macports.org/), which makes it easy (if sometimes sub-optimally) to install a whole bunch of different software from the Linux universe. 

That all said, the contradition remains. I wish that Apple's App Store were open (or perhaps that there was an open, use-at-your-own-risk component to it). I wish that I could SSH into my iPhone and muck around with some of the configuration files at will *without* having to jailbreak it. I wish there were a MacPorts for iOS or, better still, a way to compile source files right on the phone itself.
	

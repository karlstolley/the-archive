--- 
author: Karl Stolley
title: "New Course: Web Application Development"
github: 2010-09-10-new-course-web-application-development.md
date: 10/09/2010
description: "Short course description and starter book list for a spring semester course on Web application development."

Although fall semester is barely underway, I am already thinking about a graduate course that I'll
be running on web application development in the spring. While it will be a special topics course
(in the parlance of my university), my plan is to eventually push the course through the proper
channels to make it an official part of IIT's [technical communication and information
architecture](http://www.iit.edu/csl/hum/programs/grad/) curriculum, as COM531: Web Application
Development--a follow-up to the required [COM530: Standards-Based Web
Design](http://courses.karlstolley.com/530/), which I'm teaching this semester.~

Anyway, the description that I submitted to my department for this new course reads:

> **COM580: Web Application Development**
>
> A production-intensive course in the theory and practice of developing web-based applications,
emphasizing design for mobile web browsers. The course offers extensive coverage and applied
treatments of emerging web standards, including HTML5 and CSS3, and advanced techniques for
manipulating the Document Object Model (DOM) using the industry-leading jQuery JavaScript
library. Because the course is focused on the shifting designer/developer roles of technical
communicators/information architects, students will learn agile, modular development techniques
grounded in open-source technologies, including version control (Git), Ruby, and Ruby web
development frameworks, such as Rails and Sinatra. The course also explores leveraging and creating
open application programming interfaces (APIs) to integrate external data/functionality into web
applications and to repurpose/repackage information for use in mobile app platforms (e.g., Android,
iOS). Note: students should take COM530: Standards-Based Web Design or have a solid command of Web
standards (especially XHTML and CSS) prior to enrolling in this course. 

I'm only in the earliest stages of putting together the actual course, although so far the book list
is looking something like this:

1. Earle Castledine & Craig Sharkie, <cite>[jQuery: Novice to Ninja](http://www.sitepoint.com/books/jquery1/)</cite>
2. Jeremy Keith, <cite>[HTML5 for Web Designers](http://books.alistapart.com/products/html5-for-web-designers)</cite>
3. Sam Ruby, Dave Thomas, & David Heinemeier Hansson, <cite>[Agile Web Development with Rails](http://pragprog.com/titles/rails4/agile-web-development-with-rails)</cite>, 4th Ed.
4. Travis Swicegood, <cite>[Pragmatic Guide to Git](http://pragprog.com/titles/pg_git/pragmatic-guide-to-git)</cite>
5. Dave Thomas with Chad Fowler & Andy Hunt, <cite>[Programming Ruby 1.9: The Pragmatic Programmers' Guide](http://pragprog.com/titles/ruby3/programming-ruby-1-9)</cite>

Project-wise, the course is still pretty well up in the air. I'll post those ideas here as I have them.

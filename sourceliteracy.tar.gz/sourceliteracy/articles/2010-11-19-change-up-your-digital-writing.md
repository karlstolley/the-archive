--- 
author: Karl Stolley
title: Change Up Your Digital Writing
github: 2010-11-19-change-up-your-digital-writing.md
date: 19/11/2010
description: “A whole-hog, no-baby-steps approach to change up how you write digitally.”

I was inspired today by an article on [opensource.com](http://opensource.com/)
about the [pathetic state of web design and development education in secondary
and post-secondary
schools](http://opensource.com/education/10/11/epic-fail-sorry-state-web-
education-schools), which is itself a summary of [a presentation
(video)](http://vimeo.com/16632164) at Mozilla’s [Drumbeat
Festival](http://www.drumbeat.org/festival/program) by [Anna
Debenham](http://maban.co.uk/), a young web developer in the UK.~


But rather than issue a series of what-she-saids regarding Ms. Debenham’s
presentation, I’m writing a post that is a first attempt at a condensed
whole-hog, no-baby-steps list of concrete moves and classes of technologies that
I believe are essential to changing how you write and design _digitally_, by
which I mean “for the Web.” (Because when it comes to digital writing, if
something’s not made for the Web, what’s the point?) And by “for the Web,” I
also mean according to open [web standards](http://webstandards.org). In the
interest of expediency, I’ve put some concepts/premises behind this cavalier
approach at the end of the post.

## What to Do

1. **Become a better technology researcher and reader.** I’m listing only the
basics here (no, really); have Google at the ready to learn more about what
you’re doing whenever you have even the slightest question or puzzlement.
Learning doesn’t come just by hammering through a tool; it comes with lots of
reading and research. All of the languages and tools here have active, even
rabid communities of users who post to forums, blogs, and documentation pages.
Some write excellent electronic and print books; I may be old-school this way,
but a book is a great way to learn many technologies--simply because it is a
long form treatment that’s consistent (if necessarily incomplete--no one book
can teach you _everything_). Forums and blog posts are useful, but often
contradictory. The second you write with source and source-based tools, you
discover there are multiple roads to Rome. With that in mind, I’ve listed some
recommended reading in the items below; they’re all books. Use your Google-fu to
find web-available stuff.

1. **Get a text editor meant for writing.** The default editors that come with
Windows (Notepad) and Mac (TextEdit) are terrible for writing. Instead, try one
of these editors: [Notepad++](http://notepad-plus-plus.org/) for Windows
(download the ```.bin.zip``` file, and throw away the folder labeled ```ansi```;
run the Notepad++ executable in the ```unicode``` folder; there’s no need to run
an installer) and
[TextWrangler](http://www.barebones.com/products/textwrangler/) for Mac (you can
also upgrade to the for-pay BBEdit). Linux has a bunch of great editors, from
the command-line editor vim to the Gnome gedit program to something more
sophisticated like Kate. (I’ll say more about Linux later.) And you’ll use your
editor for everything: from XHTML and CSS to server configuration files. The
editor is to the digital writer what a light saber is to a Jedi. Your life
depends on it; get a good one.

1. **Learn to write XHTML 1.0 Strict and CSS in the editor.** Period. HTML5 and
CSS3 and all of the other hot languages on the horizon come later; start with
the basics to develop a sense of the strict, XML rules—checking your work
against the W3C Markup Validator:
[http://validator.w3.org/](http://validator.w3.org/) Recommended reading: Dan
Cederholm’s _Bullet-Proof Web Design_; Jeffrey Zeldman’s _Designing with Web
Standards_; Eric Meyer’s _Smashing CSS_.

1. **Name your files and folders as though you have no space bar or shift key.**
Lowercase letters, numbers, and maybe the hyphen. That’s all that goes in a file
or folder name--despite what your operating system lets you do. Also, make sure
your operating system is showing you the extensions to your files. What looks
like ```index``` in Windows might be ```index.htm```, ```index.txt```, or
```index.doc```. Adding, say, ```.htm``` to the file yourself might result in
something tortured like ```index.htm.txt```. It’s up to you to ask your OS to
always display file extension information: do a Google search for _show file
extensions_ and _windows_ or _mac os_ depending on the operating system you’re
running.

1. **Run your own local web server.** The road to hell is also paved with using
File > Open in a Web browser and the dreaded ```file:///Giant/Path to all your
stuff/Web/stuff```. Paths to other pages and files (images, CSS, JavaScript)
probably won’t work right, basic server-side scripting languages like PHP won’t
execute, etc. XAMPP is a simple, download-and-run option for running a local
Apache web server for testing, using the simple ```http://localhost/``` URL in
your browser.

1. **Run Firefox and load it up with the Web Developer Add-on.** I prefer the
snappier Google Chrome/Chromium for my everyday browsing, but for web writing
and development, you can’t beat [Firefox](http://www.mozilla.com/firefox/). And
no web writer should be without [Chris Pederick’s Web Developer
Add-on](https://addons.mozilla.org/en-US/firefox/addon/60/) for Firefox, which
lets you edit CSS right in the browser window and see your changes in real time
(just don’t forget to copy and paste your work back to your text editor. Other
features of that add-on include uploading local HTML/CSS to their respective
validators and disabling CSS/JavaScript/images to check for accessibility.

1. **Get Git, a distributed content versioning system, and use it to track
changes to everything you write in your text editor.** The hardest part of
moving forward beyond the basics of XHTML and CSS is the fear of screwing up
what already works. Git takes those worries away, by letting you maintain a
history of all the changes to your files and by offering a feature called
branching, which lets you make alternative histories of your files to really
experiment--while keeping the main/stable line of your work untouched and
pristine. If the work on a branch is good, merge it back to the main stable
line. Recommended reading: Travis Swicegood’s _Pragmatic Version Control Using
Git_.

## What to Do Next 

1. **Get a Unix-like operating system.** [Ubuntu
Linux](http://www.ubuntu.com/) is as easy to install as Windows or Mac OS (which
is actually a Unix-based operating system itself, and therefore fits the bill of
a Unix-like operating system). Repeat the steps above, but on Ubuntu Linux or
Mac OS. Use Windows only when you have no other choice; trying to write for the
Web on Windows is like trying to tap-dance in cement shoes.

1. **Learn DOM Scripting** perhaps with the assistance of a library such as
jQuery. DOM Scripting, which is JavaScript applied to the Document Object Model,
provides an excellent transition from simple markup and design languages (XHTML
and CSS) to object-oriented programming, using a familiar object: your XHTML
document (that’s where ‘Document Object Model’ comes from).

1. **Get on the command line, and stop using your operating system’s GUI for
finding and copying/moving/deleting files.** Git will have you on the command
line already, but writing for the Web and doing anything interesting with files
on it involves paths, a textual representation of the locations of and between
files: for example, the slashes in a URL or Web address represent paths. Once
you go live with a project, you may also need to worry about file
permissions--which are most accurately determined and set on the command line.

### A Note for Teachers and Students Stuck in a Locked-Down Lab

Fine if you have administrative access on your own computer. But what should
teachers and their students do in a situation where a campus computer lab is
locked down and IT staff are resistant to installing open-source software?

My answer, based on 3 years of teaching this way in just such a situation: Have
everyone get a USB/thumb drive (2GB or so is plenty) and download the following
things on that drive:

* [Notepad++](http://notepad-plus-plus.org/). Remember to download the latest
version with the ```.bin.zip``` extension. It’ll run just fine and without
complaint. Again, use the unicode version, and throw the ansi version away.
* [XAMPP](http://www.apachefriends.org/en/xampp-windows.html). Likewise, this will
also run just fine and provide a fully-fledged Web server. 
* [Firefox Portable](http://portableapps.com/apps/internet/firefox_portable). Also runs
from a USB disk and even enables installing Firefox extensions like the Web
Developer Add-on. 
* [Portable Git](http://www.softpedia.com/get/PORTABLE-SOFTWARE/Programming/Portable-Git.
shtml). Last time I tried to use this, I had to install it on a Windows computer
for which I had administrative access, but then it worked just fine on any other
computer I used it on--including those without administrative access.

Pop that baby into your lab computer, and odds are you’ll be off and running as
though you’d installed the software natively. This is approach is also helpful
to students who are hesitant to install software on their own computers (though
encourage them to do a full install).

If your campus IT is so paranoid that it won’t allow USB access, you should be
able to download and run these portable apps (minus Portable Git) right on the
desktop.

The solutions above will only work on Windows machines. For Mac versions of
these portable apps, see [FreeSmug.org](http://www.freesmug.org/portableapps).
IT paranoia and Macs seem to go hand-in-hand far less frequently than IT
paranoia and Windows. But there are always options. There is always a solution
of some kind.

## Why to Do It

As promised/threatened, here are the basic concepts/premises behind this
approach:

* **Baby steps teach nothing of significance.** The chief reason people tend to
use Microsoft Word for everything, and Dreamweaver for everything else, is that
they think ‘baby steps’ are the way to advance their knowledge. No knowledge
comes from minor, insignificant changes to entrenched habits. Baby steps are
changes that change nothing, changes that teach nothing, changes that lull
people into complacency by making them think they’ve done something new, when in
fact they’ve just dressed up an ugly old habit in the form of a new plugin or
tool. Real change in digital writing and design habits can only come by
completely scrapping past habits and committing to new ones without hesitation
or exception.

* **Don’t look back.** A summer ago when I began to teach myself Git, the
content versioning system I mentioned above, I decided that _everything_ I wrote
that wasn’t an email or a status message would be put under Git control. No
exceptions. The only way to really learn a digital technology is to use it
everywhere, all the time--and leave old habits for good.

* **Screwing up is ignorance leaving the brain.** A rewrite of Marine Corps
marketing slogan “Pain is weakness leaving the body.” Screwing up is an
essential part of learning something radically new. Screwing up will happen. It
should happen. It’s neither pleasant nor fun, but it is essential. Whenever I
learn a new digital technology, if I’m not asking myself _Dear God, what have I
done this time?_ almost immediately, I know that I’m probably taking baby steps
and not letting the real learning take place.

* **There is a solution to every problem, and you will find it. Eventually.**
That does not mean you will find the solution that _you_ believe solves the
problem; it simply means that there is a solution to be found--either by
rethinking your approach or reconceptualizing the problem. And researching and
reading. A lot. Just last week a student watched me struggle with a server
problem in my office. “How do you keep so calm?” she asked. I responded that I
know that there’s a fix for this, and it’s a matter of thinking about it, doing
some research, and then implementing the fix. (I probably should have added that
it helps me to have an audience; I can be far less calm when nobody’s looking.)

Postscript: I dislike the term ‘baby steps’ more than I can say, but because I
seem to always be asked “Well, what is a less drastic approach to this? What
would the baby-steps look like?” I opted to use the term.

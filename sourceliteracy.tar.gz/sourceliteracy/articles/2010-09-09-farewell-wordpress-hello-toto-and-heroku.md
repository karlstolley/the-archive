--- 
author: Karl Stolley
title: Farewell WordPress, Hello toto and Heroku
github: 2010-09-09-farewell-wordpress-hello-toto-and-heroku.md
date: 09/09/2010
description: "Another attempt to recommit myself to blogging."

One of the things I like to do when I [teach](http://courses.karlstolley.com/ "Overview of my course
websites") is to complete the same projects that I assign my students. Time constraints being what
they are, that's not always possible--but this semester, I plan to overhaul my website at
<http://karlstolley.com> while my [web design](http://courses.karlstolley.com/530/) students work on
their sites.

As part of preparing for that work, I have decided to pull the plug on the WordPress blog that I've
kept there, and try something new. I loved the idea of WordPress, and still do for certain things,
but it's just not something I find myself wanting to write in or with.~

I like to write in a simple text editor, because I like to write in environments that feel
low-stakes. And I like to share ideas in similar low-stakes environments, such as
[Twitter](http://twitter.com/karlstolley).

Plus, because my research is moving more and more in the direction of
[revision](http://www.composition.english.vt.edu/?page_id=253), I'm interested in a low-stakes
writing environment that nevertheless provides the opportunity for rethinking, revisiting, and
otherwise revising writing. The blog form really doesn't allow for that, at least not in a public
and visible way. Unlike wikis, the blog databases I'm familiar with do not maintain older versions
of posts. There's only just the latest one, and it's up to individual authors to note (or not) any
updates and changes.

Enter [toto](http://cloudhead.io/toto), which is

> a git-powered, minimalist blog engine for the hackers of Oz. The engine weighs around ~300 sloc
[source lines of code] at its worst. There is no toto client, at least for now; everything goes
through git. (<http://cloudhead.io/toto>)

For the uninitiated, [Git](http://git-scm.com/) is a distributed [version control
system](http://en.wikipedia.org/wiki/Revision_control) that is like a word processor's track changes
feature on steroids. And because Git is distributed, you can push your projects around from computer
to computer. I routinely push this blog to [a repository at my GitHub
account](http://github.com/karlstolley/sourceliteracy/), which contains both the template files and
the actual posts as humble text files.

And to publish the blog via [Heroku](http://heroku.com/), a platform for deploying [Ruby](http://www.ruby-lang.org/en/) applications, is no different; running

	git push heroku master

from my command line is all it takes, whether I'm pushing up a new post, changes to an old post, or
even design enhancements to the blog itself (which is pretty vanilla and basic, but that's what I
want--low-stakes).

Here are a few more things that make the new toto/Heroku/Git combination awesome:

1. The text files can be created using [Markdown](http://daringfireball.net/projects/markdown/),
which features little bits of syntax that I pretty much already use when I'm writing in plain text,
like `**bold**` for **bold**.
2. Git and toto are both free and open-source software. And even Heroku makes ad-free accounts
available. This whole blog that you see before you came into the world without any money changing
hands. (Although I feel like I ought to either finish setting up my own server to run Ruby apps, or
upgrade to a paid account on Heroku, just to support them the way I do [GitHub](http://github.com);
you'll notice that even with my free account, I'm able to use my own
URL--<http://blog.karlstolley.com/>).
3. It's easy as pie to install Ruby and [Ruby Gems](http://rubygems.org/) on any decent operating
system (read: not Windows). Using gems, it's trivial to grab toto as well as [rack](http://rack.rubyforge.org/)
and a web server like [thin](http://code.macournoyer.com/thin/), and do
all the blog design and development and post-previewing your heart desires on your own computer,
before pushing out to GitHub or Heroku or anywhere else.

OK, enough gushing. I haven't even hit the parts about HTML5 and some other goodies that I'm using
this new blog to try out. But I'll save those for another post.

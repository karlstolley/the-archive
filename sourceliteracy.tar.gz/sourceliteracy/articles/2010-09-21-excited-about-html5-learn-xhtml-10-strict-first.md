--- 
author: Karl Stolley
title: Excited about HTML5? Learn XHTML 1.0 Strict First
github: 2010-09-21-excited-about-html5-learn-xhtml-10-strict-first.md
date: 21/09/2010
description: "HTML5 is pretty awesome, but do yourself a favor and learn XHTML 1.0 Strict first."

So unless you've been living under a rock for the last several months, you'd know that since April,
there's been quite the dispute between Apple and Adobe regarding the availability of Flash on
Apple's fleet of mobile devices, particularly iPhone and iPad.~

In his letter open letter "[Thoughts on Flash](http://www.apple.com/hotnews/thoughts-on-flash/),"
Jobs wrote that

>Rather than use Flash, Apple has adopted HTML5, CSS and JavaScript – all open standards.... HTML5,
the new web standard that has been adopted by Apple, Google and many others, lets web developers
create advanced graphics, typography, animations and transitions without relying on third party
browser plug-ins (like Flash).

Billing HTML5 as a replacement for Flash is a pretty tall order, but even if it were only an empty
promise, it might be enough to pique interest in those inclined toward the latest and greatest in
Web development languages.

So should you, as the name of a website showcasing the capabilities of HTML5 invites, [Dive Into
HTML5](http://diveintohtml5.org/)? Here are some things to consider first:

**HTML5 is a language still very much in development**, and therefore all features of it are not
supported by all browsers. Those features that are supported, while generally more stable than those
that are not, may still change in the future. And in the case of Microsoft Internet Explorer (unless
you count its recently released public beta of version 9), none of HTML5's features are supported
and therefore require some kind of work around, usually in the form of a JavaScript library like
[Modernizr](http://www.modernizr.com/). (However, note that if someone is browsing in IE with
JavaScript disabled, that solution is not going to work.)

**HTML5 has a richer, more semantic tag set than HTML 4 or HTML 4's XML cousin, XHTML** and it seems
to all but demand being writting by hand, rather than through a WYSIWYG. The original HTML language
was developed by Tim Berners-Lee for the purpose of marking up scientific papers. Most of classic
HTML's tag set is limited to structural conventions found in scientific papers: headings,
paragraphs, and lists, plus tags for bold, italic, and underline. Oh, and of course the anchor tag,
better known as the hyperlink. Those basic structural conventions made WYSIWYGs (such as
Dreamweaver) attractive alternatives to writing HTML by hand. Paragraphs, lists, and so on are easy
enough to create in a word processor, so it's no accident that the same kinds of menus and buttons
found in the word processor show up in the WYSIWYG.

And while I've advocated (and taught) writing XHTML by hand for years now, I really have a hard time
seeing how WYSIWYG editors, which did fine with the old, limited tag set of earlier HTMLs, will
handle the semantic components of HTML5. I suspect that the use of templates will become more
prevalent, as evidenced in Adobe's [sad little
tutorial](http://www.adobe.com/devnet/dreamweaver/articles/dw_html5_pt1.html) on HTML5. But using
templates defeats the whole purpose of semantic markup, which should be tailored to a site's
content.

**HTML5 let's you be way sloppier with markup than XHTML.** That's a chief reason to learn XHTML 1.0
Strict first. It'll instill some very good stylistic and structural habits that, as Jeremy Keith
notes in his excellent book <cite>[HTML5 for Web
Designers](http://books.alistapart.com/products/html5-for-web-designers)</cite>, can still be
followed in HTML5--even though you don't have to according to the HTML5 specification itself.

**HTML5 is just part of a larger constellation of the next generation of Web standards.** The way
that HTML5 is sometimes talked about in the popular and tech press, you'd think it was a huge island
unto itself. But new, coemergent standards--CSS3 in particular--will be used alongside of it.
Writing the simpler XHTML 1.0 Strict and learning to control the more stable CSS2 and a healthy dose
of DOM Scripting will make HTML5 and other emerging standards far less daunting later on.
